import fs from 'node:fs/promises';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { createRequire } from 'node:module';
import assert from 'node:assert/strict';
import { emptyState } from '../web/domain.js';
const origin = 'http://localhost:4320';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLANNER_PLAYWRIGHT_MODULE || 'playwright');
const browser = await chromium.launch({ headless: true, executablePath: process.env.PLANNER_BROWSER || undefined });
const context = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, reducedMotion: 'reduce' });
try {
  const login = await context.request.post(origin + '/api/auth/login', { data: { key: 'a'.repeat(43) } }); assert.equal(login.status(), 200);
  const cookie = login.headers()['set-cookie'].split(';')[0];
  await context.setExtraHTTPHeaders({ Cookie: cookie });
  const pairingResponse = await context.request.post(origin + '/api/auth/pair', { data: {}, headers: { Cookie: cookie } });
  assert.equal(pairingResponse.status(), 200); const pairing = await pairingResponse.json();
  const { token } = await (await context.request.post(origin + '/api/auth/exchange', { data: { code: pairing.code, native: true } })).json();
  assert.ok(token);
  const previous = await (await context.request.get(origin + '/api/state')).json();
  await context.request.put(origin + '/api/state', { data: { state: emptyState(), revision: previous.revision } });
  const folder = path.resolve('.local/native-' + Date.now());
  const executable = path.resolve('../Planner/v440-sync-test/Planner.exe');
  try {
    await promisify(execFile)(executable, ['--sync-test', '--data-dir', folder, '--sync-origin', origin], { env: { ...process.env, PLANNER_TEST_SESSION: token }, timeout: 90000 });
  } catch (error) { console.log(await fs.readFile(path.join(folder, 'sync-test.txt'), 'utf8')); throw error; }
  const results = await fs.readFile(path.join(folder, 'sync-test.txt'), 'utf8'); console.log(results);
  assert.equal(results.split('\n').filter(line => line.startsWith('PASS')).length, 15);
  const page = await context.newPage();
  await page.goto(origin + '/?test=1'); await page.waitForFunction(() => window.plannerApp?.ready);
  assert.equal(await page.evaluate(() => window.plannerApp.storage.authNeeded), false);
  assert.equal(await page.evaluate(() => window.plannerApp.state.entries.some(item => item.title === 'Изменение Windows')), true);
  assert.equal(await page.evaluate(() => window.plannerApp.state.operations[0].amount), '12345');
  console.log('PASS Настоящий мобильный интерфейс видит изменения WPF и финансовые операции');
  await page.screenshot({ path: '.local/screens/independent-sync.png', fullPage: true });
  const fresh = await browser.newContext({ viewport: { width: 390, height: 844 }, reducedMotion: 'reduce' });
  const signIn = await fresh.newPage(); await signIn.goto(origin + '/?test=1');
  await signIn.locator('form[data-form="sign-in"]').waitFor();
  await signIn.locator('[name="key"]').fill('a'.repeat(43)); await signIn.locator('form[data-form="sign-in"] button[type="submit"]').click();
  await signIn.waitForFunction(() => window.plannerApp?.ready && !window.plannerApp.storage.authNeeded);
  await signIn.reload(); await signIn.waitForFunction(() => window.plannerApp?.ready && !window.plannerApp.storage.authNeeded);
  console.log('PASS Вход без ChatGPT и сохранение сессии после перезапуска страницы');
  // Pause the automatic sender, edit the same item from two actual browser clients.
  const id = await signIn.evaluate(async () => {
    const app = window.plannerApp; app.storage.running = true;
    const entry = app.state.entries.find(item => item.title === 'Изменение Windows');
    await app.commit(state => { state.entries.find(item => item.id === entry.id).title = 'Моя офлайн-редакция'; });
    return entry.id;
  });
  const server = await (await context.request.get(origin + '/api/state')).json();
  server.state.entries.find(item => item.id === id).title = 'Правка другого устройства';
  await context.request.put(origin + '/api/state', { data: { revision: server.revision, state: server.state } });
  await signIn.evaluate(async () => { const storage = window.plannerApp.storage; storage.running = false; await storage.sync(); });
  assert.equal(await signIn.evaluate(() => window.plannerApp.storage.conflicts.length), 1);
  await signIn.reload(); await signIn.waitForFunction(() => window.plannerApp?.ready);
  assert.equal(await signIn.evaluate(() => window.plannerApp.storage.conflicts.length), 1);
  const unresolved = await (await context.request.get(origin + '/api/state')).json();
  assert.equal(unresolved.state.entries.find(item => item.id === id).title, 'Правка другого устройства');
  await signIn.evaluate(() => window.plannerApp.storage.resolveConflicts(true));
  const resolved = await (await context.request.get(origin + '/api/state')).json();
  assert.equal(resolved.state.entries.find(item => item.id === id).title, 'Моя офлайн-редакция');
  console.log('PASS Конфликт переживает перезапуск и разрешается только явным выбором');
  await fresh.close();
} finally { await browser.close(); }
