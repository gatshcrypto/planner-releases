const CACHE = 'planner-phone-2';
const SHELL = ['/', '/index.html', '/app.js', '/access.js', '/domain.js', '/views.js', '/forms.js', '/storage.js', '/ui.js', '/calculator.js', '/style.css', '/icon.png', '/landscapes.jpg', '/quotes.json', '/manifest.webmanifest'];
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(SHELL))));
self.addEventListener('activate', event => event.waitUntil((async () => {
  for (const key of await caches.keys()) if (key.startsWith('planner-phone-') && key !== CACHE) await caches.delete(key);
  await self.clients.claim();
})()));
self.addEventListener('message', event => { if (event.data?.type === 'SKIP_WAITING') self.skipWaiting(); });
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin || url.pathname.startsWith('/api/') || event.request.method !== 'GET' ||
    ['/signin-with-chatgpt', '/signout-with-chatgpt', '/callback'].includes(url.pathname)) return;
  event.respondWith((async () => {
    try {
      const response = await fetch(event.request);
      if (response.ok && !response.redirected && SHELL.includes(url.pathname)) {
        const cache = await caches.open(CACHE); await cache.put(url.pathname, response.clone());
      }
      return response;
    } catch {
      return await caches.match(url.pathname) || (event.request.mode === 'navigate' ? await caches.match('/') : Response.error());
    }
  })());
});
self.addEventListener('push', event => event.waitUntil((async () => {
  let payload = { title: 'Планер', body: 'Новое напоминание' };
  try { if (event.data) payload = event.data.json(); } catch { }
  await self.registration.showNotification(payload.title || 'Планер', { body: payload.body || '', icon: '/icon.png', badge: '/icon.png',
    tag: payload.tag || 'planner-reminder', data: { entryId: payload.entryId || null } });
})()));
self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil((async () => {
    const entryId = event.notification.data?.entryId;
    const url = entryId && entryId !== 'pomodoro' ? '/?entry=' + encodeURIComponent(entryId) : '/';
    const windows = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    if (windows.length) { await windows[0].navigate(url); await windows[0].focus(); }
    else await self.clients.openWindow(url);
  })());
});
