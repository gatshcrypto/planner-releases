using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Planner
{
    internal sealed partial class MainWindow
    {
        private IEnumerable<Entry> Order(IEnumerable<Entry> entries)
        {
            return PlannerService.Chronological(entries);
        }

        private void RenderRows(StackPanel host, IEnumerable<Entry> entries, string empty,
            string action = null, Action invoke = null, bool showTaskDate = false)
        {
            var rows = new StackPanel();
            foreach (Entry entry in entries)
            {
                if (rows.Children.Count > 0)
                    rows.Children.Add(new Border { Height = 1, Background = Line, Margin = new Thickness(7, 0, 7, 0) });
                rows.Children.Add(EntryRow(entry, showTaskDate));
            }
            if (rows.Children.Count == 0)
            {
                if (empty != null) Empty(host, empty, action, invoke);
            }
            else
            {
                var frame = Card(rows, new Thickness(6, 2, 6, 2));
                frame.Margin = new Thickness(0, 0, 0, 7);
                host.Children.Add(frame);
            }
        }

        private FrameworkElement EntryRow(Entry entry, bool showTaskDate = false, bool ringProgress = false)
        {
            bool compactWeekTask = section == Section.Week && entry.Kind == EntryKind.Task && !showTaskDate;
            var row = new DockPanel { LastChildFill = true, MinHeight = compactWeekTask ? 37 : 49 };
            Identify(row, "row-" + entry.Id);
            Progress progress = planner.Measure(entry);
            bool canCheck = planner.CanCheck(entry);
            bool marked = entry.Kind == EntryKind.Habit &&
                (entry.Mastered.HasValue || planner.Marks(entry).Contains(planner.Today));
            if (canCheck || (entry.Kind == EntryKind.Habit && !entry.Mastered.HasValue && (!entry.Day.HasValue || entry.Day <= planner.Today)))
            {
                bool done = canCheck ? entry.Kind == EntryKind.Subgoal ? entry.Checked : progress.Complete : marked;
                var toggle = ToggleButton(done, entry.Title, () =>
                {
                    if (entry.Kind == EntryKind.Habit) CheckHabit(entry, !marked);
                    else
                    {
                        ToggleEntry(entry, !done, entry.Kind == EntryKind.Subgoal && modalLayer.Visibility == Visibility.Visible);
                    }
                }, "check-" + entry.Id);
                DockPanel.SetDock(toggle, Dock.Left);
                row.Children.Add(toggle);
            }
            else
            {
                string icon = entry.Kind == EntryKind.Event ? "\uE787" :
                    entry.Kind == EntryKind.Habit ? "\uE73E" :
                    entry.Kind == EntryKind.Subgoal ? "\uE8FD" : "\uECA5";
                var glyph = Glyph(icon, progress.Complete || marked ? accent : Muted);
                glyph.Width = 39;
                DockPanel.SetDock(glyph, Dock.Left);
                row.Children.Add(glyph);
            }

            var trailing = Horizontal();
            trailing.VerticalAlignment = VerticalAlignment.Center;
            trailing.Margin = new Thickness(4, 0, 5, 0);
            if (entry.Kind == EntryKind.Subgoal && ringProgress && planner.Children(entry).Any())
            {
                var ring = Ring(progress, 60, false, "progress-" + entry.Id);
                ring.Margin = new Thickness(0, 2, 5, 2);
                Identify(ring, "subgoal-ring-" + entry.Id);
                trailing.Children.Add(ring);
            }
            else if (entry.Kind == EntryKind.Goal || entry.Kind == EntryKind.Subgoal && !ringProgress && planner.Children(entry).Any())
            {
                string amount = CountText(progress);
                var value = Text(amount, 12, Muted);
                value.Margin = new Thickness(0, 0, 9, 0);
                Identify(value, "progress-" + entry.Id);
                trailing.Children.Add(value);
            }
            if (entry.Kind == EntryKind.Habit && !entry.Mastered.HasValue && (!entry.Day.HasValue || entry.Day <= planner.Today))
            {
                int streak = planner.Streak(entry);
                var value = Text(CountText(new Progress(streak, 63)), 12, Muted);
                value.Margin = new Thickness(0, 0, 9, 0);
                Identify(value, "streak-" + entry.Id, "Серия " + streak + " из 63");
                trailing.Children.Add(value);
            }
            if (entry.Kind != EntryKind.Habit) trailing.Children.Add(PriorityDot(entry));
            if (entry.Kind == EntryKind.Task && !compactWeekTask)
            {
                var move = IconButton("\uE8AB", "Перенести задачу", () => ShowMove(entry.Id), "move-" + entry.Id, "plain");
                move.Width = 32;
                move.Padding = new Thickness(3);
                trailing.Children.Add(move);
            }
            DockPanel.SetDock(trailing, Dock.Right);
            row.Children.Add(trailing);

            var labels = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(3, 3, 0, 3) };
            var title = Button(entry.Title, () => ShowDetails(entry.Id), "open-" + entry.Id);
            title.MinHeight = compactWeekTask ? 21 : 26;
            title.Padding = new Thickness(4, 2, 4, 2);
            title.HorizontalAlignment = HorizontalAlignment.Stretch;
            title.HorizontalContentAlignment = HorizontalAlignment.Left;
            title.ToolTip = entry.Title;
            var titleText = Text(entry.Title, 14, entry.Checked && (entry.Kind == EntryKind.Task || entry.Kind == EntryKind.Subgoal) ? Muted : TextInk, true);
            titleText.TextWrapping = TextWrapping.NoWrap;
            titleText.TextTrimming = TextTrimming.CharacterEllipsis;
            if (progress.Complete && entry.Kind == EntryKind.Task) titleText.TextDecorations = TextDecorations.Strikethrough;
            title.Content = titleText;
            labels.Children.Add(title);
            Entry parent = planner.Find(entry.ParentId);
            if (parent != null && (entry.Kind != EntryKind.Task || section != Section.Week))
            {
                var parentLink = Link(parent.Title, () => ShowDetails(parent.Id), "parent-" + entry.Id);
                var linkText = Text(parent.Title, 12, accent);
                linkText.TextWrapping = TextWrapping.NoWrap;
                linkText.TextTrimming = TextTrimming.CharacterEllipsis;
                parentLink.Content = linkText;
                parentLink.HorizontalAlignment = HorizontalAlignment.Stretch;
                parentLink.HorizontalContentAlignment = HorizontalAlignment.Left;
                parentLink.ToolTip = parent.Title;
                labels.Children.Add(parentLink);
            }
            string metadata = null;
            if (entry.Kind == EntryKind.Habit && entry.Mastered.HasValue) metadata =
                "Освоена " + entry.Mastered.Value.ToString("d MMMM yyyy", CalendarRules.Russian);
            if (entry.Kind == EntryKind.Task)
            {
                if (showTaskDate) metadata = PlannerService.Dates(entry);
                if (entry.Time.HasValue)
                    metadata = (metadata == null ? "" : metadata + "  ·  ") + entry.Time.Value.ToString(@"hh\:mm");
                if (entry.DurationMinutes.HasValue)
                    metadata = (metadata == null ? "" : metadata + "  ·  ") + FormatLoad(entry.DurationMinutes.Value);
            }
            if (entry.Kind == EntryKind.Goal || entry.Kind == EntryKind.Subgoal)
                metadata = PlannerService.Dates(entry);
            if (metadata != null)
            {
                var info = Text(metadata, 12, Muted);
                info.Margin = new Thickness(5, 0, 0, 2);
                labels.Children.Add(info);
            }
            row.Children.Add(labels);
            return row;
        }

        private Button ToggleButton(bool done, string item, Action act, string id)
        {
            var button = IconButton("\uE73E", (done ? "Снять отметку · " : "Отметить · ") + item,
                act, id, "plain");
            button.Width = 32;
            button.Padding = new Thickness(3);
            button.Content = new Border
            {
                Width = 20, Height = 20, BorderBrush = done ? accent : Ink("#B5A89A"), BorderThickness = new Thickness(1),
                Background = done ? accent : CardPaper, CornerRadius = new CornerRadius(6),
                Child = done ? Glyph("\uE73E", White, 12) : null
            };
            button.VerticalAlignment = VerticalAlignment.Center;
            return button;
        }

        private void CheckHabit(Entry entry, bool done)
        {
            bool mastery = planner.SetHabit(entry, done);
            Refresh();
            if (drawerRedraw != null) drawerRedraw();
            if (mastery) NotifyMastery(entry);
        }

        private void ShowSettings()
        {
            var panel = new StackPanel();
            Head(panel, "Оформление");
            panel.Children.Add(StyleOptions());
            panel.Children.Add(Gap(12));
            panel.Children.Add(Button("Архив", ShowArchive, "open-archive", "outline"));
            if (planner.Entries.Any(item => item.Kind == EntryKind.Task || item.Kind == EntryKind.Goal || item.Kind == EntryKind.Subgoal))
            {
                panel.Children.Add(Gap(6));
                panel.Children.Add(Button("Очистить задачи и цели", ConfirmClearPlanning, "clear-planning"));
            }
            AddUpdateSettings(panel);
            panel.Children.Add(Gap(12));
            panel.Children.Add(Button("Синхронизация", ShowSynchronization, "open-synchronization", "outline"));
            OpenDrawer("Настройки", panel, ShowSettings);
        }
    }
}

