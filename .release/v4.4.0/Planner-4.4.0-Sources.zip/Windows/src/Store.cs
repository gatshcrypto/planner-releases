using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace Planner
{
    internal sealed partial class Store : IDisposable
    {
        private const int SchemaVersion = 7;
        private IntPtr db;
        public string DirectoryPath { get; private set; }

        public Store(string path)
        {
            DirectoryPath = Path.GetDirectoryName(path);
            Directory.CreateDirectory(DirectoryPath);
            int result = Native.sqlite3_open_v2(Utf8(path), out db, 6, IntPtr.Zero);
            try
            {
                Check(result);
                Native.sqlite3_busy_timeout(db, 4000);
                Execute("PRAGMA foreign_keys = ON");
                int version = Query("PRAGMA user_version", row => row.Int(0))[0];
                if (version > SchemaVersion)
                    throw new InvalidOperationException("База создана более новой версией планера.");
                if (version > 0 && version < 5) BackupFor(new Version(4, 0, 0));
                if (version > 0 && version < 6) BackupFor(new Version(4, 1, 0));
                if (version > 0 && version < 7) BackupFor(new Version(4, 3, 0));
                if (version < 1) Atomic(() =>
                {
                    Execute(@"CREATE TABLE entries (
                        id TEXT PRIMARY KEY NOT NULL,
                        kind INTEGER NOT NULL CHECK(kind BETWEEN 0 AND 4),
                        title TEXT NOT NULL,
                        priority INTEGER NOT NULL CHECK(priority BETWEEN 0 AND 3),
                        parent TEXT REFERENCES entries(id) ON DELETE CASCADE,
                        day TEXT,
                        period INTEGER CHECK(period BETWEEN 1 AND 3),
                        checked INTEGER NOT NULL CHECK(checked IN (0,1)),
                        notes TEXT NOT NULL,
                        scheduled_time TEXT,
                        mastered TEXT
                    )");
                    Execute("CREATE INDEX entry_parent ON entries(parent)");
                    Execute("CREATE INDEX entry_day ON entries(day)");
                    Execute(@"CREATE TABLE habit_marks (
                        habit TEXT NOT NULL REFERENCES entries(id) ON DELETE CASCADE,
                        day TEXT NOT NULL,
                        PRIMARY KEY(habit, day)
                    )");
                    Execute("CREATE TABLE settings (key TEXT PRIMARY KEY NOT NULL, value TEXT NOT NULL)");
                    Execute("PRAGMA user_version = 1");
                });
                if (version < 2) Atomic(() =>
                {
                    Execute(@"CREATE TABLE board_columns (
                        id TEXT PRIMARY KEY NOT NULL,
                        title TEXT NOT NULL,
                        position INTEGER NOT NULL
                    )");
                    Execute("ALTER TABLE entries ADD COLUMN board_column TEXT REFERENCES board_columns(id) ON DELETE SET NULL");
                    Execute("ALTER TABLE entries ADD COLUMN target_day TEXT");
                    Execute("ALTER TABLE entries ADD COLUMN completed_on TEXT");
                    Execute("UPDATE entries SET day=(SELECT MIN(h.day) FROM habit_marks h WHERE h.habit=entries.id) WHERE kind=3 AND day IS NULL");
                    Execute("PRAGMA user_version = 2");
                });
                if (version < 3) Atomic(() =>
                {
                    Execute("ALTER TABLE entries ADD COLUMN archived_on TEXT");
                    Execute("UPDATE entries SET archived_on=COALESCE(completed_on, date('now','localtime')) WHERE kind=0 AND checked=1");
                    Execute("CREATE INDEX entry_archive ON entries(archived_on)");
                    Execute("PRAGMA user_version = 3");
                });
                if (version < 4) Atomic(() =>
                {
                    Execute("ALTER TABLE entries ADD COLUMN duration_minutes INTEGER CHECK(duration_minutes BETWEEN 1 AND 1440)");
                    Execute("PRAGMA user_version = 4");
                });
                if (version < 5) Atomic(() =>
                {
                    Execute(@"UPDATE entries SET target_day=CASE period
                        WHEN 1 THEN date(day,'+6 days')
                        WHEN 2 THEN date(day,'start of month','+1 month','-1 day')
                        WHEN 3 THEN date(day,'start of year','+1 year','-1 day') END WHERE kind=1");
                    Execute("UPDATE entries SET day=NULL WHERE kind=2 AND target_day IS NULL");
                    Execute("PRAGMA user_version = 5");
                });
                if (version < 6) Atomic(() =>
                {
                    Execute("UPDATE entries SET archived_on=completed_on WHERE kind=2 AND checked=1 AND completed_on IS NOT NULL");
                    Execute("INSERT OR IGNORE INTO settings(key,value) VALUES ('completion_tracking_since',date('now','localtime'))");
                    Execute("PRAGMA user_version = 6");
                });
                if (version < 7) MigrateFinance();
            }
            catch
            {
                Dispose();
                throw;
            }
        }

        public List<Entry> ReadEntries()
        {
            return Query("SELECT id, kind, title, priority, parent, day, period, checked, notes, scheduled_time, mastered, board_column, target_day, completed_on, archived_on, duration_minutes, rowid FROM entries",
                row => new Entry
                {
                    Id = row.String(0), Kind = (EntryKind)row.Int(1), Title = row.String(2),
                    Priority = row.Int(3), ParentId = row.String(4), Day = ReadDate(row.String(5)),
                    Period = row.IsNull(6) ? (Period?)null : (Period)row.Int(6),
                    Checked = row.Int(7) == 1, Notes = row.String(8), Time = ReadTime(row.String(9)),
                    Mastered = ReadDate(row.String(10)), BoardColumn = row.String(11),
                    TargetDay = ReadDate(row.String(12)), CompletedOn = ReadDate(row.String(13)), ArchivedOn = ReadDate(row.String(14)), DurationMinutes = row.IsNull(15) ? (int?)null : row.Int(15),
                    CreationOrder = Int64.Parse(row.String(16), CultureInfo.InvariantCulture)
                });
        }

        public void BackupFor(Version version)
        {
            string folder = Path.Combine(DirectoryPath, "Backups");
            string destination = Path.Combine(folder, "planner-before-" + version.ToString(3) + ".sqlite");
            if (File.Exists(destination)) return;
            Directory.CreateDirectory(folder);
            string temporary = destination + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                Execute("VACUUM INTO ?", temporary);
                File.Move(temporary, destination);
            }
            finally
            {
                File.Delete(temporary);
            }
        }

        public string BackupBeforeSync()
        {
            string folder = Path.Combine(DirectoryPath, "Backups");
            Directory.CreateDirectory(folder);
            string destination = Path.Combine(folder, "planner-before-sync-" + DateTime.Now.ToString("yyyyMMdd-HHmmss", CultureInfo.InvariantCulture) + "-" + Guid.NewGuid().ToString("N").Substring(0, 8) + ".sqlite");
            Execute("VACUUM INTO ?", destination);
            return destination;
        }

        public List<HabitMark> ReadMarks()
        {
            return Query("SELECT habit, day FROM habit_marks",
                row => new HabitMark { Id = row.String(0), Day = ReadDate(row.String(1)).Value });
        }

        public void Save(Entry entry)
        {
            Execute(@"INSERT INTO entries(id, kind, title, priority, parent, day, period, checked, notes, scheduled_time, mastered,
                        board_column, target_day, completed_on, archived_on, duration_minutes)
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                      ON CONFLICT(id) DO UPDATE SET title=excluded.title, priority=excluded.priority,
                      parent=excluded.parent, day=excluded.day, period=excluded.period, checked=excluded.checked,
                      notes=excluded.notes, scheduled_time=excluded.scheduled_time, mastered=excluded.mastered,
                      board_column=excluded.board_column, target_day=excluded.target_day, completed_on=excluded.completed_on, archived_on=excluded.archived_on, duration_minutes=excluded.duration_minutes",
                entry.Id, (int)entry.Kind, entry.Title, entry.Priority, entry.ParentId, Date(entry.Day),
                (int?)entry.Period, entry.Checked ? 1 : 0, entry.Notes,
                entry.Time.HasValue ? entry.Time.Value.ToString(@"hh\:mm", CultureInfo.InvariantCulture) : null,
                Date(entry.Mastered), entry.BoardColumn, Date(entry.TargetDay), Date(entry.CompletedOn), Date(entry.ArchivedOn), entry.DurationMinutes);
        }

        public void ClearPlanning()
        {
            Execute("DELETE FROM entries WHERE kind IN (0,1,2)");
        }

        public void DateUndatedOpenTasks(DateTime day)
        {
            Execute("UPDATE entries SET day=? WHERE kind=0 AND checked=0 AND day IS NULL", Date(day));
        }

        public void ExpireArchive(DateTime cutoff)
        {
            Execute(@"UPDATE entries SET title='', notes='', scheduled_time=NULL, archived_on=NULL
                      WHERE kind=0 AND checked=1 AND archived_on<=?", Date(cutoff));
            Execute("UPDATE entries SET notes='', archived_on=NULL WHERE kind=2 AND checked=1 AND archived_on<=?", Date(cutoff));
        }

        public void ClearArchive(string id)
        {
            if (id == null)
            {
                Execute("UPDATE entries SET title='', notes='', scheduled_time=NULL, archived_on=NULL WHERE kind=0 AND checked=1 AND archived_on IS NOT NULL");
                Execute("UPDATE entries SET notes='', archived_on=NULL WHERE kind=2 AND checked=1 AND archived_on IS NOT NULL");
            }
            else
            {
                Execute("UPDATE entries SET title='', notes='', scheduled_time=NULL, archived_on=NULL WHERE id=? AND kind=0 AND checked=1 AND archived_on IS NOT NULL", id);
                Execute("UPDATE entries SET notes='', archived_on=NULL WHERE id=? AND kind=2 AND checked=1 AND archived_on IS NOT NULL", id);
            }
        }

        public List<BoardColumn> ReadColumns()
        {
            return Query("SELECT id, title, position FROM board_columns ORDER BY position, id",
                row => new BoardColumn { Id = row.String(0), Title = row.String(1), Position = row.Int(2) });
        }

        public void SaveColumn(BoardColumn column)
        {
            Execute(@"INSERT INTO board_columns(id, title, position) VALUES (?, ?, ?)
                      ON CONFLICT(id) DO UPDATE SET title=excluded.title, position=excluded.position",
                column.Id, column.Title, column.Position);
        }

        public void DeleteColumn(string id) { Execute("DELETE FROM board_columns WHERE id=?", id); }

        public void Delete(string id) { Execute("DELETE FROM entries WHERE id=?", id); }

        public void SetMark(string id, DateTime day, bool done)
        {
            Execute(done ? "INSERT OR IGNORE INTO habit_marks(habit, day) VALUES (?, ?)" :
                "DELETE FROM habit_marks WHERE habit=? AND day=?", id, Date(day));
        }

        public string Setting(string key, string fallback)
        {
            List<string> values = Query("SELECT value FROM settings WHERE key=?", row => row.String(0), key);
            return values.Count == 0 ? fallback : values[0];
        }

        public void SetSetting(string key, string value)
        {
            Execute("INSERT OR REPLACE INTO settings(key, value) VALUES (?, ?)", key, value);
        }

        public void Atomic(Action action)
        {
            Execute("BEGIN IMMEDIATE");
            try
            {
                action();
                Execute("COMMIT");
            }
            catch
            {
                Execute("ROLLBACK");
                throw;
            }
        }

        private static string Date(DateTime? day)
        {
            return day.HasValue ? day.Value.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) : null;
        }

        private static DateTime? ReadDate(string value)
        {
            return value == null ? (DateTime?)null : DateTime.ParseExact(value, "yyyy-MM-dd", CultureInfo.InvariantCulture);
        }

        private static TimeSpan? ReadTime(string value)
        {
            return value == null ? (TimeSpan?)null : TimeSpan.ParseExact(value, @"hh\:mm", CultureInfo.InvariantCulture);
        }

        private static byte[] Utf8(string value) { return Encoding.UTF8.GetBytes(value + "\0"); }

        private void Check(int code)
        {
            if (code == 0) return;
            string details = db == IntPtr.Zero ? "SQLite " + code : Marshal.PtrToStringUni(Native.sqlite3_errmsg16(db));
            throw new IOException("Хранилище планера недоступно. " + details);
        }

        private void Execute(string sql, params object[] args)
        {
            Query<object>(sql, null, args);
        }

        private List<T> Query<T>(string sql, Func<Row, T> convert, params object[] args)
        {
            IntPtr statement;
            Check(Native.sqlite3_prepare_v2(db, Utf8(sql), -1, out statement, IntPtr.Zero));
            try
            {
                for (int i = 0; i < args.Length; i++)
                {
                    object value = args[i];
                    if (value == null) Check(Native.sqlite3_bind_null(statement, i + 1));
                    else if (value is int) Check(Native.sqlite3_bind_int(statement, i + 1, (int)value));
                    else Check(Native.sqlite3_bind_text(statement, i + 1, Utf8((string)value), -1, new IntPtr(-1)));
                }
                var result = new List<T>();
                int state;
                while ((state = Native.sqlite3_step(statement)) == 100)
                    if (convert != null) result.Add(convert(new Row(statement)));
                if (state != 101) Check(state);
                return result;
            }
            finally { Native.sqlite3_finalize(statement); }
        }

        public void Dispose()
        {
            if (db != IntPtr.Zero)
            {
                Native.sqlite3_close(db);
                db = IntPtr.Zero;
            }
        }

        private struct Row
        {
            private readonly IntPtr statement;
            public Row(IntPtr statement) { this.statement = statement; }
            public int Int(int column) { return Native.sqlite3_column_int(statement, column); }
            public bool IsNull(int column) { return Native.sqlite3_column_type(statement, column) == 5; }
            public string String(int column)
            {
                return IsNull(column) ? null : Marshal.PtrToStringUni(Native.sqlite3_column_text16(statement, column),
                    Native.sqlite3_column_bytes16(statement, column) / 2);
            }
        }

        private static class Native
        {
            private const string Sqlite = "winsqlite3.dll";
            [DllImport(Sqlite, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_open_v2(byte[] path, out IntPtr db, int flags, IntPtr vfs);
            [DllImport(Sqlite, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_close(IntPtr db);
            [DllImport(Sqlite, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_busy_timeout(IntPtr db, int timeout);
            [DllImport(Sqlite, CallingConvention = CallingConvention.Cdecl)] internal static extern IntPtr sqlite3_errmsg16(IntPtr db);
            [DllImport(Sqlite, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_prepare_v2(IntPtr db, byte[] sql, int size, out IntPtr statement, IntPtr tail);
            [DllImport(Sqlite, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_finalize(IntPtr statement);
            [DllImport(Sqlite, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_step(IntPtr statement);
            [DllImport(Sqlite, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_bind_null(IntPtr statement, int index);
            [DllImport(Sqlite, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_bind_int(IntPtr statement, int index, int value);
            [DllImport(Sqlite, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_bind_text(IntPtr statement, int index, byte[] value, int size, IntPtr destructor);
            [DllImport(Sqlite, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_column_type(IntPtr statement, int column);
            [DllImport(Sqlite, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_column_int(IntPtr statement, int column);
            [DllImport(Sqlite, CallingConvention = CallingConvention.Cdecl)] internal static extern IntPtr sqlite3_column_text16(IntPtr statement, int column);
            [DllImport(Sqlite, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_column_bytes16(IntPtr statement, int column);
        }
    }
}

