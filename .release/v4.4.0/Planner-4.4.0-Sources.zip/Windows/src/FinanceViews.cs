using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Planner
{
    internal sealed partial class MainWindow
    {
        private DateTime financeDate;
        private bool financeYear;
        private static readonly Brush FinanceIncome = Ink("#2562A3");
        private static readonly Brush FinanceExpense = Ink("#C44449");
        private static readonly string[] FinanceColors = { "#538B78", "#5485AF", "#B9774E", "#9971A5", "#B29142", "#C46A79", "#659DA1", "#8C9562" };

        private DateRange FinanceRange()
        {
            return CalendarRules.Range(financeYear ? Period.Year : Period.Month, financeDate);
        }

        private Grid FinanceMetrics(string[] labels, decimal[] amounts, string prefix, bool signedLast)
        {
            var grid = new Grid { Margin = new Thickness(0, 0, 0, 18) };
            for (int i = 0; i < labels.Length; i++)
            {
                grid.ColumnDefinitions.Add(new ColumnDefinition());
                var body = new StackPanel();
                bool last = i == labels.Length - 1;
                body.Children.Add(Text(labels[i], 12, last ? SoftWhite : Muted, true));
                var value = Text((last && signedLast && amounts[i] > 0 ? "+" : "") + Money.Format(amounts[i]),
                    29, last ? White : i == 0 ? FinanceIncome : FinanceExpense, true);
                value.TextWrapping = TextWrapping.NoWrap;
                Identify(value, prefix + "-" + i);
                body.Children.Add(new Viewbox { Child = value, Stretch = Stretch.Uniform,
                    StretchDirection = StretchDirection.DownOnly, HorizontalAlignment = HorizontalAlignment.Left,
                    Height = 40, Margin = new Thickness(0, 9, 0, 0) });
                var card = DashboardCard(body);
                card.MinHeight = 112;
                if (last) card.Background = Ink(currentStyle.Dark);
                card.Margin = new Thickness(i == 0 ? 0 : 5, 0, last ? 0 : 5, 0);
                Grid.SetColumn(card, i);
                grid.Children.Add(card);
            }
            return grid;
        }

        private void RenderFinance()
        {
            var operations = finance.ForPeriod(FinanceRange()).ToList();
            var totals = new FinanceTotals(operations);
            content.Children.Add(FinanceMetrics(new[] { "Доход", "Расход", "Итог" },
                new[] { totals.Income, totals.Expense, totals.Net }, "finance-total", true));
            content.Children.Add(FinanceNavigation(true));
            if (financeYear)
            {
                var list = new StackPanel();
                foreach (int month in Enumerable.Range(1, 12).Reverse())
                {
                    DateTime selected = new DateTime(financeDate.Year, month, 1);
                    var monthly = new FinanceTotals(operations.Where(item => item.Day.Month == month));
                    var row = FinanceAmountRow(CalendarRules.Capital(selected.ToString("MMMM", CalendarRules.Russian)), monthly,
                        "finance-month-" + month, 92);
                    var button = Button("Открыть " + selected.ToString("MMMM yyyy", CalendarRules.Russian), () =>
                    {
                        financeDate = selected;
                        financeYear = false;
                        Refresh(false);
                    }, "finance-open-month-" + month);
                    button.HorizontalContentAlignment = HorizontalAlignment.Stretch;
                    button.Padding = new Thickness(15, 15, 15, 15);
                    button.Content = row;
                    list.Children.Add(button);
                    if (month > 1) list.Children.Add(Rule());
                }
                content.Children.Add(DashboardCard(list));
                return;
            }
            if (operations.Count == 0)
            {
                var empty = new StackPanel();
                Empty(empty, "За этот месяц операций нет", "Добавить операцию", BeginCreate);
                content.Children.Add(DashboardCard(empty));
                return;
            }
            foreach (var group in operations.GroupBy(item => item.Day))
            {
                var day = new StackPanel();
                DateTime date = group.Key;
                var heading = FinanceAmountRow(date.ToString("dd MMM · ddd", CalendarRules.Russian),
                    new FinanceTotals(group), "finance-day-" + date.ToString("yyyyMMdd"), 108);
                heading.Margin = new Thickness(4, 0, 4, 12);
                day.Children.Add(heading);
                day.Children.Add(Rule());
                foreach (var operation in group) day.Children.Add(FinanceOperationRow(operation));
                var card = DashboardCard(day);
                card.Margin = new Thickness(0, 0, 0, 12);
                content.Children.Add(card);
            }
        }

        private Grid FinanceAmountRow(string title, FinanceTotals totals, string id, double titleWidth)
        {
            var row = new Grid();
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(titleWidth) });
            var name = Text(title, 14, TextInk, true);
            Identify(name, id);
            row.Children.Add(name);
            string[] labels = { "Доход", "Расход", "Итог" };
            decimal[] amounts = { totals.Income, totals.Expense, totals.Net };
            for (int i = 0; i < 3; i++)
            {
                row.ColumnDefinitions.Add(new ColumnDefinition());
                var stack = new StackPanel { Margin = new Thickness(6, 0, 0, 0) };
                stack.Children.Add(Text(labels[i], 10, Muted));
                var amount = Text(Money.Format(amounts[i]), 14, i == 0 ? FinanceIncome : i == 1 ? FinanceExpense : TextInk, true);
                Identify(amount, id + "-" + i);
                amount.TextWrapping = TextWrapping.NoWrap;
                stack.Children.Add(new Viewbox { Child = amount, StretchDirection = StretchDirection.DownOnly,
                    HorizontalAlignment = HorizontalAlignment.Left, Height = 24 });
                Grid.SetColumn(stack, i + 1);
                row.Children.Add(stack);
            }
            return row;
        }

        private UIElement FinanceNavigation(bool management)
        {
            var panel = new StackPanel { Margin = new Thickness(0, 0, 0, 17) };
            var navigation = new DockPanel { LastChildFill = true };
            var arrows = Horizontal();
            var previous = IconButton("\uE76B", "Предыдущий период", () => ShiftFinance(-1), "finance-prev", "plain");
            previous.IsEnabled = financeDate.Year > 2;
            var next = IconButton("\uE76C", "Следующий период", () => ShiftFinance(1), "finance-next", "plain");
            next.IsEnabled = financeDate.Year < 9998;
            arrows.Children.Add(previous);
            arrows.Children.Add(next);
            arrows.Children.Add(Button("Сейчас", () => { financeDate = planner.Today; Refresh(false); }, "finance-now"));
            DockPanel.SetDock(arrows, Dock.Right);
            navigation.Children.Add(arrows);
            var label = Text(financeYear ? financeDate.Year.ToString() : CalendarRules.Label(Period.Month, financeDate), 20, TextInk, true);
            Identify(label, "finance-period");
            navigation.Children.Add(label);
            panel.Children.Add(navigation);
            var controls = new WrapPanel { Margin = new Thickness(0, 8, 0, 0) };
            controls.Children.Add(Button("Месяц", () => { financeYear = false; Refresh(false); }, "finance-mode-month", financeYear ? "plain" : "selected"));
            controls.Children.Add(Button("Год", () => { financeYear = true; Refresh(false); }, "finance-mode-year", financeYear ? "selected" : "plain"));
            if (management)
            {
                var accounts = Button("Счета", () => ShowFinanceAccounts(), "finance-accounts", "outline");
                accounts.Margin = new Thickness(12, 0, 5, 0);
                controls.Children.Add(accounts);
                controls.Children.Add(Button("Категории", () => ShowFinanceCategories(), "finance-categories", "outline"));
            }
            panel.Children.Add(controls);
            return panel;
        }

        private void ShiftFinance(int direction)
        {
            financeDate = financeYear ? financeDate.AddYears(direction) : financeDate.AddMonths(direction);
            Refresh(false);
        }

        private Button FinanceOperationRow(FinanceOperation operation)
        {
            var account = finance.Accounts.Single(item => item.Id == operation.AccountId);
            var category = finance.Categories.FirstOrDefault(item => item.Id == operation.CategoryId);
            bool transfer = operation.Kind == FinanceKind.Transfer;
            var row = new Grid();
            row.ColumnDefinitions.Add(new ColumnDefinition());
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var body = new StackPanel();
            var title = Text(transfer ? "Перевод" : category.Name, 14, TextInk, true);
            title.TextWrapping = TextWrapping.NoWrap;
            title.TextTrimming = TextTrimming.CharacterEllipsis;
            title.ToolTip = title.Text;
            body.Children.Add(title);
            string detail = account.Name;
            if (transfer) detail += " → " + finance.Accounts.Single(item => item.Id == operation.DestinationId).Name;
            if (operation.Notes.Length > 0) detail += " · " + operation.Notes.Replace('\n', ' ').Replace('\r', ' ');
            var note = Text(detail, 12, Muted);
            note.TextWrapping = TextWrapping.NoWrap;
            note.TextTrimming = TextTrimming.CharacterEllipsis;
            note.ToolTip = detail;
            body.Children.Add(note);
            row.Children.Add(body);
            Brush color = transfer ? Muted : operation.Kind == FinanceKind.Income ? FinanceIncome : FinanceExpense;
            var amount = Text(Money.Format(operation.Amount), 15, color, true);
            amount.Margin = new Thickness(14, 0, 0, 0);
            amount.TextWrapping = TextWrapping.NoWrap;
            Grid.SetColumn(amount, 1);
            row.Children.Add(amount);
            var button = Button("Открыть операцию", () => ShowFinanceOperation(operation.Copy()), "finance-op-" + operation.Id);
            button.Content = row;
            button.HorizontalContentAlignment = HorizontalAlignment.Stretch;
            button.Padding = new Thickness(4, 12, 4, 12);
            return button;
        }

        private void RenderFinanceSummary()
        {
            var balances = finance.Accounts.ToDictionary(item => item.Id, item => finance.Balance(item));
            decimal assets = balances.Values.Where(value => value > 0).Sum();
            decimal liabilities = -balances.Values.Where(value => value < 0).Sum();
            content.Children.Add(FinanceMetrics(new[] { "Активы", "Пассивы", "Итог" },
                new[] { assets, liabilities, assets - liabilities }, "finance-balance", false));
            var accounts = new StackPanel();
            var heading = new DockPanel();
            var manage = Button("Счета", () => ShowFinanceAccounts(), "finance-accounts", "outline");
            DockPanel.SetDock(manage, Dock.Right);
            heading.Children.Add(manage);
            heading.Children.Add(Text("Остатки на счетах", 18, TextInk, true));
            accounts.Children.Add(heading);
            if (finance.Accounts.Count == 0) Empty(accounts, "Счетов пока нет", "Создать счёт", () => ShowFinanceAccount(new FinanceAccount()));
            foreach (var account in finance.Accounts)
            {
                var current = account;
                var row = new DockPanel { LastChildFill = true };
                decimal value = balances[account.Id];
                var amount = Text(Money.Format(value), 16, value < 0 ? FinanceExpense : TextInk, true);
                DockPanel.SetDock(amount, Dock.Right);
                row.Children.Add(amount);
                row.Children.Add(Text(account.Name + (account.Archived ? " · архив" : ""), 14));
                var button = Button(account.Name, () => ShowFinanceAccount(current.Copy()), "finance-account-" + account.Id);
                button.Content = row;
                button.HorizontalContentAlignment = HorizontalAlignment.Stretch;
                button.Padding = new Thickness(0, 12, 0, 12);
                accounts.Children.Add(button);
            }
            content.Children.Add(DashboardCard(accounts));
            content.Children.Add(Gap(21));
            content.Children.Add(FinanceNavigation(false));
            content.Children.Add(Pair(FinanceCategoryChart(FinanceKind.Expense), FinanceCategoryChart(FinanceKind.Income)));
        }

        private sealed class FinanceSlice
        {
            public string Id, Name;
            public decimal Amount;
            public Brush Color;
        }

        private Brush FinanceCategoryColor(string id)
        {
            uint hash = 0;
            foreach (char character in id) hash = unchecked(hash * 31 + character);
            return Ink(FinanceColors[hash % FinanceColors.Length]);
        }

        private Border FinanceCategoryChart(FinanceKind kind)
        {
            var operations = finance.ForPeriod(FinanceRange()).Where(item => item.Kind == kind).ToList();
            var slices = operations.GroupBy(item => item.CategoryId).Select(group => new FinanceSlice
            {
                Id = group.Key, Name = finance.Categories.Single(item => item.Id == group.Key).Name,
                Amount = group.Sum(item => (decimal)item.Amount), Color = FinanceCategoryColor(group.Key)
            }).OrderByDescending(item => item.Amount).ThenBy(item => item.Name).ToList();
            decimal total = slices.Sum(item => item.Amount);
            var body = new StackPanel();
            body.Children.Add(Text(kind == FinanceKind.Expense ? "Расходы по категориям" : "Доходы по категориям", 17, TextInk, true));
            var chart = new Grid { Width = 206, Height = 206, Margin = new Thickness(0, 18, 0, 18) };
            chart.Children.Add(new Ellipse { Stroke = Line, StrokeThickness = 21, Margin = new Thickness(4.5) });
            var displayed = slices.Take(7).ToList();
            if (slices.Count > 7) displayed.Add(new FinanceSlice { Name = "Остальные", Amount = slices.Skip(7).Sum(item => item.Amount), Color = Muted });
            var usedColors = new HashSet<string>();
            foreach (var slice in displayed.Where(item => item.Id != null))
            {
                int index = Array.FindIndex(FinanceColors, value => Ink(value).ToString() == slice.Color.ToString());
                while (usedColors.Contains(FinanceColors[index])) index = (index + 1) % FinanceColors.Length;
                usedColors.Add(FinanceColors[index]);
                slice.Color = Ink(FinanceColors[index]);
            }
            double angle = -90;
            foreach (var slice in displayed)
            {
                double sweep = (double)(slice.Amount / total) * 360;
                if (sweep > .02)
                {
                    double drawn = Math.Min(sweep, 359.99);
                    var geometry = new StreamGeometry();
                    using (var drawing = geometry.Open())
                    {
                        drawing.BeginFigure(FinanceCirclePoint(angle), false, false);
                        drawing.ArcTo(FinanceCirclePoint(angle + drawn), new Size(88, 88), 0, drawn > 180,
                            SweepDirection.Clockwise, true, false);
                    }
                    geometry.Freeze();
                    chart.Children.Add(new Path { Data = geometry, Stroke = slice.Color, StrokeThickness = 21,
                        ToolTip = slice.Name + " · " + Money.Format(slice.Amount) });
                }
                angle += sweep;
            }
            var center = new StackPanel { VerticalAlignment = VerticalAlignment.Center, HorizontalAlignment = HorizontalAlignment.Center, MaxWidth = 141 };
            center.Children.Add(Text(total == 0 ? "Нет операций" : kind == FinanceKind.Expense ? "Расход" : "Доход", 12, Muted));
            if (total > 0)
            {
                var amount = Text(Money.Format(total), 19, TextInk, true);
                amount.TextWrapping = TextWrapping.NoWrap;
                center.Children.Add(new Viewbox { Child = amount, StretchDirection = StretchDirection.DownOnly, Height = 32 });
            }
            chart.Children.Add(center);
            Identify(chart, "finance-chart-" + kind);
            body.Children.Add(chart);
            foreach (var slice in displayed)
            {
                var selected = slice;
                var row = new Grid();
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(13) });
                row.ColumnDefinitions.Add(new ColumnDefinition());
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                row.Children.Add(new Ellipse { Width = 7, Height = 7, Fill = slice.Color, HorizontalAlignment = HorizontalAlignment.Left });
                decimal percentage = 100m * slice.Amount / total;
                string percent = percentage < .1m ? "<0,1%" : percentage.ToString("0.#", CalendarRules.Russian) + "%";
                var name = Text(slice.Name + " · " + percent, 12);
                name.TextWrapping = TextWrapping.NoWrap;
                name.TextTrimming = TextTrimming.CharacterEllipsis;
                name.ToolTip = slice.Name;
                Grid.SetColumn(name, 1);
                row.Children.Add(name);
                var amount = Text(Money.Format(slice.Amount), 12, TextInk, true);
                amount.Margin = new Thickness(7, 0, 0, 0);
                Grid.SetColumn(amount, 2);
                row.Children.Add(amount);
                var button = Button(slice.Name, () => ShowFinanceCategoryHistory(kind, selected.Id),
                    "finance-category-history-" + (slice.Id ?? "other-" + kind));
                button.HorizontalContentAlignment = HorizontalAlignment.Stretch;
                button.Padding = new Thickness(0, 8, 0, 8);
                button.Content = row;
                body.Children.Add(button);
            }
            return DashboardCard(body);
        }

        private static Point FinanceCirclePoint(double degrees)
        {
            double radians = degrees * Math.PI / 180;
            return new Point(103 + 88 * Math.Cos(radians), 103 + 88 * Math.Sin(radians));
        }

        private void ShowFinanceCategoryHistory(FinanceKind kind, string categoryId)
        {
            var body = new StackPanel();
            var operations = finance.ForPeriod(FinanceRange()).Where(item => item.Kind == kind).ToList();
            var leading = new HashSet<string>(operations.GroupBy(item => item.CategoryId).OrderByDescending(group =>
                group.Sum(item => (decimal)item.Amount)).ThenBy(group => finance.Categories.Single(item => item.Id == group.Key).Name)
                .Take(7).Select(group => group.Key));
            foreach (var day in operations.Where(item => categoryId == null ? !leading.Contains(item.CategoryId) : item.CategoryId == categoryId)
                .GroupBy(item => item.Day))
            {
                body.Children.Add(Text(day.Key.ToString("dd MMMM yyyy", CalendarRules.Russian), 12, Muted, true));
                foreach (var operation in day) body.Children.Add(FinanceOperationRow(operation));
                body.Children.Add(Gap(10));
            }
            OpenDrawer(categoryId == null ? "Остальные категории" : finance.Categories.Single(item => item.Id == categoryId).Name, body);
        }
    }
}
