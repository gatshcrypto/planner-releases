using System;
using System.Linq;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace Planner
{
    internal sealed partial class MainWindow : Window
    {
        private readonly Store store;
        private readonly PlannerService planner;
        private readonly FinanceService finance;
        private readonly bool testing;
        private readonly DispatcherTimer timer;
        private Grid shell, workspace, modalLayer;
        private Border drawer, noticeBox;
        private ScrollViewer boardScroller;
        private ScrollViewer scroller;
        private StackPanel rail, content, header, noticeHost;
        private Section section = Section.Tasks;
        private DateTime anchor, eventDate, lastToday;
        private bool eventInitialized;
        private string shownUpcomingEvent;
        private Action submit;
        private Action drawerRedraw;
        private System.Windows.Forms.NotifyIcon notifier;
        private int masteryNotices;

        public MainWindow(Store store, PlannerService planner, bool testing)
        {
            this.store = store;
            this.planner = planner;
            finance = new FinanceService(store, () => planner.Today);
            financeDate = planner.Today;
            this.testing = testing;
            anchor = eventDate = lastToday = planner.Today;
            Title = "Планер";
            using (var logo = typeof(MainWindow).Assembly.GetManifestResourceStream("Planner.Logo"))
                Icon = BitmapFrame.Create(logo, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad);
            Width = 1240;
            Height = 805;
            MinWidth = 715;
            MinHeight = 470;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            UseLayoutRounding = true;
            FontFamily = BodyFont;
            SetColors();
            SetSharedStyles();
            InitializePomodoro();
            InitializeUpdates();
            BuildShell();
            Refresh(false);
            RefreshPomodoro();
            InitializeSynchronization();
            PreviewKeyDown += OnKey;
            SizeChanged += (sender, e) => ResizeDrawer();
            timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(15) };
            timer.Tick += (sender, e) => CheckDateChange();
            timer.Start();
            Closed += (sender, e) =>
            {
                StopQuoteIntro();
                timer.Stop();
                if (synchronizationTimer != null) synchronizationTimer.Stop();
                if (synchronization != null) synchronization.Dispose();
                if (phonePublisher != null) phonePublisher.Cancel();
                pomodoroTick.Stop();
                pomodoroSound.Dispose();
                if (notifier != null) notifier.Dispose();
            };
        }

        private void BuildShell()
        {
            shell = new Grid { Background = Paper };
            shell.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(192) });
            shell.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            var side = new DockPanel { LastChildFill = true, Margin = new Thickness(14, 19, 14, 12) };
            var brand = Horizontal();
            brand.Margin = new Thickness(8, 13, 0, 26);
            var emblem = new Image { Source = Icon, Width = 39, Height = 39, Margin = new Thickness(0, 0, 9, 0),
                VerticalAlignment = VerticalAlignment.Center, IsHitTestVisible = false };
            Identify(emblem, "planner-logo");
            brand.Children.Add(emblem);
            var brandName = Display("Планер", 29);
            brandName.VerticalAlignment = VerticalAlignment.Center;
            brand.Children.Add(brandName);
            DockPanel.SetDock(brand, Dock.Top);
            side.Children.Add(brand);
            var settings = Button("Настройки", ShowSettings, "settings");
            settings.Content = RailLabel("\uE713", "Настройки", false);
            settings.HorizontalContentAlignment = HorizontalAlignment.Left;
            DockPanel.SetDock(settings, Dock.Bottom);
            side.Children.Add(settings);
            var focus = PomodoroButton();
            DockPanel.SetDock(focus, Dock.Bottom);
            side.Children.Add(focus);
            updateButton = Button("Обновить", RunUpdateAction, "update-planner", "primary");
            updateButton.Margin = new Thickness(0, 0, 0, 7);
            DockPanel.SetDock(updateButton, Dock.Bottom);
            side.Children.Add(updateButton);
            RefreshUpdateControls();
            rail = new StackPanel();
            var sideScroll = new ScrollViewer { Content = rail, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
            side.Children.Add(sideScroll);
            shell.Children.Add(new Border { Child = side, Background = SidePaper, BorderBrush = Line, BorderThickness = new Thickness(0, 0, 1, 0) });

            workspace = new Grid { ClipToBounds = true };
            workspace.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            Grid.SetColumn(workspace, 1);
            shell.Children.Add(workspace);
            var view = new DockPanel { LastChildFill = true, Margin = new Thickness(29, 20, 29, 13) };
            header = new StackPanel();
            DockPanel.SetDock(header, Dock.Top);
            view.Children.Add(header);
            if (noticeHost == null) noticeHost = new StackPanel { Margin = new Thickness(0, 5, 0, 0) };
            DockPanel.SetDock(noticeHost, Dock.Bottom);
            view.Children.Add(noticeHost);
            content = new StackPanel { Margin = new Thickness(0, 0, 5, 10) };
            scroller = new ScrollViewer { Content = content, VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled };
            Identify(scroller, "main-scroll");
            scroller.ScrollChanged += (sender, e) =>
            {
                if (e.OriginalSource == scroller && updateWeekHeader != null) updateWeekHeader();
            };
            view.Children.Add(scroller);
            workspace.Children.Add(view);
            modalLayer = new Grid { Background = Ink("#A524201F"), Visibility = Visibility.Collapsed };
            Grid.SetColumnSpan(modalLayer, 2);
            Panel.SetZIndex(modalLayer, 20);
            drawer = new Border
            {
                Background = CardPaper, BorderBrush = Line, BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(18), HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center, Width = 528, Visibility = Visibility.Collapsed,
                Effect = new DropShadowEffect { BlurRadius = 30, ShadowDepth = 8, Direction = 270, Opacity = .2 }
            };
            modalLayer.Children.Add(drawer);
            shell.Children.Add(modalLayer);
            Content = shell;
        }

        private StackPanel RailLabel(string glyph, string label, bool active)
        {
            StackPanel row = Horizontal();
            Brush color = active ? accent : TextInk;
            var icon = Glyph(glyph, color, 15);
            icon.Width = 20;
            icon.Margin = new Thickness(0, 0, 10, 0);
            row.Children.Add(icon);
            row.Children.Add(Text(label, 14, color, active));
            return row;
        }

        private void ResizeDrawer()
        {
            drawer.Width = Math.Min(550, Math.Max(390, ActualWidth - 62));
            drawer.MaxHeight = Math.Max(290, ActualHeight - 105);
        }

        private void Refresh(bool preserve = true)
        {
            double offset = preserve ? scroller.VerticalOffset : 0;
            double horizontalOffset = preserve && boardScroller != null ? boardScroller.HorizontalOffset : 0;
            boardScroller = null;
            updateWeekHeader = null;
            var focused = Keyboard.FocusedElement as DependencyObject;
            string focusId = preserve && focused != null ? AutomationProperties.GetAutomationId(focused) : null;
            rail.Children.Clear();
            for (int i = 0; i < SectionNames.Length; i++)
            {
                Section target = (Section)i;
                if (i == 3 || i == 5 || i == 7) rail.Children.Add(Rule());
                var item = Button(SectionNames[i], () => Navigate(target), "nav-" + target,
                    target == section ? "selected" : "plain");
                item.Margin = new Thickness(0, 1, 0, 1);
                item.MinHeight = 42;
                item.HorizontalContentAlignment = HorizontalAlignment.Left;
                item.Content = RailLabel(SectionIcons[i], SectionNames[i], target == section);
                if (target == Section.Finance || target == Section.FinanceSummary)
                {
                    item.Padding = new Thickness(5, 5, 5, 5);
                    ((TextBlock)((StackPanel)item.Content).Children[1]).FontSize = 13;
                }
                rail.Children.Add(item);
            }
            RenderHeader();
            content.Children.Clear();
            switch (section)
            {
                case Section.Tasks: RenderEntities(EntryKind.Task); break;
                case Section.Subgoals: RenderEntities(EntryKind.Subgoal); break;
                case Section.Goals: RenderEntities(EntryKind.Goal); break;
                case Section.Day: RenderDay(); break;
                case Section.Week: RenderPlanning(Period.Week); break;
                case Section.Month: RenderPlanning(Period.Month); break;
                case Section.Year: RenderYear(); break;
                case Section.Habits: RenderHabits(); break;
                case Section.Events: RenderEvents(); break;
                case Section.Summary: RenderSummary(); break;
                case Section.Finance: RenderFinance(); break;
                case Section.FinanceSummary: RenderFinanceSummary(); break;
            }
            scroller.ScrollToVerticalOffset(offset);
            if (boardScroller != null) boardScroller.ScrollToHorizontalOffset(horizontalOffset);
            if (!preserve && content.Children.Count > 0) AnimateEntrance(content.Children[0]);
            if (focusId != null && focusId.Length > 0 && (focused as FrameworkElement) != null &&
                !(focused as FrameworkElement).IsLoaded)
            {
                var replacement = FindControl(shell, focusId) as Control;
                if (replacement != null) replacement.Focus();
            }
        }

        private void Navigate(Section target)
        {
            if (target == Section.Day || target == Section.Week) target = Section.Tasks;
            if (target == Section.Month || target == Section.Year) target = Section.Goals;
            if (section == target) return;
            CloseDrawer(false);
            section = target;
            if (section == Section.Events && !eventInitialized)
            {
                eventDate = anchor;
                eventInitialized = true;
            }
            Refresh(false);
        }

        private Period ActivePeriod()
        {
            if (section == Section.Events) return Period.Month;
            return (Period)section;
        }

        private void CheckDateChange()
        {
            DateTime today = planner.Today;
            if (lastToday == today)
            {
                if (section == Section.Events)
                {
                    Entry upcoming = UpcomingEvent(planner.Entries.Where(entry => entry.Kind == EntryKind.Event));
                    if (shownUpcomingEvent != (upcoming == null ? null : upcoming.Id)) Refresh();
                }
                return;
            }
            if (anchor == lastToday) anchor = today;
            if (taskChartEnd == lastToday && anchor == today) taskChartEnd = today;
            if (eventDate == lastToday) eventDate = today;
            lastToday = today;
            planner.SyncArchive();
            Refresh();
            if (drawerRedraw != null) drawerRedraw();
        }

        private void ChangePeriod(int steps)
        {
            Period period = ActivePeriod();
            if (section == Section.Events)
            {
                eventDate = steps == 0 ? planner.Today : CalendarRules.Shift(period, eventDate, steps);
            }
            else
            {
                anchor = steps == 0 ? planner.Today : CalendarRules.Shift(period, anchor, steps);
            }
            CloseDrawer(false);
            Refresh(false);
        }

        private void RenderHeader()
        {
            header.Children.Clear();
            var line = new DockPanel { LastChildFill = true };
            string newLabel;
            switch (section)
            {
                case Section.Tasks: newLabel = "Новая задача"; break;
                case Section.Subgoals: newLabel = "Новая подцель"; break;
                case Section.Goals: newLabel = "Новая цель"; break;
                case Section.Day: newLabel = "Новая задача"; break;
                case Section.Week: newLabel = "Добавить"; break;
                case Section.Summary: newLabel = null; break;
                case Section.Habits: newLabel = "Новая привычка"; break;
                case Section.Events: newLabel = "Новое событие"; break;
                case Section.Finance:
                case Section.FinanceSummary: newLabel = "Операция"; break;
                default: newLabel = "Добавить"; break;
            }
            if (newLabel != null)
            {
                var add = Button(newLabel, BeginCreate, "add", "primary");
                var addLabel = Horizontal();
                var plus = Glyph("\uE710", White, 13);
                plus.Margin = new Thickness(0, 0, 8, 0);
                addLabel.Children.Add(plus);
                addLabel.Children.Add(Text(newLabel, 13, White, true));
                add.Content = addLabel;
                DockPanel.SetDock(add, Dock.Right);
                add.MinHeight = 38;
                add.VerticalAlignment = VerticalAlignment.Center;
                line.Children.Add(add);
            }
            if (section == Section.Day)
            {
                int overdue = planner.OverdueTasks().Count();
                if (overdue > 0)
                {
                    var late = Button("Просрочено · " + overdue, ShowOverdue, "overdue", "outline");
                    late.Margin = new Thickness(0, 0, 7, 0);
                    late.VerticalAlignment = VerticalAlignment.Center;
                    DockPanel.SetDock(late, Dock.Right);
                    line.Children.Add(late);
                }
            }
            var title = Display(SectionNames[(int)section], section == Section.FinanceSummary ? 31 : 42);
            title.TextWrapping = TextWrapping.Wrap;
            line.Children.Add(title);
            header.Children.Add(line);

            if (section == Section.Events)
            {
                DateTime selected = section == Section.Events ? eventDate : anchor;
                Period period = ActivePeriod();
                var controls = new DockPanel { LastChildFill = true, Margin = new Thickness(0, 8, 0, 13) };
                StackPanel buttons = Horizontal();
                var previous = IconButton("\uE76B", "Предыдущий период", () => ChangePeriod(-1), "previous");
                var next = IconButton("\uE76C", "Следующий период", () => ChangePeriod(1), "next");
                previous.IsEnabled = CalendarRules.Range(period, selected).Start > new DateTime(2, 1, 1);
                next.IsEnabled = CalendarRules.Range(period, selected).End < new DateTime(9998, 12, 31);
                previous.Margin = next.Margin = new Thickness(0, 0, 4, 0);
                buttons.Children.Add(previous);
                buttons.Children.Add(next);
                buttons.Children.Add(Button("Сегодня", () => ChangePeriod(0), "today", "outline"));
                DockPanel.SetDock(buttons, Dock.Right);
                controls.Children.Add(buttons);
                var periodLabel = Text(CalendarRules.Label(period, selected), 16, Muted);
                periodLabel.Margin = new Thickness(0, 0, 5, 0);
                Identify(periodLabel, "period-label");
                controls.Children.Add(periodLabel);
                header.Children.Add(controls);
            }
            else header.Children.Add(Gap(17));
        }

        private void OpenDrawer(string title, StackPanel contents, Action redraw = null, Action save = null)
        {
            if (financeCalculator != null) financeCalculator.IsOpen = false;
            bool wasModal = modalLayer.Visibility == Visibility.Visible;
            var layout = new DockPanel { LastChildFill = true, Margin = new Thickness(24, 20, 22, 18) };
            KeyboardNavigation.SetTabNavigation(layout, KeyboardNavigationMode.Cycle);
            var bar = new DockPanel { LastChildFill = true };
            var close = IconButton("\uE711", "Закрыть", () => CloseDrawer(), "close-drawer", "plain");
            DockPanel.SetDock(close, Dock.Right);
            bar.Children.Add(close);
            bar.Children.Add(Display(title, 25));
            DockPanel.SetDock(bar, Dock.Top);
            layout.Children.Add(bar);
            contents.Margin = new Thickness(0, 10, 6, 4);
            var drawerScroll = new ScrollViewer { Content = contents, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
            Identify(drawerScroll, "drawer-scroll");
            layout.Children.Add(drawerScroll);
            drawer.Child = layout;
            drawer.Visibility = Visibility.Visible;
            modalLayer.Visibility = Visibility.Visible;
            if (!wasModal) AnimateEntrance(drawer);
            drawerRedraw = redraw;
            submit = save;
            ResizeDrawer();
            if (submit == null) close.Focus();
        }

        private void CloseDrawer(bool focusAdd = true)
        {
            if (financeCalculator != null) financeCalculator.IsOpen = false;
            bool wasVisible = drawer.Visibility == Visibility.Visible;
            submit = null;
            drawerRedraw = null;
            drawer.Visibility = Visibility.Collapsed;
            modalLayer.Visibility = Visibility.Collapsed;
            drawer.Child = null;
            ResizeDrawer();
            if (focusAdd && wasVisible)
            {
                var add = FindControl(shell, "add") as Button;
                if (add != null) add.Focus();
            }
        }

        private void OnKey(object sender, KeyEventArgs e)
        {
            if (!ReferenceEquals(Content, shell)) return;
            var picked = Keyboard.FocusedElement as DependencyObject;
            bool comboOpen = false;
            for (DependencyObject node = picked; node is Visual; node = VisualTreeHelper.GetParent(node))
            {
                var combo = node as ComboBox;
                var picker = node as DateField;
                if ((combo != null && combo.IsDropDownOpen) || (picker != null && picker.Popup.IsOpen))
                {
                    comboOpen = true;
                    break;
                }
            }
            if (comboOpen) return;
            if (e.Key == Key.Escape && drawer.Visibility == Visibility.Visible)
            {
                CloseDrawer();
                e.Handled = true;
            }
            else if (e.Key == Key.N && Keyboard.Modifiers == ModifierKeys.Control && section != Section.Summary)
            {
                RunAction(BeginCreate);
                e.Handled = true;
            }
            else if (e.Key == Key.Enter && submit != null && picked is TextBox && !((TextBox)picked).AcceptsReturn)
            {
                RunAction(submit);
                e.Handled = true;
            }
        }

        private void RunAction(Action action)
        {
            try { action(); }
            catch (ArgumentException error) { Notice(error.Message); }
            catch (System.IO.IOException error) { Notice(error.Message); }
        }

        private void Notice(string message, string action = null, Action invoke = null)
        {
            noticeHost.Children.Clear();
            var line = new DockPanel { LastChildFill = true };
            var dismiss = IconButton("\uE711", "Скрыть", () => noticeHost.Children.Clear(), "dismiss-notice", "plain");
            DockPanel.SetDock(dismiss, Dock.Right);
            line.Children.Add(dismiss);
            if (invoke != null)
            {
                var undo = Button(action, invoke, "undo", "outline");
                undo.Margin = new Thickness(5, 0, 3, 0);
                DockPanel.SetDock(undo, Dock.Right);
                line.Children.Add(undo);
            }
            var label = Text(message, 13, TextInk, true);
            label.Margin = new Thickness(7, 0, 4, 0);
            Identify(label, "notice");
            line.Children.Add(label);
            var box = Card(line, new Thickness(5));
            box.Background = accentWash;
            noticeBox = box;
            noticeHost.Children.Add(box);
        }

        private void NotifyMastery(Entry habit)
        {
            string message = "Привычка освоена — " + habit.Title;
            masteryNotices++;
            Notice(message);
            if (testing) return;
            try
            {
                if (notifier == null)
                {
                    notifier = new System.Windows.Forms.NotifyIcon
                    {
                        Icon = System.Drawing.SystemIcons.Information,
                        Text = "Планер",
                        Visible = true
                    };
                }
                notifier.ShowBalloonTip(5000, "Привычка освоена", habit.Title,
                    System.Windows.Forms.ToolTipIcon.Info);
            }
            catch (System.ComponentModel.Win32Exception) { }
            catch (InvalidOperationException) { }
        }

        private static DependencyObject FindControl(DependencyObject node, string id)
        {
            if (AutomationProperties.GetAutomationId(node) == id) return node;
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(node); i++)
            {
                var found = FindControl(VisualTreeHelper.GetChild(node, i), id);
                if (found != null) return found;
            }
            return null;
        }
    }
}


