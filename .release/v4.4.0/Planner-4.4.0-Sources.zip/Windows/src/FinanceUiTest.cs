#if PLANNER_TESTS
using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;

namespace Planner
{
    internal static partial class UiTest
    {
        private static void FinanceText(MainWindow window, string id, string value) { Find<TextBox>(window, id).Text = value; }

        private static void VerifyFinance(MainWindow window, Store store, PlannerService planner, string folder)
        {
            var service = new FinanceService(store, () => planner.Today);
            Assert(service.Accounts.Count == 0 && service.Categories.Count == 0 && service.Operations.Count == 0,
                "Финансы открываются без созданных за пользователя счетов, категорий и операций");
            Click(window, "nav-Finance");
            Assert(Read(window, "finance-total-0") == Money.Format(0) && !Has(window, "finance-day-20261119"),
                "Пустой месяц показывает нулевые суммы и не создаёт пустые дни");
            Click(window, "finance-accounts");
            Click(window, "finance-add-account");
            FinanceText(window, "finance-account-name", "Карта");
            FinanceText(window, "finance-account-opening", "5000");
            Click(window, "finance-save");
            var card = store.ReadFinanceAccounts().Single();
            Assert(card.Opening == 500000, "Начальный остаток сохраняется целым числом копеек");
            Click(window, "finance-add-account");
            FinanceText(window, "finance-account-name", "Кредитка");
            FinanceText(window, "finance-account-opening", "-20000");
            Click(window, "finance-save");
            var credit = store.ReadFinanceAccounts().Single(item => item.Name == "Кредитка");
            Click(window, "close-drawer");
            Click(window, "add");
            FinanceText(window, "finance-amount", "10000,25");
            FinanceText(window, "finance-notes", "Оплата смен");
            Click(window, "finance-new-category");
            FinanceText(window, "finance-category-name", "Работа");
            Click(window, "finance-save");
            var income = store.ReadFinanceCategories().Single();
            Assert(Find<TextBox>(window, "finance-amount").Text == "10000,25" &&
                Find<TextBox>(window, "finance-notes").Text == "Оплата смен", "Создание категории из операции сохраняет введённые сумму и заметку");
            Select(window, "finance-account", "finance-account-" + card.Id);
            Click(window, "finance-save");
            var payment = store.ReadFinanceOperations().Single();
            Assert(payment.Amount == 1000025 && Read(window, "finance-total-0") == Money.Format(1000025),
                "Доход с копейками обновляет дашборд выбранного месяца");
            Assert(Has(window, "finance-day-20261119") && !Has(window, "finance-day-20261118"),
                "Плашка появляется только у дня с операциями");
            Click(window, "finance-op-" + payment.Id);
            FinanceText(window, "finance-amount", "12345,67");
            Click(window, "finance-save");
            using (var checkAmount = new Store(Path.Combine(folder, "planner.sqlite")))
                Assert(checkAmount.ReadFinanceOperations().Single(item => item.Id == payment.Id).Amount == 1234567,
                    "Редактирование суммы фиксируется в базе и видно через независимое соединение");
            Click(window, "finance-op-" + payment.Id);
            FinanceText(window, "finance-amount", "10000,25");
            Click(window, "finance-save");
            Click(window, "add");
            Click(window, "finance-kind-Expense");
            FinanceText(window, "finance-amount", "1200,75");
            Click(window, "finance-new-category");
            FinanceText(window, "finance-category-name", "Еда");
            Click(window, "finance-save");
            var food = store.ReadFinanceCategories().Single(item => item.Kind == FinanceKind.Expense);
            Select(window, "finance-account", "finance-account-" + card.Id);
            Click(window, "finance-save");
            Assert(Read(window, "finance-day-20261119-0") == Money.Format(1000025) &&
                Read(window, "finance-day-20261119-1") == Money.Format(120075) &&
                Read(window, "finance-day-20261119-2") == Money.Format(879950),
                "Доход, расход и итог дня рассчитываются отдельно и точно");
            Click(window, "add");
            Click(window, "finance-kind-Transfer");
            Assert(!Has(window, "finance-category") && Has(window, "finance-destination"),
                "Перевод предлагает два счёта");
            FinanceText(window, "finance-amount", "5000");
            Select(window, "finance-account", "finance-account-" + card.Id);
            Select(window, "finance-destination", "finance-destination-" + credit.Id);
            Click(window, "finance-save");
            var transfer = store.ReadFinanceOperations().Single(item => item.Kind == FinanceKind.Transfer);
            Assert(Read(window, "finance-total-0") == Money.Format(1000025) &&
                Read(window, "finance-total-1") == Money.Format(120075), "Перевод не увеличивает доходы и расходы");
            Click(window, "nav-FinanceSummary");
            Assert(Read(window, "finance-balance-0") == Money.Format(879950) &&
                Read(window, "finance-balance-1") == Money.Format(1500000) &&
                Read(window, "finance-balance-2") == Money.Format(-620050), "Погашение кредитки уменьшает деньги и долг на одинаковую сумму");
            Assert(Has(window, "finance-chart-Income") && Has(window, "finance-chart-Expense"), "Сводка содержит отдельные диаграммы доходов и расходов");
            Screenshot(window, folder, "finance-summary.png");
            Click(window, "finance-category-history-" + food.Id);
            Assert(Has(window, "finance-op-" + store.ReadFinanceOperations().Single(item => item.Kind == FinanceKind.Expense).Id),
                "Категория открывает сохранённую историю операций");
            Click(window, "close-drawer");
            Click(window, "nav-Finance");
            Screenshot(window, folder, "finance-operations.png");
            Click(window, "finance-op-" + transfer.Id);
            Click(window, "finance-delete");
            Assert(!store.ReadFinanceOperations().Any(item => item.Id == transfer.Id), "Удаление перевода удаляет операцию целиком");
            Click(window, "undo");
            Assert(store.ReadFinanceOperations().Single(item => item.Id == transfer.Id).DestinationId == credit.Id,
                "Отмена восстанавливает оба счёта перевода");
            Click(window, "finance-op-" + payment.Id);
            FinanceText(window, "finance-date-text", "31.10.2026");
            Click(window, "finance-save");
            Assert(Read(window, "finance-total-0") == Money.Format(0), "Перенос дохода через границу месяца обновляет текущий период");
            Click(window, "finance-prev");
            Assert(Has(window, "finance-day-20261031") && Read(window, "finance-total-0") == Money.Format(1000025),
                "Перенесённый доход отображается в новом месяце");
            Click(window, "finance-op-" + payment.Id);
            Click(window, "finance-delete");
            Assert(!Has(window, "finance-day-20261031"), "Удаление последней операции убирает плашку дня");
            Click(window, "undo");
            Assert(Has(window, "finance-day-20261031"), "Отмена возвращает день вместе с операцией");
            Click(window, "finance-mode-year");
            Assert(Enumerable.Range(1, 12).All(month => Has(window, "finance-open-month-" + month)),
                "Год содержит все 12 месяцев");
            Assert(Read(window, "finance-month-10-0") == Money.Format(1000025), "В годовом списке доход относится к правильному месяцу");
            Click(window, "finance-open-month-10");
            Assert(Has(window, "finance-day-20261031"), "Нажатие месяца открывает его операции");
            Click(window, "finance-op-" + payment.Id);
            FinanceText(window, "finance-amount", "10000,255");
            Click(window, "finance-save");
            Assert(Has(window, "finance-save") && store.ReadFinanceOperations().Single(item => item.Id == payment.Id).Amount == 1000025,
                "Лишние десятичные знаки не изменяют сохранённую операцию");
            Click(window, "close-drawer");
            Click(window, "finance-now");
            Click(window, "finance-categories");
            Click(window, "finance-remove-category-" + food.Id);
            Assert(store.ReadFinanceCategories().Single(item => item.Id == food.Id).Archived &&
                store.ReadFinanceOperations().Any(item => item.CategoryId == food.Id), "Архивирование категории сохраняет историю");
            Click(window, "close-drawer");
            Click(window, "add");
            Click(window, "finance-kind-Expense");
            Assert(!Find<ComboBox>(window, "finance-category").Items.Cast<ComboBoxItem>().Any(item => (string)item.Tag == food.Id),
                "Архивная категория скрыта при создании операции");
            Click(window, "close-drawer");
            service = new FinanceService(store, () => planner.Today);
            var spent = service.Operations.Single(item => item.Kind == FinanceKind.Expense);
            spent = spent.Copy();
            spent.Notes = "Правка старой операции";
            service.Save(spent);
            Assert(store.ReadFinanceOperations().Single(item => item.Id == spent.Id).CategoryId == food.Id,
                "Правка старой операции сохраняет её архивную категорию");
            var restoreFood = service.Categories.Single(item => item.Id == food.Id).Copy();
            restoreFood.Archived = false;
            service.Save(restoreFood);
            Click(window, "finance-accounts");
            Click(window, "finance-edit-account-" + card.Id);
            FinanceText(window, "finance-account-name", "Основная карта");
            Click(window, "finance-save");
            Assert(store.ReadFinanceAccounts().Single(item => item.Id == card.Id).Name == "Основная карта",
                "Переименование счёта сохраняет его идентификатор и историю");
            Click(window, "close-drawer");
            Click(window, "add");
            Click(window, "finance-calculator");
            var calculator = typeof(MainWindow).GetField("financeCalculator", System.Reflection.BindingFlags.NonPublic |
                System.Reflection.BindingFlags.Instance).GetValue(window) as Popup;
            Assert(calculator != null && calculator.IsOpen, "Калькулятор открывается в работающем окне");
            var expression = Find<TextBox>(calculator.Child, "finance-calc-expression");
            expression.Text = "1000+250,50*2";
            Find<Button>(calculator.Child, "finance-calc-Готово").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            Assert(Find<TextBox>(window, "finance-amount").Text == "1501,00", "Калькулятор передаёт точную сумму в форму");
            Click(window, "close-drawer");
            Assert(MoneyCalculator.Evaluate("(100+50)/3") == "50,00" && Money.Parse("0,01", false) == 1 &&
                Money.Parse("-20000", true) == -2000000 && Money.Parse("1 000,25", false) == 100025,
                "Калькулятор поддерживает приоритет операций, скобки и точные копейки");
            bool rejected = false;
            try { MoneyCalculator.Evaluate("1/0"); } catch (ArgumentException) { rejected = true; }
            Assert(rejected, "Деление на ноль обрабатывается без сбоя приложения");
            var bad = transfer.Copy(); bad.DestinationId = bad.AccountId;
            rejected = false;
            try { service.Save(bad); } catch (ArgumentException) { rejected = true; }
            Assert(rejected, "Перевод на тот же счёт отклоняется");
            using (var persisted = new Store(Path.Combine(folder, "planner.sqlite")))
            {
                var reloaded = new FinanceService(persisted, () => planner.Today);
                Assert(reloaded.Operations.Count == 3 && reloaded.Accounts.Count == 2 && reloaded.Categories.Count == 2 &&
                    reloaded.Balance(reloaded.Accounts.Single(item => item.Id == credit.Id)) == -1500000,
                    "Счета, категории, копейки и погашение долга сохраняются после повторного открытия базы");
            }
            window.Width = 740;
            window.Height = 580;
            Click(window, "nav-FinanceSummary");
            Screenshot(window, folder, "finance-summary-compact.png");
            Assert(Find<FrameworkElement>(window, "finance-chart-Expense").ActualWidth > 0,
                "Диаграммы доступны в уменьшенном окне");
            Click(window, "nav-Finance");
            Screenshot(window, folder, "finance-operations-compact.png");
            window.Width = 1240;
            window.Height = 805;
            Click(window, "nav-Tasks");
        }
    }
}
#endif
