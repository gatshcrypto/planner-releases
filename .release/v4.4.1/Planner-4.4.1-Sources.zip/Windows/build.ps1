﻿param(
    [string]$OutputDirectory = (Join-Path $PSScriptRoot 'build'),
    [switch]$Tests,
    [ValidatePattern('^[A-Za-z0-9-]+/[A-Za-z0-9_.-]+$')]
    [string]$ReleaseRepository
)
$ErrorActionPreference = 'Stop'
$framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
$compiler = Join-Path $framework 'csc.exe'
if (-not (Test-Path -LiteralPath $compiler)) {
    throw 'Сборка рассчитана на 64-разрядную Windows с .NET Framework 4.8 или новее.'
}
$null = New-Item -ItemType Directory -Path $OutputDirectory -Force
$output = (Resolve-Path -LiteralPath $OutputDirectory).Path
$sourceDirectory = Join-Path $PSScriptRoot 'src'
$sourceFiles = @(Get-ChildItem -LiteralPath $sourceDirectory -Filter '*.cs' |
    Where-Object { $Tests -or $_.Name -ne 'UiTest.cs' } |
    ForEach-Object FullName)
$references = @('WPF\WindowsBase.dll', 'WPF\PresentationCore.dll', 'WPF\PresentationFramework.dll',
    'WPF\UIAutomationTypes.dll', 'System.Xaml.dll', 'System.Windows.Forms.dll', 'System.Drawing.dll',
    'System.Configuration.dll', 'System.Net.Http.dll', 'System.Runtime.Serialization.dll', 'System.Web.Extensions.dll', 'System.Web.dll', 'System.IO.Compression.dll') |
    ForEach-Object { '/reference:' + (Join-Path $framework $_) }
$manifest = Join-Path $sourceDirectory 'Planner.manifest'
$icon = Join-Path $sourceDirectory 'Planner.ico'
$logo = Join-Path $sourceDirectory 'PlannerLogo.png'
$quotes = Join-Path $sourceDirectory 'Quotes.txt'
$landscapes = Join-Path $sourceDirectory 'ThemeLandscapes.jpg'
$phoneServer = Join-Path $sourceDirectory 'PhoneServer.zip'
if (-not (Test-Path -LiteralPath $phoneServer)) { throw 'Не найден подготовленный пакет мобильного приложения PhoneServer.zip.' }
$compilerOptions = @('/nologo', '/target:winexe', '/platform:x64', '/optimize+', '/codepage:65001',
    '/langversion:5', "/out:$output\Planner.exe", "/win32manifest:$manifest", "/win32icon:$icon",
    "/resource:$logo,Planner.Logo", "/resource:$quotes,Planner.Quotes", "/resource:$landscapes,Planner.Landscapes", "/resource:$phoneServer,Planner.PhoneServer")
if ($Tests) { $compilerOptions += '/define:PLANNER_TESTS' }
& $compiler @compilerOptions @references @sourceFiles
if ($LASTEXITCODE -ne 0) { throw "Ошибка сборки ($LASTEXITCODE)." }
$configuration = Join-Path $output 'Planner.exe.config'
Copy-Item -LiteralPath (Join-Path $sourceDirectory 'Planner.exe.config') -Destination $configuration
if ($ReleaseRepository) {
    $settings = [xml](Get-Content -LiteralPath $configuration -Raw -Encoding utf8)
    $settings.SelectSingleNode('/configuration/appSettings/add[@key="ReleaseRepository"]').SetAttribute('value', $ReleaseRepository)
    $settings.Save($configuration)
}
Write-Output (Join-Path $output 'Planner.exe')

