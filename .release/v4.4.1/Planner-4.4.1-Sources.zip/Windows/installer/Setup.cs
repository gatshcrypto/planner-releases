using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;
using Planner;

internal sealed class Setup
{
    private const string UninstallKey = @"Software\Microsoft\Windows\CurrentVersion\Uninstall\PersonalPlanner";
    private static readonly string Self = Assembly.GetExecutingAssembly().Location;
    private static readonly string[] Files = { InstallationPaths.AppFile, InstallationPaths.ConfigFile,
        InstallationPaths.MaintenanceFile };
    private readonly string appFolder, previousFolder, shortcut;
    private readonly bool test;

    private Setup(string appFolder, string shortcut, bool test)
    {
        this.appFolder = appFolder;
        previousFolder = appFolder + ".previous";
        this.shortcut = shortcut;
        this.test = test;
    }

    [STAThread]
    private static int Main(string[] args)
    {
        string programs = Environment.GetFolderPath(Environment.SpecialFolder.Programs);
        var setup = new Setup(InstallationPaths.ProgramFolder, Path.Combine(programs, "Планер.lnk"), false);
        try
        {
#if INSTALLER_TESTS
            if (args.Length == 2 && (args[0] == "--test-install" || args[0] == "--test-remove"))
            {
                string root = Path.GetFullPath(args[1]);
                setup = new Setup(Path.Combine(root, "Programs", "Planner"),
                    Path.Combine(root, "Start Menu", "Планер.lnk"), true);
                setup.Run(args[0] == "--test-remove");
                return 0;
            }
#endif
            bool update = args.Length == 2 && args[0] == "--apply";
            bool remove = args.Length == 2 && args[0] == "--finish-remove";
            if (update || remove)
            {
                int pid;
                if (!Int32.TryParse(args[1], out pid)) return 1;
                WaitFor(pid);
            }
            else if (args.Length == 1 && args[0] == "--uninstall")
            {
                if (MessageBox.Show("Удалить планер? Задачи и настройки сохранятся.", "Планер",
                    MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK) return 0;
                string helper = Path.Combine(Path.GetTempPath(), "PlannerRemove-" + Guid.NewGuid().ToString("N") + ".exe");
                File.Copy(Self, helper);
                using (Process current = Process.GetCurrentProcess())
                using (Process next = Process.Start(helper, "--finish-remove " + current.Id)) { }
                return 0;
            }
            else if (MessageBox.Show("Установить планер для текущего пользователя?", "Установка планера",
                MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK) return 0;

            setup.Run(remove);
            if (!remove)
                using (Process next = Process.Start(Path.Combine(setup.appFolder, InstallationPaths.AppFile))) { }
            return 0;
        }
        catch (Exception error)
        {
            if (setup.test) File.WriteAllText(Path.Combine(Path.GetDirectoryName(Path.GetDirectoryName(setup.appFolder)),
                "install-error.txt"), error.ToString());
            else MessageBox.Show("Не удалось завершить операцию.\n\n" + error.Message,
                "Планер", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return 1;
        }
    }

    private static void WaitFor(int pid)
    {
        try
        {
            using (Process process = Process.GetProcessById(pid))
                if (!process.WaitForExit(20000))
                    throw new InvalidOperationException("Закройте планер и попробуйте ещё раз.");
        }
        catch (ArgumentException) { }
    }

    private void Run(bool remove)
    {
        using (var gate = new Mutex(false, @"Local\PersonalPlannerSetup-" + Environment.UserName))
        {
            bool acquired;
            try { acquired = gate.WaitOne(TimeSpan.FromSeconds(5)); }
            catch (AbandonedMutexException) { acquired = true; }
            if (!acquired) throw new InvalidOperationException("Установщик планера уже открыт.");
            try
            {
                // Recover the previous installation if Windows shut down between the two folder moves.
                if (Directory.Exists(previousFolder))
                {
                    if (!Directory.Exists(appFolder)) Directory.Move(previousFolder, appFolder);
                    else RemoveFiles(previousFolder);
                }
                if (remove) Uninstall();
                else Install();
            }
            finally { gate.ReleaseMutex(); }
        }
    }

    private void Install()
    {
        string staging = appFolder + ".stage-" + Guid.NewGuid().ToString("N");
        bool replacing = Directory.Exists(appFolder);
        if (replacing && !File.Exists(Path.Combine(appFolder, InstallationPaths.MaintenanceFile)))
            throw new InvalidOperationException("Папка установки уже занята другими файлами.");
        Directory.CreateDirectory(staging);
        try
        {
            Extract("Planner.Program", Path.Combine(staging, InstallationPaths.AppFile));
            Extract("Planner.Configuration", Path.Combine(staging, InstallationPaths.ConfigFile));
            File.Copy(Self, Path.Combine(staging, InstallationPaths.MaintenanceFile));
            Version version = ReadVersion(staging);
            if (replacing && ReadVersion(appFolder) > version)
                throw new InvalidOperationException("Установлена более новая версия планера.");

            if (replacing) Directory.Move(appFolder, previousFolder);
            try
            {
                Directory.Move(staging, appFolder);
                Register(version);
            }
            catch
            {
                if (Directory.Exists(appFolder)) RemoveFiles(appFolder);
                if (replacing && Directory.Exists(previousFolder))
                {
                    Directory.Move(previousFolder, appFolder);
                    Register(ReadVersion(appFolder));
                }
                else Unregister();
                throw;
            }
            if (replacing)
            {
                try { RemoveFiles(previousFolder); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        }
        finally
        {
            if (Directory.Exists(staging)) RemoveFiles(staging);
        }
    }

    private void Uninstall()
    {
        if (!File.Exists(Path.Combine(appFolder, InstallationPaths.MaintenanceFile))) return;
        Directory.Move(appFolder, previousFolder);
        try { Unregister(); }
        catch
        {
            Directory.Move(previousFolder, appFolder);
            Register(ReadVersion(appFolder));
            throw;
        }
        RemoveFiles(previousFolder);
    }

    private static void Extract(string resource, string path)
    {
        using (Stream payload = Assembly.GetExecutingAssembly().GetManifestResourceStream(resource))
        using (Stream output = File.Create(path))
            payload.CopyTo(output);
    }

    private static Version ReadVersion(string directory)
    {
        var info = FileVersionInfo.GetVersionInfo(Path.Combine(directory, InstallationPaths.AppFile));
        return new Version(info.FileMajorPart, info.FileMinorPart, info.FileBuildPart);
    }

    private void Register(Version version)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(shortcut));
        dynamic shell = Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell"));
        try
        {
            dynamic link = shell.CreateShortcut(shortcut);
            try
            {
                link.TargetPath = Path.Combine(appFolder, InstallationPaths.AppFile);
                link.WorkingDirectory = appFolder;
                link.Description = "Планер";
                link.Save();
            }
            finally { Marshal.FinalReleaseComObject(link); }
        }
        finally { Marshal.FinalReleaseComObject(shell); }
        if (test) return;

        string maintenance = Path.Combine(appFolder, InstallationPaths.MaintenanceFile);
        using (RegistryKey key = Registry.CurrentUser.CreateSubKey(UninstallKey))
        {
            key.SetValue("DisplayName", "Планер");
            key.SetValue("DisplayVersion", version.ToString(3));
            key.SetValue("DisplayIcon", Path.Combine(appFolder, InstallationPaths.AppFile));
            key.SetValue("InstallLocation", appFolder);
            key.SetValue("UninstallString", "\"" + maintenance + "\" --uninstall");
            key.SetValue("NoModify", 1);
            key.SetValue("NoRepair", 1);
        }
    }

    private void Unregister()
    {
        File.Delete(shortcut);
        if (!test) Registry.CurrentUser.DeleteSubKey(UninstallKey, false);
    }

    private static void RemoveFiles(string folder)
    {
        if ((File.GetAttributes(folder) & FileAttributes.ReparsePoint) != 0)
            throw new IOException("Папка установки была перемещена.");
        foreach (string name in Files) File.Delete(Path.Combine(folder, name));
        Directory.Delete(folder);
    }
}
