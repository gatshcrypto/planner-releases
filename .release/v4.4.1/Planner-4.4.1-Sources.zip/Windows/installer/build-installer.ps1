param(
    [string]$OutputDirectory = (Join-Path $PSScriptRoot '..\build'),
    [string]$ReleaseRepository,
    [string]$ApplicationDirectory,
    [switch]$Tests
)
$ErrorActionPreference = 'Stop'
$output = (New-Item -ItemType Directory -Path $OutputDirectory -Force).FullName
if (-not $ApplicationDirectory) {
    $ApplicationDirectory = Join-Path $output 'application'
    $options = @{ OutputDirectory = $ApplicationDirectory }
    if ($ReleaseRepository) { $options.ReleaseRepository = $ReleaseRepository }
    $null = & (Join-Path $PSScriptRoot '..\build.ps1') @options
}
$app = (Get-Item -LiteralPath (Join-Path $ApplicationDirectory 'Planner.exe')).FullName
$config = (Get-Item -LiteralPath (Join-Path $ApplicationDirectory 'Planner.exe.config')).FullName
$icon = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..\src\Planner.ico')).Path
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$setup = Join-Path $output 'PlannerSetup.exe'
$options = @('/nologo', '/target:winexe', '/platform:x64', '/optimize+', '/codepage:65001', '/langversion:5',
    '/reference:System.Windows.Forms.dll', '/reference:Microsoft.CSharp.dll',
    "/out:$setup", "/win32icon:$icon", "/resource:$app,Planner.Program", "/resource:$config,Planner.Configuration")
if ($Tests) { $options += '/define:INSTALLER_TESTS' }
& $compiler @options (Join-Path $PSScriptRoot 'Setup.cs') (Join-Path $PSScriptRoot '..\src\InstallationPaths.cs')
if ($LASTEXITCODE -ne 0) { throw "Installer compilation failed ($LASTEXITCODE)." }
Write-Output $setup
