using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace Planner
{
    internal sealed partial class MainWindow
    {
        private void ToggleEntry(Entry entry, bool done, bool keepDrawer = false)
        {
            planner.SetChecked(entry, done);
            bool archived = (entry.Kind == EntryKind.Task || entry.Kind == EntryKind.Subgoal) && done;
            if (archived && !keepDrawer) CloseDrawer(false);
            Refresh();
            if (archived && keepDrawer && drawerRedraw != null) RedrawCompletionDrawer();
            if (!archived)
            {
                if (drawerRedraw != null)
                {
                    if (keepDrawer) RedrawCompletionDrawer();
                    else drawerRedraw();
                }
                return;
            }

            Notice("В архиве", "Вернуть", () =>
            {
                var task = planner.Find(entry.Id);
                if (task != null) planner.SetChecked(task, false);
                noticeHost.Children.Clear();
                Refresh();
                if (drawerRedraw != null) drawerRedraw();
            });
            var notification = noticeBox;
            var timeout = new DispatcherTimer { Interval = TimeSpan.FromSeconds(5) };
            timeout.Tick += (sender, e) =>
            {
                timeout.Stop();
                if (noticeBox == notification) noticeHost.Children.Clear();
            };
            timeout.Start();
        }

        private void RedrawCompletionDrawer()
        {
            var oldScroll = FindControl(drawer, "drawer-scroll") as ScrollViewer;
            double offset = oldScroll == null ? 0 : oldScroll.VerticalOffset;
            drawerRedraw();
            var newScroll = FindControl(drawer, "drawer-scroll") as ScrollViewer;
            if (newScroll != null) newScroll.ScrollToVerticalOffset(offset);
        }

        private void ConfirmClearPlanning()
        {
            var panel = Horizontal();
            panel.Children.Add(Button("Удалить", () =>
            {
                planner.ClearPlanning();
                noticeHost.Children.Clear();
                Refresh();
                ShowSettings();
            }, "confirm-clear-planning", "primary"));
            panel.Children.Add(Button("Отмена", ShowSettings));
            var dialog = new StackPanel();
            dialog.Children.Add(panel);
            OpenDrawer("Удалить задачи, цели и подцели?", dialog);
        }

        private void ShowArchive()
        {
            var panel = new StackPanel();
            var tasks = Order(planner.ArchivedEntries).ToList();
            var top = new DockPanel { LastChildFill = true, Margin = new Thickness(0, 0, 0, 9) };
            var back = Link("‹ Настройки", ShowSettings, "archive-back");
            top.Children.Add(back);
            if (tasks.Count > 0)
            {
                var clear = Button("Очистить архив", () => ConfirmArchive(null), "archive-clear");
                DockPanel.SetDock(clear, Dock.Right);
                top.LastChildFill = false;
                top.Children.Add(clear);
            }
            panel.Children.Add(top);
            if (tasks.Count == 0) Empty(panel, "Архив пуст");
            foreach (var group in tasks.GroupBy(PlannerService.ScheduledDate))
            {
                var date = Text(group.Key.HasValue ? group.Key.Value.ToString("d MMMM", CalendarRules.Russian) :
                    "Без даты", 12, Muted, true);
                date.Margin = new Thickness(3, 7, 0, 5);
                panel.Children.Add(date);
                foreach (Entry task in group) panel.Children.Add(ArchiveRow(task));
            }
            OpenDrawer("Архив", panel, ShowArchive);
        }

        private UIElement ArchiveRow(Entry task)
        {
            var row = new DockPanel { LastChildFill = true };
            var buttons = Horizontal();
            var restore = IconButton("\uE7A7", "Вернуть на доску", () =>
            {
                planner.SetChecked(task, false);
                Refresh();
                ShowArchive();
            }, "archive-restore-" + task.Id, "plain");
            buttons.Children.Add(restore);
            buttons.Children.Add(IconButton("\uE74D", "Удалить из архива", () => ConfirmArchive(task),
                "archive-delete-" + task.Id, "plain"));
            DockPanel.SetDock(buttons, Dock.Right);
            row.Children.Add(buttons);
            var name = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            name.Children.Add(Link(task.Title, () => ShowDetails(task.Id), "archive-open-" + task.Id));
            string info = task.Day.HasValue ? task.Day.Value.ToString("dd.MM", CalendarRules.Russian) : "Без даты";
            if (task.Time.HasValue) info += " · " + task.Time.Value.ToString(@"hh\:mm");
            if (task.BoardColumn != null) info += " · " + ColumnName(task.BoardColumn);
            info = KindName(task.Kind) + " · " + info;
            Entry parent = planner.Find(task.ParentId);
            if (parent != null) info += " · " + parent.Title;
            name.Children.Add(Text(info, 11, Muted));
            if (!String.IsNullOrWhiteSpace(task.Notes)) name.ToolTip = task.Notes;
            row.Children.Add(name);
            var card = Card(row, new Thickness(9, 6, 4, 6));
            card.Margin = new Thickness(0, 0, 0, 4);
            Identify(card, "archive-task-" + task.Id);
            return card;
        }

        private void ConfirmArchive(Entry task)
        {
            var panel = new StackPanel();
            if (task != null) Head(panel, task.Title);
            var actions = Horizontal();
            actions.Children.Add(Button("Удалить", () =>
            {
                planner.ClearArchive(task == null ? null : task.Id);
                Refresh();
                ShowArchive();
            }, "archive-confirm", "primary"));
            actions.Children.Add(Button("Отмена", ShowArchive, "archive-cancel"));
            panel.Children.Add(actions);
            OpenDrawer(task == null ? "Очистить архив?" : "Удалить из архива?", panel);
        }
    }
}
