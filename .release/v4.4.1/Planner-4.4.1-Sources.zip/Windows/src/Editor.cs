using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Threading;

namespace Planner
{
    internal sealed partial class MainWindow
    {
        private static string KindName(EntryKind kind)
        {
            switch (kind)
            {
                case EntryKind.Goal: return "Цель";
                case EntryKind.Subgoal: return "Подцель";
                case EntryKind.Habit: return "Привычка";
                case EntryKind.Event: return "Событие";
                default: return "Задача";
            }
        }

        private void BeginCreate()
        {
            if (section == Section.Finance || section == Section.FinanceSummary)
            {
                ShowFinanceOperation(new FinanceOperation { Day = financeDate });
                return;
            }
            if (section == Section.Habits)
            {
                ShowForm(new Entry { Kind = EntryKind.Habit, Day = planner.Today }, false);
                return;
            }
            if (section == Section.Events)
            {
                NewEvent(eventDate);
                return;
            }

            switch (section)
            {
                case Section.Tasks:
                    NewTask(anchor, null, null, FirstColumn());
                    break;
                case Section.Goals:
                    NewGoal(Period.Month, FirstColumn());
                    break;
                case Section.Subgoals:
                    NewSubgoal(null);
                    break;
                case Section.Day:
                    NewTask(anchor, null, null, FirstColumn());
                    break;
                case Section.Week:
                case Section.Month:
                case Section.Year:
                    Period period = ActivePeriod();
                    var panel = new StackPanel();
                    if (period == Period.Week)
                        AddChoice(panel, "Задача", "\uE73A",
                            () => NewTask(null, null, CalendarRules.Range(Period.Week, anchor), FirstColumn()), "add-task");
                    AddChoice(panel, "Цель", "\uECA5", () => NewGoal(period, FirstColumn()), "add-goal");
                    AddChoice(panel, "Подцель", "\uE8FD", () => NewSubgoal(null, period), "add-subgoal");
                    OpenDrawer("Добавить", panel);
                    break;
            }
        }

        private void AddChoice(StackPanel stack, string label, string icon, Action action, string id)
        {
            var button = Button(label, action, id, "outline");
            button.Content = RailLabel(icon, label, false);
            button.HorizontalContentAlignment = HorizontalAlignment.Left;
            button.Margin = new Thickness(0, 0, 0, 8);
            stack.Children.Add(button);
        }

        private void NewGoal(Period period, string columnId = null)
        {
            ShowForm(new Entry { Kind = EntryKind.Goal, Day = planner.Today, Period = period, BoardColumn = columnId }, false);
        }

        private void NewSubgoal(string goalId, Period? scope = null)
        {
            IEnumerable<Entry> parents = null;
            if (scope == Period.Week) parents = planner.Goals(Period.Week, anchor);
            if (scope == Period.Year) parents = planner.Goals(Period.Year, anchor);
            if (scope == Period.Month)
                parents = planner.Goals(Period.Month, anchor).Concat(planner.Goals(Period.Year, anchor));
            if (goalId == null && !(parents ?? planner.Entries.Where(item => item.Kind == EntryKind.Goal)).Any())
            {
                var panel = new StackPanel();
                Empty(panel, "Целей нет", "Новая цель", () => NewGoal(scope ?? Period.Month));
                OpenDrawer("Новая подцель", panel);
                return;
            }
            ShowForm(new Entry { Kind = EntryKind.Subgoal, ParentId = goalId }, false, null, parents);
        }

        private void NewTask(DateTime? day, string parentId, DateRange? permitted, string columnId = null)
        {
            ShowForm(new Entry { Kind = EntryKind.Task, Day = day, ParentId = parentId, BoardColumn = columnId }, false, permitted);
        }

        private void NewEvent(DateTime day)
        {
            eventDate = day;
            Refresh();
            ShowForm(new Entry { Kind = EntryKind.Event, Day = day }, false);
        }

        private void FormLabel(StackPanel panel, string label, Control input)
        {
            var caption = new Label
            {
                Content = label, Target = input, Padding = new Thickness(0, 0, 0, 5),
                Foreground = Muted, FontSize = 12, FontWeight = FontWeights.SemiBold
            };
            panel.Children.Add(caption);
            input.Margin = new Thickness(0, 0, 0, 13);
            panel.Children.Add(input);
        }

        private TextBox Input(string id, string value, bool multi = false)
        {
            var input = new TextBox
            {
                Text = value, FontFamily = BodyFont, FontSize = 14, Foreground = TextInk, Background = CardPaper,
                BorderBrush = Line, BorderThickness = new Thickness(1), Padding = new Thickness(9, 6, 9, 6),
                MinHeight = multi ? 62 : 38, AcceptsReturn = multi,
                MaxLength = multi ? 4000 : 220, TextWrapping = multi ? TextWrapping.Wrap : TextWrapping.NoWrap,
                VerticalScrollBarVisibility = multi ? ScrollBarVisibility.Auto : ScrollBarVisibility.Hidden
            };
            input.Template = TextFieldTemplate();
            input.GotKeyboardFocus += (sender, e) => input.BorderBrush = accent;
            input.LostKeyboardFocus += (sender, e) => input.BorderBrush = Line;
            Identify(input, id);
            return input;
        }

        private ComboBox ParentPicker(Entry entry, IEnumerable<Entry> available)
        {
            var picker = SelectList("parent");
            if (entry.Kind == EntryKind.Task)
                picker.Items.Add(new ComboBoxItem { Content = "Без подцели" });
            EntryKind kind = entry.Kind == EntryKind.Task ? EntryKind.Subgoal : EntryKind.Goal;
            Entry original = planner.Find(entry.Id);
            var options = (available ?? planner.Entries).Where(item => item.Kind == kind && item.Title.Length > 0 &&
                (entry.Kind != EntryKind.Task || planner.CanAttachTaskTo(item) || original != null && original.ParentId == item.Id));
            foreach (Entry option in Order(options))
            {
                Entry goal = kind == EntryKind.Subgoal ? planner.Find(option.ParentId) : option;
                string context = PlannerService.Dates(goal);
                if (kind == EntryKind.Subgoal) context = goal.Title + " · " + context;
                string label = planner.IsArchived(option) ? option.Title + " (выполнена)" : option.Title;
                var item = new ComboBoxItem { Tag = option.Id, Content = label, ToolTip = context };
                Identify(item, "parent-choice-" + option.Id, label + ", " + context);
                picker.Items.Add(item);
                if (option.Id == entry.ParentId) picker.SelectedItem = item;
            }
            if (picker.SelectedIndex < 0 && (entry.Kind == EntryKind.Task || picker.Items.Count == 1))
                picker.SelectedIndex = 0;
            return picker;
        }

        private void ShowForm(Entry entry, bool editing, DateRange? permitted = null, IEnumerable<Entry> parents = null)
        {
            Entry draft = entry.Copy();
            var panel = new StackPanel();
            var title = Input("entry-title", entry.Title);
            FormLabel(panel, "Название", title);
            ComboBox kind = null;
            if (entry.Kind == EntryKind.Goal)
            {
                kind = SelectList("goal-period");
                foreach (Period period in new[] { Period.Week, Period.Month, Period.Year })
                {
                    var option = new ComboBoxItem
                    {
                        Content = PlannerService.TermName(period),
                        Tag = period
                    };
                    Identify(option, "goal-period-" + period);
                    kind.Items.Add(option);
                    if (entry.Period == period) kind.SelectedItem = option;
                }
                FormLabel(panel, "Период цели", kind);
            }
            DateField date = PickDate(entry.Day, permitted);
            DateField endDate = null;
            CheckBox noDate = null;
            bool optionalDate = entry.Kind == EntryKind.Subgoal;
            if (optionalDate)
            {
                noDate = new CheckBox { Content = "Без срока",
                    IsChecked = !entry.Day.HasValue, Foreground = TextInk, Margin = new Thickness(0, 0, 0, 12) };
                noDate.Template = (ControlTemplate)XamlReader.Parse(@"<ControlTemplate
                    xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
                    xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' TargetType='CheckBox'>
                    <StackPanel Orientation='Horizontal' Background='Transparent'>
                        <Border Width='20' Height='20' CornerRadius='5' BorderThickness='1'
                            BorderBrush='{DynamicResource Planner.Muted}' Background='{DynamicResource Planner.Card}' Margin='0,0,9,0'>
                            <TextBlock x:Name='tick' Text='✓' Visibility='Collapsed' FontSize='15'
                                Foreground='{TemplateBinding Foreground}' HorizontalAlignment='Center' VerticalAlignment='Center'/>
                        </Border>
                        <ContentPresenter VerticalAlignment='Center'/>
                    </StackPanel>
                    <ControlTemplate.Triggers><Trigger Property='IsChecked' Value='True'>
                        <Setter TargetName='tick' Property='Visibility' Value='Visible'/>
                    </Trigger></ControlTemplate.Triggers>
                </ControlTemplate>");
                Identify(noDate, "no-date");
                noDate.Checked += (sender, e) => { date.IsEnabled = false; if (endDate != null) endDate.IsEnabled = false; };
                noDate.Unchecked += (sender, e) =>
                {
                    date.IsEnabled = true;
                    if (!date.Value.HasValue) date.Value = planner.Today;
                    if (endDate != null)
                    {
                        endDate.IsEnabled = true;
                        if (!endDate.Value.HasValue) endDate.Value = date.Value.Value.AddDays(7);
                    }
                };
                date.IsEnabled = noDate.IsChecked != true;
                panel.Children.Add(noDate);
            }
            TextBox time = null, duration = null;
            if (entry.Kind == EntryKind.Task)
            {
                time = Input("time", entry.Time.HasValue ? entry.Time.Value.ToString(@"hh\:mm") : "");
                time.MaxLength = 5;
                time.ToolTip = "Время в формате ЧЧ:ММ, по желанию";
                duration = Input("duration", entry.DurationMinutes.HasValue ? entry.DurationMinutes.Value.ToString() : "");
                duration.MaxLength = 4;
                var strip = DashboardGrid(240);
                strip.ColumnDefinitions.Add(new ColumnDefinition());
                var dateColumn = new StackPanel { Margin = new Thickness(0, 0, 9, 0) };
                var timeColumn = new StackPanel { Margin = new Thickness(0, 0, 9, 0) };
                var durationColumn = new StackPanel();
                FormLabel(dateColumn, "Дата", date);
                FormLabel(timeColumn, "Время", time);
                FormLabel(durationColumn, "Минуты", duration);
                duration.ToolTip = "Плановая длительность";
                strip.Children.Add(dateColumn);
                Grid.SetColumn(timeColumn, 1);
                strip.Children.Add(timeColumn);
                Grid.SetColumn(durationColumn, 2);
                strip.Children.Add(durationColumn);
                panel.Children.Add(strip);
            }
            else FormLabel(panel, entry.Kind == EntryKind.Habit || entry.Kind == EntryKind.Goal ||
                entry.Kind == EntryKind.Subgoal ? "Начало" : "Дата", date);
            if (entry.Kind == EntryKind.Subgoal)
            {
                endDate = PickDate(entry.TargetDay, null, "end-date");
                endDate.IsEnabled = noDate.IsChecked != true;
                FormLabel(panel, "Завершение", endDate);
            }
            if (entry.Kind == EntryKind.Goal)
            {
                var deadline = Text("", 13, accent, true);
                Identify(deadline, "goal-deadline");
                deadline.Margin = new Thickness(0, 0, 0, 13);
                Action showDeadline = () =>
                {
                    var selected = kind.SelectedItem as ComboBoxItem;
                    if (selected == null || !date.Value.HasValue) { deadline.Text = ""; return; }
                    DateTime start = date.Value.Value;
                    if (start.Year > 9997) { deadline.Text = ""; return; }
                    DateTime due = editing && entry.Day == start && entry.Period == (Period)selected.Tag && entry.TargetDay.HasValue ?
                        entry.TargetDay.Value : CalendarRules.Shift((Period)selected.Tag, start, 1);
                    deadline.Text = "Завершение · " + due.ToString("dd.MM.yyyy");
                };
                kind.SelectionChanged += (sender, e) => showDeadline();
                date.Input.TextChanged += (sender, e) => showDeadline();
                showDeadline();
                panel.Children.Add(deadline);
            }
            ComboBox parent = null;
            if (entry.Kind == EntryKind.Subgoal || entry.Kind == EntryKind.Task)
            {
                parent = ParentPicker(entry, parents);
                FormLabel(panel, entry.Kind == EntryKind.Subgoal ? "Родительская цель" : "Подцель", parent);
            }
            ComboBox assignment = null;
            if ((entry.Kind == EntryKind.Task || entry.Kind == EntryKind.Goal) && planner.Columns.Count > 0)
            {
                assignment = SelectList("assignment");
                assignment.Items.Add(new ComboBoxItem { Content = "Входящие", IsSelected = entry.BoardColumn == null });
                foreach (BoardColumn column in planner.Columns)
                {
                    var option = new ComboBoxItem { Content = column.Title, Tag = column.Id, IsSelected = column.Id == entry.BoardColumn };
                    Identify(option, "assign-" + column.Id);
                    assignment.Items.Add(option);
                }
                if (assignment.SelectedIndex < 0) assignment.SelectedIndex = 0;
                FormLabel(panel, "Столбец", assignment);
                if (entry.Kind == EntryKind.Task && parent != null)
                {
                    Action updateAssignment = () =>
                    {
                        var choice = parent.SelectedItem as ComboBoxItem;
                        assignment.IsEnabled = choice == null || choice.Tag == null;
                        assignment.ToolTip = assignment.IsEnabled ? null : "Столбец наследуется от подцели";
                    };
                    parent.SelectionChanged += (sender, e) => updateAssignment();
                    updateAssignment();
                }
            }
            if (entry.Kind != EntryKind.Habit)
                panel.Children.Add(PriorityField(entry.Priority, value => draft.Priority = value));
            var notes = Input("description", entry.Notes, true);
            FormLabel(panel, "Описание", notes);
            var error = Text("", 13, Ink("#A43236"));
            Identify(error, "form-error");
            error.Margin = new Thickness(0, 0, 0, 8);
            error.Visibility = Visibility.Collapsed;
            panel.Children.Add(error);
            if (time != null) time.TextChanged += (sender, e) => error.Visibility = Visibility.Collapsed;
            Action finish = () =>
            {
                error.Visibility = Visibility.Collapsed;
                try
                {
                    draft.Title = title.Text;
                    draft.Notes = notes.Text;
                    draft.Day = optionalDate && noDate.IsChecked == true ? (DateTime?)null : ReadPickedDate(date, permitted);
                    if (endDate != null)
                        draft.TargetDay = noDate.IsChecked == true ? (DateTime?)null : ReadPickedDate(endDate, null);
                    if (kind != null)
                    {
                        var selected = kind.SelectedItem as ComboBoxItem;
                        if (selected == null) throw new ArgumentException("Выберите период цели.");
                        draft.Period = (Period)selected.Tag;
                    }
                    if (assignment != null && assignment.SelectedItem != null)
                        draft.BoardColumn = (string)((ComboBoxItem)assignment.SelectedItem).Tag;
                    if (entry.Kind == EntryKind.Habit && draft.Day > planner.Marks(entry).DefaultIfEmpty(DateTime.MaxValue).Min())
                        throw new ArgumentException("Дата начала позже первой отметки привычки.");
                    if (parent != null && parent.SelectedItem != null)
                        draft.ParentId = (string)((ComboBoxItem)parent.SelectedItem).Tag;
                    else draft.ParentId = null;
                    if (time != null)
                    {
                        string value = time.Text.Trim();
                        TimeSpan parsed;
                        if (value.Length > 0)
                        {
                            if (!TimeSpan.TryParseExact(value, new[] { @"h\:mm", @"hh\:mm" }, CultureInfo.InvariantCulture, out parsed)
                                || parsed >= TimeSpan.FromDays(1))
                                throw new ArgumentException("Введите время в формате ЧЧ:ММ.");
                            draft.Time = parsed;
                        }
                        else draft.Time = null;
                    }

                    if (duration != null)
                    {
                        string rawMinutes = duration.Text.Trim();
                        int minutes;
                        if (rawMinutes.Length == 0) draft.DurationMinutes = null;
                        else if (Int32.TryParse(rawMinutes, NumberStyles.None, CultureInfo.InvariantCulture, out minutes)
                            && minutes >= 1 && minutes <= 1440) draft.DurationMinutes = minutes;
                        else throw new ArgumentException("Укажи длительность от 1 до 1440 минут.");
                    }
                    Entry result = planner.Save(draft);
                    if (result.Kind == EntryKind.Event && section == Section.Events) eventDate = result.Day.Value;
                    CloseDrawer(false);
                    Refresh();
                    if (editing || result.Kind == EntryKind.Subgoal || result.Kind == EntryKind.Goal)
                        ShowDetails(result.Id);
                    else
                    {
                        var add = FindControl(shell, "add") as Button;
                        if (add != null) add.Focus();
                    }
                }
                catch (ArgumentException invalid)
                {
                    error.Text = invalid.Message;
                    error.Visibility = Visibility.Visible;
                    error.BringIntoView();
                }
            };
            var actions = Horizontal();
            var save = Button("Сохранить", finish, "save", "primary");
            save.Margin = new Thickness(0, 0, 6, 0);
            actions.Children.Add(save);
            actions.Children.Add(Button("Отмена", () =>
            {
                if (editing) ShowDetails(entry.Id);
                else CloseDrawer();
            }, "cancel"));
            panel.Children.Add(actions);
            string heading = editing ? "Редактирование" :
                entry.Kind == EntryKind.Task ? "Новая задача" :
                entry.Kind == EntryKind.Goal ? "Новая цель" :
                entry.Kind == EntryKind.Subgoal ? "Новая подцель" :
                entry.Kind == EntryKind.Habit ? "Новая привычка" : "Новое событие";
            if (editing) HeadBeforeForm(panel, KindName(entry.Kind));
            OpenDrawer(heading, panel, null, finish);
            FocusInput(title);
        }

        private void FocusInput(TextBox input)
        {
            Dispatcher.BeginInvoke(DispatcherPriority.Input, new Action(() =>
            {
                if (input.IsLoaded)
                {
                    input.Focus();
                    input.SelectAll();
                }
            }));
        }

        private void HeadBeforeForm(StackPanel panel, string label)
        {
            var caption = Text(label, 12, accent, true);
            caption.Margin = new Thickness(0, 0, 0, 12);
            panel.Children.Insert(0, caption);
        }

        private DateTime ReadPickedDate(DateField picker, DateRange? permitted)
        {
            if (!picker.Value.HasValue)
                throw new ArgumentException("Выберите дату в календаре или введите её в формате ДД.ММ.ГГГГ.");
            DateTime day = picker.Value.Value;
            if (permitted.HasValue && !permitted.Value.Contains(day))
                throw new ArgumentException("Выберите день внутри открытого периода.");
            if (day < new DateTime(2, 1, 8) || day > new DateTime(9998, 12, 24))
                throw new ArgumentException("Дата находится за пределами календаря.");
            return day;
        }

        private void ShowDetails(string id)
        {
            Entry item = planner.Find(id);
            if (item == null || item.Title.Length == 0) return;
            var panel = new StackPanel();
            var category = Text(KindName(item.Kind), 12, accent, true);
            category.Margin = new Thickness(0, 0, 0, 4);
            panel.Children.Add(category);
            var title = Display(item.Title, 24);
            Identify(title, "detail-title");
            var titleRow = new DockPanel { LastChildFill = true };
            if (item.Kind == EntryKind.Subgoal && planner.CanCheck(item))
            {
                var square = ToggleButton(item.Checked, item.Title,
                    () => ToggleEntry(item, !item.Checked, true), "detail-check");
                square.Margin = new Thickness(0, 0, 6, 0);
                DockPanel.SetDock(square, Dock.Left);
                titleRow.Children.Add(square);
            }
            titleRow.Children.Add(title);
            panel.Children.Add(titleRow);
            var priority = Horizontal();
            priority.Margin = new Thickness(0, 8, 0, 2);
            priority.Children.Add(PriorityDot(item));
            priority.Children.Add(Text(Priorities[item.Priority] + " важность", 12, Muted));
            if (item.Kind != EntryKind.Habit) panel.Children.Add(priority);

            Entry parent = planner.Find(item.ParentId);
            if (parent != null)
                panel.Children.Add(Link(KindName(parent.Kind) + " · " + parent.Title, () => ShowDetails(parent.Id), "detail-parent"));
            if (item.Kind == EntryKind.Goal) DetailLine(panel, PlannerService.TermName(item.Period.Value));
            DateTime? date = item.TargetDay ?? item.Day;
            if (item.Kind == EntryKind.Goal || item.Kind == EntryKind.Subgoal)
                DetailLine(panel, PlannerService.Dates(item));
            else if (date.HasValue)
                DetailLine(panel, date.Value.ToString("d MMMM yyyy", CalendarRules.Russian) +
                    (item.Kind == EntryKind.Task && item.Time.HasValue ? " · " + item.Time.Value.ToString(@"hh\:mm") : ""));
            if (item.DurationMinutes.HasValue) DetailLine(panel, "План · " + FormatLoad(item.DurationMinutes.Value));
            if (item.Kind == EntryKind.Task && parent == null) DetailLine(panel, "Без подцели");
            if (item.BoardColumn != null) DetailLine(panel, ColumnName(item.BoardColumn));
            if (item.Notes.Length > 0)
            {
                var notes = Text(item.Notes, 14);
                notes.Margin = new Thickness(0, 9, 0, 3);
                panel.Children.Add(notes);
            }

            var actions = Horizontal();
            actions.Margin = new Thickness(0, 13, 0, 11);
            var edit = Button("Изменить", () => ShowForm(item, true), "edit", "outline");
            edit.Margin = new Thickness(0, 0, 5, 0);
            actions.Children.Add(edit);
            if (item.Kind == EntryKind.Task)
                actions.Children.Add(IconButton("\uE8AB", "Перенести задачу", () => ShowMove(item.Id), "detail-move", "outline"));
            var delete = IconButton("\uE74D", "Удалить", () => AskDelete(item), "delete", "plain");
            delete.Margin = new Thickness(6, 0, 0, 0);
            actions.Children.Add(delete);
            panel.Children.Add(actions);

            if (planner.CanCheck(item) && item.Kind != EntryKind.Subgoal)
            {
                bool checkedOff = item.Kind == EntryKind.Subgoal ? item.Checked : planner.Measure(item).Complete;
                var check = Button(checkedOff ? "Вернуть в работу" : item.Kind == EntryKind.Subgoal ? "Завершить подцель" : "Отметить выполненной", () =>
                {
                    ToggleEntry(item, !checkedOff);
                    if (!checkedOff && (item.Kind == EntryKind.Task || item.Kind == EntryKind.Subgoal)) return;
                    ShowDetails(id);
                }, "detail-check", "selected");
                check.Margin = new Thickness(0, 0, 0, 8);
                check.HorizontalAlignment = HorizontalAlignment.Left;
                panel.Children.Add(check);
            }
            if (item.Kind == EntryKind.Goal || item.Kind == EntryKind.Subgoal)
            {
                bool goal = item.Kind == EntryKind.Goal;
                var all = planner.Children(item).ToList();
                var items = Order(all.Where(child => child.Title.Length > 0 &&
                    (goal || !child.Checked))).ToList();
                if (all.Count > 0)
                    panel.Children.Add(Metrics(goal ? "Подцели завершены" : "Задачи выполнены",
                        planner.Measure(item), "detail-progress"));
                panel.Children.Add(Gap(14));
                Head(panel, (goal ? "Подцели" : "Задачи") + " · " + all.Count);
                RenderRows(panel, items, goal ? "Подцелей пока нет." : "Задач пока нет.", null, null, true);
                var finished = all.Where(child => child.Title.Length > 0 &&
                    child.ArchivedOn.HasValue && (child.Kind == EntryKind.Task ? child.Checked : planner.IsArchived(child))).ToList();
                if (!goal && finished.Count > 0)
                    panel.Children.Add(Link("Завершённые · " + finished.Count, () => ShowCompletedChildren(item.Id), "detail-completed"));
                if (goal)
                    panel.Children.Add(Link("+ Добавить подцель", () => NewSubgoal(id), "detail-add-child"));
                if (!goal && planner.CanAttachTaskTo(item))
                    panel.Children.Add(Link("+ Добавить задачу", () =>
                    {
                        NewTask(section == Section.Tasks ? anchor : planner.Today, id, null, planner.ColumnFor(item));
                    }, "detail-add-child"));
            }
            if (item.Kind == EntryKind.Habit) RenderHabitDetails(panel, item);
            OpenDrawer("Карточка", panel, () => ShowDetails(id));
        }

        private void DetailLine(StackPanel panel, string value)
        {
            var line = Text(value, 13, Muted);
            line.Margin = new Thickness(0, 6, 0, 0);
            panel.Children.Add(line);
        }

        private void ShowCompletedChildren(string id)
        {
            Entry item = planner.Find(id);
            if (item == null) return;
            var panel = new StackPanel();
            panel.Children.Add(Link("< " + item.Title, () => ShowDetails(id), "completed-back"));
            var finished = Order(planner.Children(item).Where(child => child.Title.Length > 0 &&
                child.ArchivedOn.HasValue && (child.Kind == EntryKind.Task ? child.Checked : planner.IsArchived(child))));
            RenderRows(panel, finished, "Архив пуст", null, null, true);
            OpenDrawer("Завершённые", panel, () => ShowCompletedChildren(id));
        }

        private void RenderHabitDetails(StackPanel panel, Entry item)
        {
            panel.Children.Add(Metrics(item.Mastered.HasValue ? "Привычка освоена" : "Дней подряд",
                new Progress(Math.Min(63, planner.Streak(item)), 63), "detail-streak"));
            if (!item.Mastered.HasValue && (!item.Day.HasValue || item.Day <= planner.Today))
            {
                bool marked = planner.Marks(item).Contains(planner.Today);
                var toggle = Button(marked ? "Снять сегодняшнюю отметку" : "Отметить сегодня",
                    () => CheckHabit(item, !marked), "detail-habit-check", "selected");
                toggle.Margin = new Thickness(0, 8, 0, 0);
                panel.Children.Add(toggle);
            }
            panel.Children.Add(Gap(13));
            Head(panel, "История отметок");
            panel.Children.Add(HabitTrack(item));
            var dates = planner.Marks(item).ToList();
            if (dates.Count == 0) Empty(panel, "Отметок пока нет.");
            foreach (DateTime date in dates)
                DetailLine(panel, date.ToString("d MMMM yyyy, dddd", CalendarRules.Russian));
        }

        private void ShowMove(string id)
        {
            Entry item = planner.Find(id);
            if (item == null) return;
            var panel = new StackPanel();
            Head(panel, item.Title, item.Day.HasValue ? "Назначено на " +
                item.Day.Value.ToString("d MMMM yyyy", CalendarRules.Russian) : "Без даты");
            var quick = Horizontal();
            quick.Margin = new Thickness(0, 0, 0, 12);
            var today = Button("Сегодня", () => MoveTo(item, planner.Today), "move-today", "outline");
            today.Margin = new Thickness(0, 0, 7, 0);
            quick.Children.Add(today);
            quick.Children.Add(Button("Завтра", () => MoveTo(item, planner.Today.AddDays(1)), "move-tomorrow", "outline"));
            panel.Children.Add(quick);
            var date = PickDate(item.Day, null);
            FormLabel(panel, "Другая дата", date);
            Action move = () => MoveTo(item, ReadPickedDate(date, null));
            panel.Children.Add(Button("Перенести", move, "move-save", "primary"));
            OpenDrawer("Перенести задачу", panel, null, move);
        }

        private void MoveTo(Entry item, DateTime day)
        {
            item = item.Copy();
            item.Day = day;
            planner.Save(item);
            CloseDrawer(false);
            Refresh();
            Notice("Задача перенесена на " + day.ToString("d MMMM yyyy", CalendarRules.Russian), "Открыть день", () =>
            {
                anchor = day;
                Navigate(Section.Day);
                Refresh(false);
                noticeHost.Children.Clear();
            });
        }

        private void AskDelete(Entry item)
        {
            int related = planner.Branch(item).Count - 1;
            if (related > 0)
            {
                var panel = new StackPanel();
                Head(panel, item.Title);
                panel.Children.Add(Text("Вместе с этой записью будут удалены связанные подцели и задачи (" + related + ").", 14));
                panel.Children.Add(Gap(10));
                var row = Horizontal();
                row.Children.Add(Button("Удалить", () => Delete(item), "confirm-delete", "primary"));
                row.Children.Add(Button("Отмена", () => ShowDetails(item.Id), "keep"));
                panel.Children.Add(row);
                OpenDrawer("Удалить запись?", panel);
            }
            else Delete(item);
        }

        private void Delete(Entry item)
        {
            planner.Delete(item);
            CloseDrawer(false);
            Refresh();
            Notice("Удалено · " + item.Title, "Отменить", () =>
            {
                planner.UndoDelete();
                noticeHost.Children.Clear();
                Refresh();
            });
        }
    }
}

