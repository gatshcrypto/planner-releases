using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace Planner
{
    internal sealed partial class MainWindow
    {
        internal sealed class DateField : UserControl
        {
            public TextBox Input;
            public Popup Popup;
            public DateTime? Value
            {
                get
                {
                    DateTime day;
                    return DateTime.TryParseExact(Input.Text.Trim(), new[] { "dd.MM.yyyy", "d.M.yyyy", "yyyy-MM-dd" },
                        CalendarRules.Russian, DateTimeStyles.None, out day) ? day.Date : (DateTime?)null;
                }
                set { Input.Text = value.HasValue ? value.Value.ToString("dd.MM.yyyy") : ""; }
            }
        }

        private DateField PickDate(DateTime? value, DateRange? range, string id = "date")
        {
            var field = new DateField();
            field.Input = Input(id + "-text", "");
            field.Input.MaxLength = 10;
            field.Value = value;
            var row = new DockPanel { LastChildFill = true };
            var button = IconButton("\uE787", "Открыть календарь", () => { }, id + "-calendar", "outline");
            button.Margin = new Thickness(5, 0, 0, 0);
            DockPanel.SetDock(button, Dock.Right);
            row.Children.Add(button);
            row.Children.Add(field.Input);
            field.Content = row;
            Identify(field, id);
            var popup = new Popup
            {
                PlacementTarget = row, Placement = PlacementMode.Bottom, StaysOpen = false, AllowsTransparency = true,
                PopupAnimation = testing || !SystemParameters.ClientAreaAnimation ? PopupAnimation.None : PopupAnimation.Fade,
                VerticalOffset = 4
            };
            field.Popup = popup;
            button.Click += (sender, e) =>
            {
                if (popup.IsOpen) { popup.IsOpen = false; return; }
                DateTime selected = field.Value ?? (range.HasValue ? range.Value.Start : planner.Today);
                if (range.HasValue && !range.Value.Contains(selected)) selected = range.Value.Start;
                if (selected < new DateTime(2, 1, 8) || selected > new DateTime(9998, 12, 24)) selected = planner.Today;
                ShowDateMonth(field, range, selected);
                popup.IsOpen = true;
            };
            field.Unloaded += (sender, e) => popup.IsOpen = false;
            return field;
        }

        private void ShowDateMonth(DateField field, DateRange? range, DateTime day)
        {
            DateRange month = CalendarRules.Range(Period.Month, day);
            var panel = new StackPanel();
            KeyboardNavigation.SetTabNavigation(panel, KeyboardNavigationMode.Cycle);
            panel.PreviewKeyDown += (sender, e) =>
            {
                if (e.Key != Key.Escape) return;
                field.Popup.IsOpen = false;
                field.Input.Focus();
                e.Handled = true;
            };
            var top = new DockPanel { LastChildFill = true, Margin = new Thickness(1, 0, 1, 3) };
            var prev = IconButton("\uE76B", "Предыдущий месяц", () => ShowDateMonth(field, range, day.AddMonths(-1)), "picker-prev", "plain");
            var next = IconButton("\uE76C", "Следующий месяц", () => ShowDateMonth(field, range, day.AddMonths(1)), "picker-next", "plain");
            prev.IsEnabled = month.Start > new DateTime(2, 2, 1) && (!range.HasValue || month.Start > range.Value.Start);
            next.IsEnabled = month.End < new DateTime(9998, 12, 1) && (!range.HasValue || month.End < range.Value.End);
            DockPanel.SetDock(prev, Dock.Left);
            DockPanel.SetDock(next, Dock.Right);
            top.Children.Add(prev);
            top.Children.Add(next);
            var heading = Text(CalendarRules.Label(Period.Month, day), 13, TextInk, true);
            heading.HorizontalAlignment = HorizontalAlignment.Center;
            top.Children.Add(heading);
            panel.Children.Add(top);
            panel.Children.Add(CalendarGrid(month, 32, (date, inside) =>
            {
                var cell = Button(date.Day.ToString(), () =>
                {
                    field.Value = date;
                    field.Popup.IsOpen = false;
                    field.Input.Focus();
                }, "picker-day-" + date.ToString("yyyyMMdd"), date == field.Value ? "selected" : "plain");
                cell.MinHeight = 27;
                cell.Padding = new Thickness(1, 0, 1, 0);
                cell.IsEnabled = (inside || range.HasValue) && (!range.HasValue || range.Value.Contains(date));
                if (date == planner.Today) cell.Foreground = accent;
                return cell;
            }));
            var frame = DashboardCard(panel);
            frame.Width = 296;
            frame.Padding = new Thickness(10, 8, 10, 9);
            frame.Margin = new Thickness(1, 1, 7, 8);
            frame.Effect = new System.Windows.Media.Effects.DropShadowEffect { BlurRadius = 13, ShadowDepth = 3, Opacity = .2 };
            field.Popup.Child = frame;
            Dispatcher.BeginInvoke(new Action(() => { if (field.Popup.IsOpen) panel.MoveFocus(new TraversalRequest(FocusNavigationDirection.First)); }));
        }

        private ControlTemplate TextFieldTemplate()
        {
            return (ControlTemplate)XamlReader.Parse(@"<ControlTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
                xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' TargetType='TextBox'>
                <Border Background='{TemplateBinding Background}' BorderBrush='{TemplateBinding BorderBrush}'
                        BorderThickness='{TemplateBinding BorderThickness}' CornerRadius='8'>
                    <ScrollViewer x:Name='PART_ContentHost' Padding='{TemplateBinding Padding}'/>
                </Border>
            </ControlTemplate>");
        }

        private ComboBox SelectList(string id)
        {
            var picker = new ComboBox
            {
                FontFamily = BodyFont, FontSize = 14, Background = CardPaper,
                Foreground = TextInk, BorderBrush = Line, BorderThickness = new Thickness(1),
                MinHeight = 38, MaxDropDownHeight = 275
            };
            Identify(picker, id);
            picker.Template = (ControlTemplate)XamlReader.Parse(@"<ControlTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
                xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' TargetType='ComboBox'>
                <Grid>
                    <ToggleButton Focusable='False' ClickMode='Press' Background='{TemplateBinding Background}'
                      BorderBrush='{TemplateBinding BorderBrush}'
                      IsChecked='{Binding IsDropDownOpen, Mode=TwoWay, RelativeSource={RelativeSource TemplatedParent}}'>
                        <ToggleButton.Template>
                          <ControlTemplate TargetType='ToggleButton'>
                            <Border Background='{TemplateBinding Background}' BorderBrush='{TemplateBinding BorderBrush}' BorderThickness='1' CornerRadius='8'>
                              <TextBlock Text='⌄' FontSize='16' Margin='0,0,10,2' HorizontalAlignment='Right' VerticalAlignment='Center'/>
                            </Border>
                          </ControlTemplate>
                        </ToggleButton.Template>
                    </ToggleButton>
                    <ContentPresenter Margin='10,5,28,5' VerticalAlignment='Center' IsHitTestVisible='False'
                         Content='{TemplateBinding SelectionBoxItem}' ContentTemplate='{TemplateBinding SelectionBoxItemTemplate}'/>
                    <Popup x:Name='PART_Popup' Placement='Bottom' IsOpen='{TemplateBinding IsDropDownOpen}'
                           AllowsTransparency='True' Focusable='False' PopupAnimation='None' VerticalOffset='4'>
                        <Border MinWidth='{TemplateBinding ActualWidth}' Padding='4' Background='{DynamicResource Planner.Card}'
                                BorderBrush='{DynamicResource Planner.Line}' BorderThickness='1' CornerRadius='9'>
                            <ScrollViewer MaxHeight='{TemplateBinding MaxDropDownHeight}' CanContentScroll='True'
                                          HorizontalScrollBarVisibility='Disabled' VerticalScrollBarVisibility='Auto'>
                                <ItemsPresenter KeyboardNavigation.DirectionalNavigation='Contained'/>
                            </ScrollViewer>
                        </Border>
                    </Popup>
                </Grid>
            </ControlTemplate>");
            picker.ItemContainerStyle = (Style)XamlReader.Parse(@"<Style xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
                xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' TargetType='ComboBoxItem'>
                <Setter Property='Padding' Value='7,6'/>
                <Setter Property='Template'>
                    <Setter.Value>
                        <ControlTemplate TargetType='ComboBoxItem'>
                            <Border x:Name='tile' Background='Transparent' CornerRadius='6' Padding='{TemplateBinding Padding}'
                               BorderThickness='1' BorderBrush='Transparent'>
                                <ContentPresenter VerticalAlignment='Center'/>
                            </Border>
                            <ControlTemplate.Triggers>
                                <Trigger Property='IsHighlighted' Value='True'>
                                    <Setter TargetName='tile' Property='Background' Value='{DynamicResource Planner.Hover}'/>
                                </Trigger>
                                <Trigger Property='IsSelected' Value='True'>
                                    <Setter TargetName='tile' Property='BorderBrush' Value='{DynamicResource Planner.Line}'/>
                                </Trigger>
                            </ControlTemplate.Triggers>
                        </ControlTemplate>
                    </Setter.Value>
                </Setter>
            </Style>");
            return picker;
        }

        private FrameworkElement PriorityField(int selected, Action<int> set)
        {
            var outer = new StackPanel { Margin = new Thickness(0, 0, 0, 13) };
            var label = Text("Важность", 12, Muted, true);
            label.Margin = new Thickness(0, 0, 0, 5);
            outer.Children.Add(label);
            var row = new WrapPanel();
            Action redraw = null;
            redraw = () =>
            {
                row.Children.Clear();
                for (int i = 0; i < Priorities.Length; i++)
                {
                    int value = i;
                    var select = Button(Priorities[i], () =>
                    {
                        selected = value;
                        set(value);
                        redraw();
                        ((Button)row.Children[value]).Focus();
                    },
                        "priority-" + i, selected == i ? "selected" : "outline");
                    select.ToolTip = Priorities[i] + " · " + PriorityNames[i];
                    Identify(select, null, (string)select.ToolTip + (selected == i ? ", выбрано" : ""));
                    select.Padding = new Thickness(7, 4, 8, 4);
                    select.MinHeight = 32;
                    select.Margin = new Thickness(0, 0, 4, 4);
                    var contents = Horizontal();
                    var flag = Glyph("\uE7C1", PriorityColors[i], 14);
                    flag.Margin = new Thickness(0, 0, 6, 0);
                    contents.Children.Add(flag);
                    contents.Children.Add(Text(Priorities[i], 12, selected == i ? accent : TextInk, true));
                    select.Content = contents;
                    row.Children.Add(select);
                }
            };
            redraw();
            outer.Children.Add(row);
            return outer;
        }
    }
}
