using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Planner
{
    internal sealed partial class MainWindow
    {
        private int summaryGoalsPage;
        private const int SummaryPageSize = 6;

        private void RenderSummary()
        {
            DateTime end = planner.Today.AddDays(1);
            var range = new DateRange(end.AddDays(-28), end);
            var tasks = planner.Tasks(range).ToList();
            var allGoals = planner.Entries.Where(item => item.Kind == EntryKind.Goal).ToList();
            var goals = Order(allGoals.Where(item => !planner.Measure(item).Complete)).ToList();
            var habits = planner.Entries.Where(item => item.Kind == EntryKind.Habit).ToList();

            var course = new Grid();
            course.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            course.ColumnDefinitions.Add(new ColumnDefinition());
            var ring = Ring(planner.Count(tasks), 118, true, "summary-tasks-overview");
            ring.Margin = new Thickness(0, 4, 15, 4);
            course.Children.Add(ring);
            var legend = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            legend.Children.Add(Text("ВЫПОЛНЕНИЕ ЗАДАЧ", 11, SoftWhite, true));
            var title = Text("Последние\n4 недели", 23, White, true);
            title.Margin = new Thickness(0, 7, 0, 7);
            title.ToolTip = "Выполненные задачи из назначенных на показанные 28 дней.";
            legend.Children.Add(title);
            legend.Children.Add(Text(range.Start.ToString("dd.MM") + " — " + planner.Today.ToString("dd.MM"), 12, SoftWhite));
            Grid.SetColumn(legend, 1);
            course.Children.Add(legend);
            var habitsToday = new StackPanel();
            Head(habitsToday, "Привычки сегодня");
            var today = CalendarRules.Range(Period.Day, planner.Today);
            habitsToday.Children.Add(Ring(HabitRate(habits, today), 100, false, "summary-habits-today"));
            var daily = Text("Отмечено за сегодня", 12, Muted);
            daily.HorizontalAlignment = HorizontalAlignment.Center;
            daily.Margin = new Thickness(0, 5, 0, 0);
            habitsToday.Children.Add(daily);
            content.Children.Add(Pair(Hero(course), DashboardCard(habitsToday), 1.8));
            content.Children.Add(Gap(22));

            SummaryGoals(goals);
            content.Children.Add(Gap(13));
            content.Children.Add(Pair(WeeklyTaskDashboard(tasks, range), MonthlyResults(), 1.5));
            content.Children.Add(Gap(12));

            var rhythm = new StackPanel();
            Head(rhythm, "История привычек");
            rhythm.Children.Add(HabitHeatmap(habits));
            var progress = new StackPanel();
            Head(progress, "Привычки");
            AddProgressRow(progress, "Привычки · последние 4 недели", HabitRate(habits, range), "summary-habits");
            var started = habits.Where(habit => habit.Day.HasValue && habit.Day <= planner.Today).ToList();
            AddProgressRow(progress, "Освоено привычек", new Progress(started.Count(habit => habit.Mastered.HasValue), started.Count), "summary-mastered-habits");
            content.Children.Add(Pair(DashboardCard(rhythm), DashboardCard(progress), 1.5));
            content.Children.Add(Gap(12));

            var directions = new StackPanel();
            Head(directions, "Задачи по направлениям");
            var groups = tasks.GroupBy(planner.ColumnFor).OrderByDescending(group => group.Count()).ToList();
            foreach (var group in groups.Take(5)) AddProgressRow(directions, ColumnName(group.Key), planner.Count(group), null);
            if (groups.Count > 5) AddProgressRow(directions, "Остальные", planner.Count(groups.Skip(5).SelectMany(group => group)), null);
            if (groups.Count == 0) directions.Children.Add(Text("—", 28, Muted));
            var priorities = new StackPanel();
            Head(priorities, "Задачи по приоритету");
            priorities.Children.Add(PercentBars(Enumerable.Range(0, Priorities.Length).Select(rank =>
                new ChartDatum(Priorities[rank], planner.Count(tasks.Where(task => task.Priority == rank)), null,
                    PriorityColors[rank])).ToList(), 115, false));
            content.Children.Add(Pair(DashboardCard(directions), DashboardCard(priorities)));
        }

        private void SummaryGoals(IList<Entry> goals)
        {
            int pages = Math.Max(1, (goals.Count + SummaryPageSize - 1) / SummaryPageSize);
            summaryGoalsPage = Math.Min(summaryGoalsPage, pages - 1);
            var header = new DockPanel { LastChildFill = true, Margin = new Thickness(0, 0, 0, 9) };
            if (pages > 1)
            {
                var paging = Horizontal();
                var back = IconButton("\uE76B", "Предыдущие цели", () => { summaryGoalsPage--; Refresh(); }, "summary-goals-prev", "plain");
                back.IsEnabled = summaryGoalsPage > 0;
                paging.Children.Add(back);
                paging.Children.Add(Text((summaryGoalsPage + 1) + " / " + pages, 12, Muted));
                var next = IconButton("\uE76C", "Следующие цели", () => { summaryGoalsPage++; Refresh(); }, "summary-goals-next", "plain");
                next.IsEnabled = summaryGoalsPage + 1 < pages;
                paging.Children.Add(next);
                DockPanel.SetDock(paging, Dock.Right);
                header.Children.Add(paging);
            }
            var completed = Button("Выполненные", () => ShowCompletedEntities(EntryKind.Goal), "summary-show-completed-goals", "outline");
            completed.Margin = new Thickness(0, 0, 10, 0);
            DockPanel.SetDock(completed, Dock.Right);
            header.Children.Add(completed);
            header.Children.Add(Text("Цели в работе", 18, TextInk, true));
            content.Children.Add(header);
            if (goals.Count == 0)
            {
                var empty = new StackPanel();
                empty.Children.Add(Button("+ Новая цель", () => NewGoal(Period.Month, FirstColumn()), "summary-new-goal", "outline"));
                content.Children.Add(DashboardCard(empty));
                return;
            }
            var grid = new Grid();
            Identify(grid, "summary-goal-grid");
            var cards = goals.Skip(summaryGoalsPage * SummaryPageSize).Take(SummaryPageSize).Select(SummaryGoalCard).ToList();
            for (int i = 0; i < 3; i++) grid.ColumnDefinitions.Add(new ColumnDefinition());
            foreach (FrameworkElement card in cards) grid.Children.Add(card);
            Action arrange = () =>
            {
                int columns = grid.ActualWidth >= 870 ? 3 : grid.ActualWidth >= 570 ? 2 : 1;
                int rows = (cards.Count + columns - 1) / columns;
                if (grid.RowDefinitions.Count != rows)
                {
                    grid.RowDefinitions.Clear();
                    for (int i = 0; i < rows; i++) grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                }
                for (int i = 0; i < 3; i++) grid.ColumnDefinitions[i].Width = i < columns ? new GridLength(1, GridUnitType.Star) : new GridLength(0);
                for (int i = 0; i < cards.Count; i++)
                {
                    Grid.SetColumn(cards[i], i % columns);
                    Grid.SetRow(cards[i], i / columns);
                    cards[i].Margin = new Thickness(0, 0, i % columns + 1 < columns ? 10 : 0, 10);
                }
            };
            grid.SizeChanged += (sender, e) => { if (e.WidthChanged) arrange(); };
            arrange();
            content.Children.Add(grid);
        }

        private FrameworkElement SummaryGoalCard(Entry goal)
        {
            var panel = new StackPanel();
            var context = new DockPanel { LastChildFill = true };
            var dot = PriorityDot(goal);
            DockPanel.SetDock(dot, Dock.Right);
            context.Children.Add(dot);
            context.Children.Add(Text(ColumnName(planner.ColumnFor(goal)), 11, Muted, true));
            panel.Children.Add(context);
            var row = new Grid { Margin = new Thickness(0, 14, 0, 3) };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(109) });
            row.ColumnDefinitions.Add(new ColumnDefinition());
            var ring = Ring(planner.Measure(goal), 96, false, "summary-goal-progress-" + goal.Id);
            ring.HorizontalAlignment = HorizontalAlignment.Left;
            row.Children.Add(ring);
            var copy = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            var name = Text(goal.Title, 16, TextInk, true);
            name.TextTrimming = TextTrimming.CharacterEllipsis;
            name.MaxHeight = 45;
            name.ToolTip = goal.Title;
            copy.Children.Add(name);
            string due = goal.TargetDay.HasValue ? "До " + goal.TargetDay.Value.ToString("dd MMM yyyy", CalendarRules.Russian) : "Без срока";
            var deadline = Text(due, 12, goal.TargetDay < planner.Today ? Ink("#A43236") : Muted);
            deadline.Margin = new Thickness(0, 7, 0, 0);
            copy.Children.Add(deadline);
            Grid.SetColumn(copy, 1);
            row.Children.Add(copy);
            panel.Children.Add(row);
            var button = Button(goal.Title, () => ShowDetails(goal.Id), "summary-goal-" + goal.Id);
            button.Content = panel;
            button.HorizontalContentAlignment = HorizontalAlignment.Stretch;
            button.Padding = new Thickness(0);
            var card = DashboardCard(button);
            return card;
        }

        private Border WeeklyTaskDashboard(IList<Entry> tasks, DateRange range)
        {
            var panel = new StackPanel();
            panel.Children.Add(ChartHeading("Выполнение задач", planner.Count(tasks), "summary-tasks"));
            var subtitle = Text("Последние 4 недели", 12, Muted);
            subtitle.Margin = new Thickness(0, 3, 0, 13);
            panel.Children.Add(subtitle);
            var chart = new Grid();
            Identify(chart, "summary-weekly-chart");
            for (int i = 0; i < 4; i++)
            {
                DateTime from = range.Start.AddDays(i * 7);
                var week = new DateRange(from, from.AddDays(7));
                Progress value = planner.Count(tasks.Where(task => task.Day.HasValue && week.Contains(task.Day.Value)));
                chart.ColumnDefinitions.Add(new ColumnDefinition());
                var slot = new StackPanel { Margin = new Thickness(5, 0, 5, 0) };
                var percent = MetricValue(value, "summary-week-" + i, 21, accent);
                percent.HorizontalAlignment = HorizontalAlignment.Center;
                slot.Children.Add(percent);
                var bar = new Grid { Height = 91, Width = 42, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 10, 0, 9) };
                bar.Children.Add(new Border { Background = accentWash, CornerRadius = new CornerRadius(9) });
                if (value.Percent > 0) bar.Children.Add(new Border { Height = .91 * value.Percent,
                    Background = accent, CornerRadius = new CornerRadius(9), VerticalAlignment = VerticalAlignment.Bottom });
                slot.Children.Add(bar);
                var date = Text(from.ToString("dd.MM") + "–" + week.End.AddDays(-1).ToString("dd.MM"), 10, Muted);
                date.HorizontalAlignment = HorizontalAlignment.Center;
                slot.Children.Add(date);
                slot.ToolTip = "Выполнено " + CountText(value) + " задач, назначенных на " + from.ToString("dd.MM.yyyy") +
                    " — " + week.End.AddDays(-1).ToString("dd.MM.yyyy");
                Grid.SetColumn(slot, i);
                chart.Children.Add(slot);
            }
            panel.Children.Add(chart);
            return DashboardCard(panel);
        }

        private Border MonthlyResults()
        {
            DateTime start = new DateTime(planner.Today.Year, planner.Today.Month, 1);
            DateTime end = planner.Today.AddDays(1);
            var panel = new StackPanel();
            Head(panel, "Результаты за месяц");
            panel.Children.Add(Text(CalendarRules.Capital(planner.Today.ToString("MMMM yyyy", CalendarRules.Russian)), 12, Muted));
            panel.Children.Add(Gap(13));
            foreach (EntryKind kind in new[] { EntryKind.Goal, EntryKind.Subgoal, EntryKind.Task })
            {
                int count = planner.Entries.Count(entry => entry.Kind == kind &&
                    (kind == EntryKind.Subgoal ? entry.Checked && entry.CompletedOn >= start && entry.CompletedOn < end :
                        planner.Measure(entry).Complete && entry.CompletedOn >= start && entry.CompletedOn < end));
                var row = new DockPanel { LastChildFill = true, Margin = new Thickness(0, 5, 0, 7) };
                var value = Text(count.ToString(), 28, accent, true);
                Identify(value, "summary-completed-" + kind);
                DockPanel.SetDock(value, Dock.Right);
                row.Children.Add(value);
                row.Children.Add(Text(kind == EntryKind.Goal ? "Завершено целей" : kind == EntryKind.Subgoal ? "Закрыто подцелей" : "Выполнено задач", 13, TextInk));
                panel.Children.Add(row);
            }
            panel.ToolTip = "За календарный месяц по дате выполнения. Учёт автоматического завершения целей — с " +
                store.Setting("completion_tracking_since", planner.Today.ToString("yyyy-MM-dd")) + ".";
            return DashboardCard(panel);
        }

        private FrameworkElement HabitHeatmap(IList<Entry> habits)
        {
            DateTime start = CalendarRules.Range(Period.Week, planner.Today).Start.AddDays(-84);
            var panel = new StackPanel();
            var dates = Text(start.ToString("dd MMM", CalendarRules.Russian) + " — " + planner.Today.ToString("dd MMM", CalendarRules.Russian), 12, Muted);
            dates.Margin = new Thickness(0, 0, 0, 13);
            panel.Children.Add(dates);
            var grid = new Grid { HorizontalAlignment = HorizontalAlignment.Left };
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(28) });
            for (int i = 0; i < 13; i++) grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(20) });
            for (int row = 0; row < 7; row++)
            {
                grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(20) });
                if (row == 0 || row == 2 || row == 4)
                {
                    var label = Text(row == 0 ? "Пн" : row == 2 ? "Ср" : "Пт", 10, Muted);
                    Grid.SetRow(label, row);
                    grid.Children.Add(label);
                }
            }
            for (int week = 0; week < 13; week++)
                for (int day = 0; day < 7; day++)
                {
                    DateTime date = start.AddDays(week * 7 + day);
                    Progress rate = HabitRate(habits, CalendarRules.Range(Period.Day, date));
                    bool future = date > planner.Today;
                    var tile = new Border { Width = 15, Height = 15, CornerRadius = new CornerRadius(4),
                        Background = future ? Clear : rate.Total == 0 ? Line : Blend(currentStyle.Paper, currentStyle.Accent, .12 + .88 * rate.Percent / 100.0),
                        BorderBrush = date == planner.Today ? accent : Clear, BorderThickness = new Thickness(1),
                        ToolTip = date.ToString("dd.MM.yyyy") + (future ? "" : " · " + CountText(rate)) };
                    Identify(tile, "summary-habit-day-" + date.ToString("yyyyMMdd"));
                    Grid.SetColumn(tile, week + 1);
                    Grid.SetRow(tile, day);
                    grid.Children.Add(tile);
                }
            panel.Children.Add(grid);
            var legend = Horizontal();
            legend.Margin = new Thickness(28, 12, 0, 0);
            legend.Children.Add(Text("0%", 10, Muted));
            for (int i = 0; i < 5; i++) legend.Children.Add(new Border { Width = 13, Height = 13, Margin = new Thickness(4, 0, 0, 0),
                CornerRadius = new CornerRadius(3), Background = Blend(currentStyle.Paper, currentStyle.Accent, .12 + .22 * i) });
            var last = Text("100%", 10, Muted);
            last.Margin = new Thickness(5, 0, 0, 0);
            legend.Children.Add(last);
            panel.Children.Add(legend);
            return panel;
        }
    }
}
