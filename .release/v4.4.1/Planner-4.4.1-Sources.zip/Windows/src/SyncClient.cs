using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Planner
{
    internal sealed class SyncClient : IDisposable
    {
        private readonly Store store;
        private readonly HttpClient http;
        private readonly CancellationTokenSource lifetime = new CancellationTokenSource();
        private string origin, token;
        private bool running;
        public bool Conflicted { get; private set; }
        public bool AuthenticationRequired { get; private set; }
        public bool Configured { get { return origin != null && token != null; } }
        public string ServerAddress { get { return origin; } }
        public string Status = "Не подключено";
        public Action Changed;
        public Action Applied;
        private string CredentialPath { get { return Path.Combine(store.DirectoryPath, "sync-session.dat"); } }
        public SyncClient(Store store, HttpMessageHandler handler = null)
        {
            this.store = store;
            http = handler == null ? new HttpClient(new HttpClientHandler { AllowAutoRedirect = false }) : new HttpClient(handler);
            http.Timeout = TimeSpan.FromSeconds(18);
            try
            {
                if (File.Exists(CredentialPath))
                {
                    var data = SyncDocument.Parse(Encoding.UTF8.GetString(ProtectedData.Unprotect(File.ReadAllBytes(CredentialPath), null, DataProtectionScope.CurrentUser)));
                    origin = ValidOrigin(SyncDocument.Text(data, "origin"), false); token = SyncDocument.Text(data, "token");
                    Status = "Ожидает синхронизации";
                }
            }
            catch (Exception error) { whenUnsupported(error); }
        }
        private void whenUnsupported(Exception error)
        {
            if (!(error is IOException || error is CryptographicException || error is ArgumentException || error is UnauthorizedAccessException)) throw error;
            Status = "Подключите устройство заново"; origin = token = null;
        }
        public static string ValidOrigin(string value, bool test)
        {
            Uri address;
            if (!Uri.TryCreate(value == null ? "" : value.Trim(), UriKind.Absolute, out address) ||
                (address.Scheme != "https" && !(test && address.IsLoopback && address.Scheme == "http")) ||
                address.UserInfo.Length != 0 || address.AbsolutePath != "/" || address.Query.Length != 0 || address.Fragment.Length != 0)
                throw new ArgumentException("Введите адрес планера целиком, начиная с https://.");
            return address.GetLeftPart(UriPartial.Authority);
        }
        public async Task ConnectAsync(string address, string code)
        {
            string location = ValidOrigin(address, false);
            var result = await Send(location, null, "/api/auth/exchange", HttpMethod.Post, SyncDocument.Object("code", code.Trim(), "native", true));
            string received = SyncDocument.Text(result, "token");
            if (received == null || received.Length != 43) throw new IOException("Сервер не подтвердил подключение.");
            byte[] secured = ProtectedData.Protect(Encoding.UTF8.GetBytes(SyncDocument.Write(SyncDocument.Object("origin", location, "token", received))), null, DataProtectionScope.CurrentUser);
            store.BackupBeforeSync();
            string temporary = CredentialPath + ".tmp";
            File.WriteAllBytes(temporary, secured);
            if (File.Exists(CredentialPath)) File.Replace(temporary, CredentialPath, null); else File.Move(temporary, CredentialPath);
            if (origin != location) store.Atomic(() => {
                store.SetSetting("sync-shadow", SyncDocument.Write(SyncDocument.Empty()));
                store.SetSetting("sync-native-base", SyncDocument.Write(SyncDocument.Empty()));
            });
            store.SetSetting("sync-origin", location);
            origin = location; token = received; AuthenticationRequired = false;
            await SynchronizeAsync(null);
        }
#if PLANNER_TESTS
        public void TestConnect(string address, string secret) { origin = ValidOrigin(address, true); token = secret; }
#endif
        public async Task SynchronizeAsync(bool? preferLocal)
        {
            if (running || !Configured || lifetime.IsCancellationRequested || (Conflicted && !preferLocal.HasValue)) return;
            running = true; Status = "Синхронизация…"; Notify();
            try
            {
                if (store.Setting("sync-origin", "") != origin) store.Atomic(() => {
                    store.SetSetting("sync-shadow", SyncDocument.Write(SyncDocument.Empty()));
                    store.SetSetting("sync-native-base", SyncDocument.Write(SyncDocument.Empty()));
                    store.SetSetting("sync-origin", origin);
                });
                var shadow = SyncDocument.Parse(store.Setting("sync-shadow", SyncDocument.Write(SyncDocument.Empty())));
                var nativeBase = SyncDocument.Parse(store.Setting("sync-native-base", SyncDocument.Write(SyncDocument.Empty())));
                var remote = await Send(origin, token, "/api/state", HttpMethod.Get, null);
                lifetime.Token.ThrowIfCancellationRequested();
                var capture = store.ExportSync();
                var local = SyncDocument.Overlay(shadow, nativeBase, capture);
                var remoteState = SyncDocument.Map(remote, "state");
                var conflicts = new List<string>();
                var merged = SyncDocument.Merge(shadow, local, remoteState, conflicts, preferLocal);
                if (conflicts.Count > 0 && !preferLocal.HasValue)
                { Conflicted = true; Status = "Есть изменения с другого устройства"; return; }
                long revision = Convert.ToInt64(SyncDocument.Get(remote, "revision"), CultureInfo.InvariantCulture);
                if (!SyncDocument.Equal(merged, remoteState))
                {
                    var saved = await Send(origin, token, "/api/state", HttpMethod.Put, SyncDocument.Object("state", merged, "revision", revision));
                    lifetime.Token.ThrowIfCancellationRequested();
                    if (SyncDocument.Get(saved, "state") != null) { Status = "Получены новые изменения; повторяем"; return; }
                    revision = Convert.ToInt64(SyncDocument.Get(saved, "revision"), CultureInfo.InvariantCulture);
                }
                Conflicted = AuthenticationRequired = false;
                if (SyncDocument.Equal(capture, store.ExportSync()))
                {
                    bool changed = !SyncDocument.Equal(nativeBase, capture) || !SyncDocument.Equal(shadow, merged);
                    store.ImportSync(merged, revision.ToString(CultureInfo.InvariantCulture));
                    Status = "Синхронизировано · " + DateTime.Now.ToString("HH:mm");
                    if (changed && Applied != null) Applied();
                }
                else
                {
                    // User edits made during the HTTP request stay in SQLite and are sent next.
                    store.Atomic(() => {
                        store.SetSetting("sync-shadow", SyncDocument.Write(merged));
                        store.SetSetting("sync-native-base", SyncDocument.Write(capture));
                        store.SetSetting("sync-revision", revision.ToString(CultureInfo.InvariantCulture));
                    });
                    Status = "Сохранено на устройстве · ожидает отправки";
                }
            }
            catch (OperationCanceledException) { if (!lifetime.IsCancellationRequested) Status = "Офлайн · данные сохранены на компьютере"; }
            catch (SyncAuthenticationException) { AuthenticationRequired = true; Status = "Подключите устройство заново"; }
            catch (HttpRequestException) { Status = "Офлайн · данные сохранены на компьютере"; }
            catch (Exception error) { Status = "Не удалось синхронизировать · " + error.Message; }
            finally { running = false; if (!lifetime.IsCancellationRequested) Notify(); }
        }
        private async Task<Dictionary<string, object>> Send(string location, string secret, string path, HttpMethod method, Dictionary<string, object> body)
        {
            using (var request = new HttpRequestMessage(method, location + path))
            {
                if (secret != null) request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", secret);
                if (body != null) request.Content = new StringContent(SyncDocument.Write(body), Encoding.UTF8, "application/json");
                using (var response = await http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, lifetime.Token))
                {
                    if (response.StatusCode == HttpStatusCode.Unauthorized) throw new SyncAuthenticationException();
                    string text;
                    using (var deadline = CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token))
                    using (var input = await response.Content.ReadAsStreamAsync())
                    using (var output = new MemoryStream())
                    {
                        deadline.CancelAfter(TimeSpan.FromSeconds(18));
                        byte[] buffer = new byte[16384]; int count;
                        while ((count = await input.ReadAsync(buffer, 0, buffer.Length, deadline.Token)) > 0)
                        {
                            if (output.Length + count > 2200000) throw new IOException("Объём данных превышает поддерживаемый.");
                            output.Write(buffer, 0, count);
                        }
                        text = Encoding.UTF8.GetString(output.ToArray());
                    }
                    Dictionary<string, object> data;
                    try { data = SyncDocument.Parse(text); } catch { throw new IOException("Сервер вернул неизвестный ответ."); }
                    if (!response.IsSuccessStatusCode && response.StatusCode != HttpStatusCode.Conflict) throw new IOException(SyncDocument.Text(data, "error") ?? "Сервер временно недоступен.");
                    return data;
                }
            }
        }
        private void Notify() { if (Changed != null) Changed(); }
        public void Disconnect() { lifetime.Cancel(); File.Delete(CredentialPath); origin = token = null; Status = "Не подключено"; Notify(); }
        public void Dispose() { lifetime.Cancel(); http.Dispose(); }
        private sealed class SyncAuthenticationException : Exception { public SyncAuthenticationException() : base("Код подключения недействителен. Получите новый в настройках телефона.") { } }
    }
}
