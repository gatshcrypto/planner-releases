using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace Planner
{
    // Runs on the owner's computer. Credentials never enter the published application/release.
    internal sealed class CloudflarePublisher : IDisposable
    {
        private const string ClientId = "54d11594-84e4-41aa-b438-e81b8fa78ee7";
        private const string Scopes = "account:read user:read workers:write workers_scripts:write d1:write offline_access";
        private const string Callback = "http://localhost:8976/oauth/callback";
        private const string ApiOrigin = "https://api.cloudflare.com/client/v4";
        private readonly HttpClient http;
        private readonly string folder;
        private readonly Func<byte[], byte[]> protect, unprotect;
        private readonly CancellationTokenSource cancellation = new CancellationTokenSource();
        private string accessToken;
        public string Origin, RecoveryFile;
        public Action<string> Progress;
        internal Action<string> OpenAuthorizationPage;
        public Func<List<Dictionary<string, object>>, Task<string>> ChooseAccount;
        public CloudflarePublisher(string directory, HttpMessageHandler handler = null, Func<byte[], byte[]> protectData = null, Func<byte[], byte[]> unprotectData = null)
        {
            folder = directory;
            http = new HttpClient(handler ?? new HttpClientHandler { AllowAutoRedirect = false, UseCookies = true });
            http.Timeout = TimeSpan.FromSeconds(45);
            protect = protectData ?? (bytes => ProtectedData.Protect(bytes, null, DataProtectionScope.CurrentUser));
            unprotect = unprotectData ?? (bytes => ProtectedData.Unprotect(bytes, null, DataProtectionScope.CurrentUser));
        }
        private void Report(string text) { if (Progress != null) Progress(text); }
        internal static string Base64(byte[] bytes) { return Convert.ToBase64String(bytes).TrimEnd('=').Replace('+', '-').Replace('/', '_'); }
        private static string RandomKey() { var bytes = new byte[32]; using (var random = RandomNumberGenerator.Create()) random.GetBytes(bytes); return Base64(bytes); }
        internal static string Challenge(string verifier) { using (var sha = SHA256.Create()) return Base64(sha.ComputeHash(Encoding.ASCII.GetBytes(verifier))); }
        public async Task AuthorizeAsync()
        {
            string storedAuth = Path.Combine(folder, "cloudflare-auth.dat");
            if (File.Exists(storedAuth))
            {
                try
                {
                    var saved = SyncDocument.Parse(Encoding.UTF8.GetString(unprotect(File.ReadAllBytes(storedAuth))));
                    var refreshed = await SendJson("https://dash.cloudflare.com/oauth2/token", HttpMethod.Post,
                        new FormUrlEncodedContent(new Dictionary<string, string> { { "grant_type", "refresh_token" }, { "client_id", ClientId }, { "refresh_token", S(saved, "refresh_token") } }), null);
                    RememberAuthorization(refreshed);
                    return;
                }
                catch (CloudError error) { if (error.Code != 400 && error.Code != 401) throw; }
                catch (CryptographicException) { }
            }
            string state = RandomKey(), verifier = RandomKey();
            var listener = new TcpListener(IPAddress.Loopback, 8976);
            try
            {
                listener.Start(4);
                using (var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellation.Token))
                {
                    timeout.CancelAfter(TimeSpan.FromMinutes(5));
                    using (timeout.Token.Register(() => listener.Stop()))
                    {
                        string url = "https://dash.cloudflare.com/oauth2/auth?response_type=code&client_id=" + ClientId +
                            "&redirect_uri=" + Uri.EscapeDataString(Callback) + "&scope=" + Uri.EscapeDataString(Scopes) +
                            "&state=" + state + "&code_challenge=" + Challenge(verifier) + "&code_challenge_method=S256";
                        Report("Подтвердите Cloudflare в открывшемся браузере");
                        if (OpenAuthorizationPage != null) OpenAuthorizationPage(url);
                        else Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
                        string code = null;
                        while (code == null)
                        {
                            using (var client = await listener.AcceptTcpClientAsync())
                            using (var stream = client.GetStream())
                            {
                                var request = new List<byte>(); var buffer = new byte[1024]; int count;
                                while (request.Count < 8192 && (count = await stream.ReadAsync(buffer, 0, buffer.Length, timeout.Token)) > 0)
                                {
                                    request.AddRange(buffer.Take(count));
                                    if (Encoding.ASCII.GetString(request.ToArray()).Contains("\r\n\r\n")) break;
                                }
                                string line = Encoding.ASCII.GetString(request.ToArray()).Split('\r')[0];
                                string[] parts = line.Split(' ');
                                Uri target;
                                bool valid = parts.Length == 3 && parts[0] == "GET" && parts[1].StartsWith("/") &&
                                    Uri.TryCreate("http://localhost:8976" + parts[1], UriKind.Absolute, out target);
                                target = valid ? new Uri("http://localhost:8976" + parts[1]) : new Uri(Callback);
                                var query = HttpUtility.ParseQueryString(target.Query);
                                valid = valid && target.AbsolutePath == "/oauth/callback" && query["state"] == state;
                                string html = valid ? "<!doctype html><meta charset=utf-8><title>Планер</title><p>Подключение подтверждено. Вернитесь в планер.</p>" : "<!doctype html><title>Planner</title><p>Invalid callback</p>";
                                byte[] body = Encoding.UTF8.GetBytes(html);
                                byte[] header = Encoding.ASCII.GetBytes("HTTP/1.1 " + (valid ? "200 OK" : "400 Bad Request") + "\r\nContent-Type: text/html; charset=utf-8\r\nCache-Control: no-store\r\nConnection: close\r\nContent-Length: " + body.Length + "\r\n\r\n");
                                await stream.WriteAsync(header, 0, header.Length, timeout.Token); await stream.WriteAsync(body, 0, body.Length, timeout.Token);
                                if (valid && query["error"] != null) throw new InvalidOperationException("Доступ Cloudflare не предоставлен.");
                                if (valid) code = query["code"];
                            }
                        }
                        var token = await SendJson("https://dash.cloudflare.com/oauth2/token", HttpMethod.Post,
                            new FormUrlEncodedContent(new Dictionary<string, string> { { "grant_type", "authorization_code" }, { "client_id", ClientId }, { "redirect_uri", Callback }, { "code", code }, { "code_verifier", verifier } }), null);
                        RememberAuthorization(token);
                    }
                }
            }
            catch (SocketException) { throw new InvalidOperationException("Порт подключения занят или время входа истекло. Закройте другое подключение Cloudflare и повторите."); }
            finally { listener.Stop(); }
        }
        private void RememberAuthorization(Dictionary<string, object> response)
        {
            accessToken = S(response, "access_token");
            if (String.IsNullOrEmpty(accessToken)) throw new InvalidOperationException("Cloudflare не подтвердил подключение. Повторите вход.");
            string refresh = S(response, "refresh_token");
            if (!String.IsNullOrEmpty(refresh))
            {
                Directory.CreateDirectory(folder);
                string path = Path.Combine(folder, "cloudflare-auth.dat"), temporary = path + ".tmp";
                File.WriteAllBytes(temporary, protect(Encoding.UTF8.GetBytes(SyncDocument.Write(SyncDocument.Object("refresh_token", refresh)))));
                if (File.Exists(path)) File.Replace(temporary, path, null); else File.Move(temporary, path);
            }
        }
        private async Task<Dictionary<string, object>> SendJson(string url, HttpMethod method, HttpContent content, string token)
        {
            using (var request = new HttpRequestMessage(method, url))
            {
                request.Headers.UserAgent.ParseAdd("PersonalPlanner/4.4");
                if (token != null) request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
                request.Content = content;
                using (var response = await http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, cancellation.Token))
                using (var deadline = CancellationTokenSource.CreateLinkedTokenSource(cancellation.Token))
                using (var stream = await response.Content.ReadAsStreamAsync())
                using (var memory = new MemoryStream())
                {
                    deadline.CancelAfter(TimeSpan.FromSeconds(45));
                    byte[] buffer = new byte[16384]; int count;
                    while ((count = await stream.ReadAsync(buffer, 0, buffer.Length, deadline.Token)) > 0)
                    { if (memory.Length + count > 3000000) throw new IOException("Слишком большой ответ сервера."); memory.Write(buffer, 0, count); }
                    Dictionary<string, object> data;
                    try { data = SyncDocument.Parse(Encoding.UTF8.GetString(memory.ToArray())); }
                    catch { throw new IOException("Сервер вернул неизвестный ответ (" + (int)response.StatusCode + ")."); }
                    if (!response.IsSuccessStatusCode || Object.Equals(SyncDocument.Get(data, "success"), false))
                    {
                        var errors = SyncDocument.Items(data, "errors");
                        int code = errors.Count == 0 ? (int)response.StatusCode : Convert.ToInt32(SyncDocument.Get(errors[0], "code"), CultureInfo.InvariantCulture);
                        throw new CloudError(code, "Cloudflare: " + (errors.Count == 0 ? SyncDocument.Text(data, "error") : SyncDocument.Text(errors[0], "message")));
                    }
                    return data;
                }
            }
        }
        private static HttpContent Json(object value) { return new StringContent(SyncDocument.Write(value), Encoding.UTF8, "application/json"); }
        private async Task<object> Api(string route, HttpMethod method = null, HttpContent content = null)
        {
            var result = await SendJson(ApiOrigin + route, method ?? HttpMethod.Get, content, accessToken);
            if (!Object.Equals(SyncDocument.Get(result, "success"), true)) throw new IOException("Cloudflare не подтвердил действие.");
            return SyncDocument.Get(result, "result");
        }
        private static List<Dictionary<string, object>> Records(object value) { return ((System.Collections.IEnumerable)value).Cast<object>().Select(item => (Dictionary<string, object>)item).ToList(); }
        private static Dictionary<string, object> Record(object value) { return (Dictionary<string, object>)value; }
        private static string S(Dictionary<string, object> data, string key) { return SyncDocument.Text(data, key); }

        public async Task<string> PublishAsync()
        {
            if (String.IsNullOrEmpty(accessToken)) throw new InvalidOperationException("Сначала подтвердите Cloudflare.");
            Report("Проверка аккаунта Cloudflare");
            var accounts = Records(await Api("/accounts"));
            if (accounts.Count == 0) throw new InvalidOperationException("Создайте бесплатный аккаунт Cloudflare и повторите подключение.");
            string accountId = accounts.Count == 1 ? S(accounts[0], "id") : null;
            if (accounts.Count > 1 && ChooseAccount != null)
            {
                var choice = ChooseAccount(accounts);
                await Task.WhenAny(choice, Task.Delay(Timeout.Infinite, cancellation.Token));
                cancellation.Token.ThrowIfCancellationRequested();
                accountId = await choice;
            }
            if (accountId == null || !accounts.Any(item => S(item, "id") == accountId)) throw new InvalidOperationException("Выберите аккаунт для планера.");
            string account = "/accounts/" + accountId, script = "mikhail-planner";
            var scripts = Records(await Api(account + "/workers/scripts"));
            string previousOwner = null;
            if (scripts.Any(item => S(item, "id") == script))
            {
                var settings = Record(await Api(account + "/workers/scripts/" + script + "/settings"));
                previousOwner = SyncDocument.Items(settings, "bindings").Where(item => S(item, "name") == "OWNER_ID").Select(item => S(item, "text")).FirstOrDefault();
                if (previousOwner == null) throw new InvalidOperationException("Имя mikhail-planner занято другим приложением. Оно не изменено.");
            }
            Directory.CreateDirectory(folder);
            string ownerFile = Path.Combine(folder, "owner.dat");
            Dictionary<string, object> owner;
            if (File.Exists(ownerFile)) owner = SyncDocument.Parse(Encoding.UTF8.GetString(unprotect(File.ReadAllBytes(ownerFile))));
            else
            {
                owner = SyncDocument.Object("owner", previousOwner ?? Guid.NewGuid().ToString("N"), "key", RandomKey(), "account", accountId);
                File.WriteAllBytes(ownerFile, protect(Encoding.UTF8.GetBytes(SyncDocument.Write(owner))));
            }
            if (S(owner, "account") != accountId || (previousOwner != null && S(owner, "owner") != previousOwner)) throw new InvalidOperationException("Сохранённое подключение относится к другому планеру. Данные не изменены.");
            Report("Подготовка личной базы данных");
            var databases = Records(await Api(account + "/d1/database"));
            var database = databases.FirstOrDefault(item => S(item, "name") == "planner-data") ?? Record(await Api(account + "/d1/database", HttpMethod.Post, Json(SyncDocument.Object("name", "planner-data"))));
            string databaseId = S(database, "uuid");
            using (var resource = typeof(CloudflarePublisher).Assembly.GetManifestResourceStream("Planner.PhoneServer"))
            using (var archive = new ZipArchive(resource, ZipArchiveMode.Read))
            {
                foreach (var migration in archive.Entries.Where(item => item.FullName.EndsWith(".sql")).OrderBy(item => item.FullName))
                {
                    string sql; using (var reader = new StreamReader(migration.Open(), Encoding.UTF8)) sql = reader.ReadToEnd();
                    sql = sql.Replace("CREATE TABLE ", "CREATE TABLE IF NOT EXISTS ").Replace("CREATE INDEX ", "CREATE INDEX IF NOT EXISTS ");
                    var results = Records(await Api(account + "/d1/database/" + databaseId + "/query", HttpMethod.Post, Json(SyncDocument.Object("sql", sql))));
                    if (results.Any(item => !Object.Equals(SyncDocument.Get(item, "success"), true))) throw new InvalidOperationException("База данных не подтвердила подготовку схемы.");
                }
                string subdomain;
                try { subdomain = S(Record(await Api(account + "/workers/subdomain")), "subdomain"); }
                catch (CloudError error) { if (error.Code != 10007 && error.Code != 404) throw; subdomain = null; }
                if (String.IsNullOrEmpty(subdomain))
                {
                    subdomain = "mikhail-planner-" + accountId.Substring(0, 6);
                    await Api(account + "/workers/subdomain", HttpMethod.Put, Json(SyncDocument.Object("subdomain", subdomain)));
                }
                Origin = "https://" + script + "." + subdomain + ".workers.dev";
                string scriptPath = account + "/workers/scripts/" + script;
                Report("Публикация приложения");
                using (var upload = new MultipartFormDataContent())
                {
                    var bindings = new[] { SyncDocument.Object("type", "d1", "name", "DB", "id", databaseId),
                        SyncDocument.Object("type", "plain_text", "name", "OWNER_ID", "text", S(owner, "owner")),
                        SyncDocument.Object("type", "plain_text", "name", "APP_ORIGIN", "text", Origin) };
                    upload.Add(Json(SyncDocument.Object("main_module", "independent.js", "compatibility_date", "2026-11-27", "bindings", bindings)), "metadata");
                    foreach (var module in archive.Entries.Where(item => item.FullName.EndsWith(".js")))
                    {
                        byte[] bytes; using (var input = module.Open()) using (var output = new MemoryStream()) { input.CopyTo(output); bytes = output.ToArray(); }
                        var content = new ByteArrayContent(bytes); content.Headers.ContentType = new MediaTypeHeaderValue("application/javascript+module");
                        upload.Add(content, module.Name, module.Name);
                    }
                    await Api(scriptPath, HttpMethod.Put, upload);
                }
                await Api(scriptPath + "/secrets", HttpMethod.Put, Json(SyncDocument.Object("name", "OWNER_KEY_HASH", "type", "secret_text", "text", Challenge(S(owner, "key")))));
                await Api(scriptPath + "/subdomain", HttpMethod.Post, Json(SyncDocument.Object("enabled", true, "previews_enabled", false)));
                await Api(scriptPath + "/schedules", HttpMethod.Put, Json(new[] { SyncDocument.Object("cron", "* * * * *") }));
            }
            // Save recovery access before network verification; a retry reuses the same owner/key.
            RecoveryFile = Path.Combine(folder, "Доступ к планеру.txt");
            owner["origin"] = Origin;
            File.WriteAllBytes(ownerFile, protect(Encoding.UTF8.GetBytes(SyncDocument.Write(owner))));
            File.WriteAllText(RecoveryFile, "Планер\r\n\r\nАдрес: " + Origin + "\r\nКлюч доступа: " + S(owner, "key") +
                "\r\n\r\nСохраните этот файл у себя. Ключ открывает личные данные. Не публикуйте его.\r\n", new UTF8Encoding(false));
            Report("Проверка опубликованного планера");
            Dictionary<string, object> signedIn = null;
            for (int attempt = 0; attempt < 10; attempt++)
            {
                try { signedIn = await SendJson(Origin + "/api/auth/login", HttpMethod.Post, Json(SyncDocument.Object("key", S(owner, "key"))), null); break; }
                catch (Exception error)
                {
                    if (!(error is HttpRequestException || error is IOException || error is CloudError) || attempt == 9) throw;
                }
                await Task.Delay(2000, cancellation.Token);
            }
            if (signedIn == null || S(signedIn, "user") != S(owner, "owner")) throw new InvalidOperationException("Сервер не подтвердил владельца данных.");
            var pair = await SendJson(Origin + "/api/auth/pair", HttpMethod.Post, Json(SyncDocument.Object()), null);
            if (S(pair, "code") == null) throw new InvalidOperationException("Сервер не выдал код подключения Windows.");
            return S(pair, "code");
        }
        public string ReadRecoveryKey()
        { return S(SyncDocument.Parse(Encoding.UTF8.GetString(unprotect(File.ReadAllBytes(Path.Combine(folder, "owner.dat"))))), "key"); }
#if PLANNER_TESTS
        internal void TestAuthorize(string token) { accessToken = token; }
#endif
        public void Cancel() { cancellation.Cancel(); }
        public void Dispose() { cancellation.Cancel(); accessToken = null; http.Dispose(); }
        private sealed class CloudError : Exception { public readonly int Code; public CloudError(int code, string message) : base(message) { Code = code; } }
    }
}
