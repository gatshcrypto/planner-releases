﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace Planner
{
    internal static partial class UiTest
    {
        private static readonly List<string> Results = new List<string>();

        private static void TestUpdates(Store store, string task, string folder)
        {
            const string digest = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad";
            const string repository = "planner-test/releases";
            const string json = "{\"tag_name\":\"v99.0.0\",\"assets\":[{\"name\":\"PlannerSetup.exe\",\"size\":3,\"" +
                "digest\":\"sha256:" + digest + "\",\"browser_download_url\":" +
                "\"https://github.com/" + repository + "/releases/download/v99.0.0/PlannerSetup.exe\"}]}";
            UpdateRelease release;
            using (var input = new MemoryStream(Encoding.UTF8.GetBytes(json)))
                release = UpdateClient.ReadRelease(input, repository, UpdateClient.Current);
            Assert(release != null && release.Version == new Version(99, 0, 0, 0),
                "Новая версия определяется по релизу GitHub");
            using (var input = new MemoryStream(Encoding.UTF8.GetBytes(json)))
                Assert(UpdateClient.ReadRelease(input, "another/repository", UpdateClient.Current) == null,
                    "Обновление из другого репозитория отклоняется");
            using (var input = new MemoryStream(Encoding.UTF8.GetBytes(json)))
                Assert(UpdateClient.ReadRelease(input, repository, release.Version) == null,
                    "Текущая версия не предлагается повторно");
            string file = Path.Combine(folder, "update-check.bin");
            File.WriteAllBytes(file, Encoding.ASCII.GetBytes("abc"));
            Assert(UpdateClient.ValidPackage(file, release), "Проверяется контрольная сумма скачанного обновления");
            File.WriteAllBytes(file, Encoding.ASCII.GetBytes("abd"));
            Assert(!UpdateClient.ValidPackage(file, release), "Повреждённое обновление отклоняется");
            store.BackupFor(release.Version);
            string backup = Path.Combine(store.DirectoryPath, "Backups", "planner-before-99.0.0.sqlite");
            using (var copy = new Store(backup))
                Assert(copy.ReadEntries().Any(entry => entry.Id == task), "Резервная копия базы сохраняет задачи");
        }

        private static void VerifyChronologicalOrder(MainWindow window, Store store, PlannerService planner, string folder)
        {
            DateTime today = planner.Today;
            var column = planner.SaveColumn(new BoardColumn { Position = planner.Columns.Count }, "Порядок");
            var late = planner.Save(new Entry { Kind = EntryKind.Task, Title = "А · Завтра", Day = today.AddDays(1),
                Time = new TimeSpan(7, 0, 0), Priority = 3, BoardColumn = column.Id });
            var early = planner.Save(new Entry { Kind = EntryKind.Task, Title = "Я · Утро", Day = today,
                Time = new TimeSpan(8, 0, 0), BoardColumn = column.Id });
            var evening = planner.Save(new Entry { Kind = EntryKind.Task, Title = "А · Вечер", Day = today,
                Time = new TimeSpan(18, 0, 0), Priority = 3, BoardColumn = column.Id });
            var first = planner.Save(new Entry { Kind = EntryKind.Task, Title = "Я · Первая", Day = today,
                Time = new TimeSpan(9, 0, 0), BoardColumn = column.Id });
            var second = planner.Save(new Entry { Kind = EntryKind.Task, Title = "А · Вторая", Day = today,
                Time = new TimeSpan(9, 0, 0), Priority = 3, BoardColumn = column.Id });
            var noTime = planner.Save(new Entry { Kind = EntryKind.Task, Title = "А · Без времени", Day = today,
                BoardColumn = column.Id });
            string[] expected = { early.Id, first.Id, second.Id, evening.Id, noTime.Id, late.Id };
            Assert(PlannerService.Chronological(planner.Entries.Where(entry => entry.BoardColumn == column.Id))
                .Select(entry => entry.Id).SequenceEqual(expected), "Сначала дата и время, затем стабильный порядок добавления");
            var edited = planner.Find(first.Id).Copy();
            edited.Title = "Новое название";
            edited.Priority = 3;
            planner.Save(edited);
            using (var reopened = new Store(Path.Combine(folder, "planner.sqlite")))
                Assert(PlannerService.Chronological(reopened.ReadEntries().Where(entry => entry.BoardColumn == column.Id))
                    .Select(entry => entry.Id).SequenceEqual(expected), "Редактирование и перезапуск сохраняют порядок при равном времени");
            window.Width = 1240;
            window.Height = 805;
            Click(window, "nav-Goals");
            Click(window, "nav-Tasks");
            double previous = Double.MinValue;
            foreach (string id in expected.Take(expected.Length - 1))
            {
                FrameworkElement row = Find<FrameworkElement>(window, "row-" + id);
                double position = row.TranslatePoint(new Point(0, 0), window).Y;
                Assert(position > previous, "Задача отображается по времени: " + planner.Find(id).Title);
                previous = position;
            }
            var goal = planner.Save(new Entry { Kind = EntryKind.Goal, Title = "Сортировка подцелей",
                Day = today, Period = Period.Year, BoardColumn = column.Id });
            var stepLate = planner.Save(new Entry { Kind = EntryKind.Subgoal, Title = "А · Поздняя",
                ParentId = goal.Id, Day = today.AddDays(-2), TargetDay = today.AddDays(20), Priority = 3 });
            var stepEarly = planner.Save(new Entry { Kind = EntryKind.Subgoal, Title = "Я · Ближайшая",
                ParentId = goal.Id, Day = today, TargetDay = today.AddDays(2) });
            var stepUndated = planner.Save(new Entry { Kind = EntryKind.Subgoal, Title = "Без срока", ParentId = goal.Id });
            Assert(PlannerService.Chronological(planner.Children(goal)).Select(entry => entry.Id)
                .SequenceEqual(new[] { stepEarly.Id, stepLate.Id, stepUndated.Id }),
                "Подцели сортируются по завершению, независимо от начала и важности");
            Click(window, "nav-Subgoals");
            double earlyY = Find<FrameworkElement>(window, "row-" + stepEarly.Id).TranslatePoint(new Point(), window).Y;
            double lateY = Find<FrameworkElement>(window, "row-" + stepLate.Id).TranslatePoint(new Point(), window).Y;
            Assert(earlyY < lateY, "Сортировка подцелей применяется на доске");
            Click(window, "nav-Goals");
            Click(window, "open-" + goal.Id);
            earlyY = Find<FrameworkElement>(window, "row-" + stepEarly.Id).TranslatePoint(new Point(), window).Y;
            lateY = Find<FrameworkElement>(window, "row-" + stepLate.Id).TranslatePoint(new Point(), window).Y;
            Assert(earlyY < lateY, "Сортировка подцелей применяется внутри цели");
            Click(window, "close-drawer");
            var weekGoal = planner.Save(new Entry { Kind = EntryKind.Goal, Title = "Я · Неделя", Day = today.AddDays(2), Period = Period.Week });
            Assert(PlannerService.Chronological(new[] { goal, weekGoal }).First().Id == weekGoal.Id,
                "Цели сортируются по ближайшей дате завершения");
        }

        private static void VerifyBoardWheel(MainWindow window, PlannerService planner)
        {
            var column = planner.Columns.First();
            Entry card = null;
            for (int i = 0; i < 18; i++)
                card = planner.Save(new Entry { Kind = EntryKind.Task, Title = "Прокрутка " + i,
                    Day = planner.Today, BoardColumn = column.Id });
            Click(window, "nav-Tasks");
            window.Height = 580;
            Layout(window);
            var outer = Find<ScrollViewer>(window, "main-scroll");
            var board = Find<ScrollViewer>(window, "board-scroll");
            Assert(outer.ScrollableHeight > 0, "Тестовая доска имеет вертикальную прокрутку");
            outer.ScrollToVerticalOffset(0);
            Layout(window);
            Wheel(board, -120);
            Layout(window);
            Assert(outer.VerticalOffset > 0 && board.HorizontalOffset == 0,
                "Колёсико над столбцами прокручивает страницу вниз");
            double afterDown = outer.VerticalOffset;
            Wheel(board, 120);
            Layout(window);
            Assert(outer.VerticalOffset < afterDown, "Колёсико над столбцами прокручивает страницу вверх");
            outer.ScrollToVerticalOffset(0);
            Layout(window);
            Wheel(Find<Button>(window, "open-" + card.Id), -120);
            Layout(window);
            Assert(outer.VerticalOffset > 0, "Колёсико над кнопкой задачи прокручивает страницу");
            outer.ScrollToBottom();
            Layout(window);
            double bottom = outer.VerticalOffset;
            Wheel(Find<Button>(window, "open-" + card.Id), 120);
            Layout(window);
            Assert(outer.VerticalOffset < bottom, "Прокрутка вверх работает из нижней части списка");
        }

        private static void VerifySummaryCompletion(MainWindow window, Store store, PlannerService planner, string folder)
        {
            DateTime today = planner.Today;
            var goal = planner.Save(new Entry { Kind = EntryKind.Goal, Title = "Новый запуск",
                Day = today.AddDays(-3), Period = Period.Week, BoardColumn = planner.Columns.First().Id });
            var first = planner.Save(new Entry { Kind = EntryKind.Subgoal, Title = "Проверить продукт", ParentId = goal.Id });
            var second = planner.Save(new Entry { Kind = EntryKind.Subgoal, Title = "Подготовить публикацию", ParentId = goal.Id });
            var task = planner.Save(new Entry { Kind = EntryKind.Task, Title = "Пройти сценарий", ParentId = first.Id, Day = today });
            var task2 = planner.Save(new Entry { Kind = EntryKind.Task, Title = "Сохранить результат", ParentId = first.Id, Day = today });
            Click(window, "nav-Tasks");
            Click(window, "nav-Subgoals");
            Assert(!Has(window, "check-" + first.Id), "У подцели с незавершёнными задачами нет квадрата выполнения");
            planner.SetChecked(task, true);
            planner.SetChecked(task2, true);
            Click(window, "nav-Tasks");
            Click(window, "nav-Subgoals");
            Assert(Has(window, "check-" + first.Id) && Has(window, "open-" + first.Id) && !planner.Find(first.Id).Checked && !Has(window, "finish-" + first.Id),
                "Все задачи выполнены: появляется маленький квадрат вместо кнопки Завершить");
            var square = Find<Button>(window, "check-" + first.Id);
            var squareFrame = square.Content as Border;
            Assert(squareFrame != null && squareFrame.Width == 20 && squareFrame.Child == null &&
                square.TranslatePoint(new Point(), window).X < Find<Button>(window, "open-" + first.Id).TranslatePoint(new Point(), window).X,
                "Квадрат слева пустой до ручного подтверждения, хотя задачи выполнены на 100%");
            Assert(planner.Measure(goal).Percent == 50, "Готовая подцель даёт свою долю прогресса цели");
            Assert(!Has(window, "entity-progress") && Read(window, "progress-" + first.Id) == "100%" &&
                Has(window, "subgoal-ring-" + first.Id) && !Has(window, "subgoal-ring-" + second.Id),
                "В подцелях нет общего дашборда; собственное кольцо есть только у подцели с задачами");
            Click(window, "check-" + first.Id);
            Assert(!Has(window, "entity-progress") && planner.Measure(goal).Percent == 50,
                "Закрытие подцели сохраняет вклад в её цель без общего процента подцелей");
            Assert(!Has(window, "open-" + first.Id) && planner.Find(first.Id).ArchivedOn == today && planner.Measure(goal).Percent == 50,
                "Подтверждённая подцель скрывается с сохранением прогресса цели");
            Click(window, "settings");
            Click(window, "open-archive");
            Assert(Has(window, "archive-open-" + first.Id), "Подцель доступна в общем архиве");
            Click(window, "archive-open-" + first.Id);
            Click(window, "detail-completed");
            Assert(Has(window, "open-" + task.Id) && Has(window, "open-" + task2.Id), "Архивная подцель открывает выполненные задачи");
            Click(window, "open-" + task.Id);
            Assert(Read(window, "detail-title") == task.Title, "Выполненная задача открывается для просмотра");
            Click(window, "close-drawer");
            var edited = planner.Find(task.Id).Copy();
            edited.Title = "Пройти сценарий ещё раз";
            planner.Save(edited);
            Assert(planner.Find(first.Id).Checked, "Редактирование выполненной задачи сохраняет подтверждение подцели");
            using (var reopened = new Store(Path.Combine(folder, "planner.sqlite")))
            {
                var copy = new PlannerService(reopened, () => planner.Now);
                Assert(copy.Find(first.Id).Checked && copy.Find(first.Id).ArchivedOn == today && copy.Measure(copy.Find(goal.Id)).Percent == 50,
                    "Подтверждение, архив и вклад в цель сохраняются после открытия базы заново");
            }
            planner.SetChecked(planner.Find(task.Id), false);
            Assert(!planner.Find(first.Id).Checked && !planner.Find(first.Id).ArchivedOn.HasValue && planner.Measure(goal).Percent == 0,
                "Возврат задачи автоматически возвращает подцель в работу и пересчитывает цель");
            planner.SetChecked(planner.Find(task.Id), true);
            planner.SetChecked(planner.Find(first.Id), true);
            Click(window, "nav-Tasks");
            Click(window, "nav-Subgoals");
            Click(window, "settings");
            Click(window, "open-archive");
            Click(window, "archive-restore-" + first.Id);
            Assert(!planner.Find(first.Id).Checked && planner.Measure(goal).Percent == 50,
                "Восстановление подцели из архива сохраняет готовность задач и процент цели");
            Click(window, "close-drawer");
            planner.SetChecked(planner.Find(first.Id), true);
            bool rejected = false;
            try { planner.Save(new Entry { Kind = EntryKind.Task, Day = today, Title = "Проверка запрета", ParentId = first.Id }); }
            catch (ArgumentException) { rejected = true; }
            Assert(rejected && planner.Find(first.Id).Checked && planner.Measure(goal).Percent == 50,
                "Нельзя добавить задачу к выполненной подцели даже в обход формы");
            planner.SetChecked(planner.Find(first.Id), false);
            var added = planner.Save(new Entry { Kind = EntryKind.Task, Day = today, Title = "Дополнительная проверка", ParentId = first.Id });
            Assert(!planner.Find(first.Id).Checked && planner.Measure(goal).Percent == 0,
                "После снятия отметки можно добавить задачу, прогресс цели пересчитывается");
            planner.SetChecked(added, true);
            planner.SetChecked(planner.Find(first.Id), true);
            Click(window, "nav-Summary");
            Assert(Has(window, "summary-goal-" + goal.Id) && Read(window, "summary-goal-progress-" + goal.Id) == "50%",
                "Каждая активная цель получает кольцо с собственным прогрессом");
            Click(window, "summary-goal-" + goal.Id);
            Assert(Read(window, "detail-title") == goal.Title && Has(window, "open-" + first.Id) &&
                Has(window, "open-" + second.Id) && !Has(window, "detail-completed"),
                "Внутри цели сразу видны все подцели, включая выполненные");
            Assert((Find<Button>(window, "check-" + first.Id).Content as Border).Child != null,
                "У выполненной подцели внутри цели квадрат отмечен");
            Click(window, "check-" + first.Id);
            Assert(Read(window, "detail-title") == goal.Title && Has(window, "open-" + first.Id) && !planner.Find(first.Id).Checked,
                "Снятие квадрата не закрывает карточку цели и оставляет подцель на месте");
            Click(window, "check-" + first.Id);
            Assert(Read(window, "detail-title") == goal.Title && Has(window, "open-" + first.Id) && planner.Find(first.Id).Checked,
                "Повторное выполнение не прячет подцель внутри цели и не закрывает карточку");
            Screenshot(window, folder, "goal-all-subgoals.png");
            Click(window, "open-" + first.Id);
            Assert(Find<Button>(window, "detail-check").Content is Border,
                "В карточке подцели также маленький квадрат вместо текстовой кнопки");
            Click(window, "close-drawer");
            planner.SetChecked(second, true);
            Click(window, "nav-Tasks");
            Click(window, "nav-Summary");
            Assert(!Has(window, "summary-goal-" + goal.Id) && planner.Find(goal.Id).CompletedOn == today,
                "Завершённая цель исчезает из сводки и получает дату завершения");
            Assert(!Has(window, "summary-goals") && !Has(window, "summary-subgoals") && Has(window, "summary-tasks-overview"),
                "В сводке нет усреднённых процентов целей и подцелей");
            Click(window, "summary-show-completed-goals");
            Assert(Has(window, "open-" + goal.Id), "Из статистики открываются выполненные цели, которые она учитывает");
            string selectedGoal = AutomationProperties.GetName(Find<Button>(window, "goal-dashboard-open"));
            var selectedEntry = planner.Entries.First(entry => entry.Kind == EntryKind.Goal && entry.Title == selectedGoal);
            Assert(Read(window, "entity-progress") == planner.Measure(selectedEntry).Percent + "%" && !planner.Measure(selectedEntry).Complete,
                "Дашборд целей показывает процент конкретной активной цели");
            Click(window, "filter-0");
            Click(window, "nav-Summary");
            Assert(Has(window, "summary-weekly-chart") && Has(window, "summary-completed-Goal") &&
                Has(window, "summary-habit-day-" + today.ToString("yyyyMMdd")),
                "Сводка содержит недельные столбцы, результаты месяца и тепловую карту");
            var lastWeek = new DateRange(today.AddDays(-6), today.AddDays(1));
            Progress expected = planner.Count(planner.Tasks(lastWeek));
            Assert(Read(window, "summary-week-3") == (expected.Total == 0 ? "—" : expected.Percent + "%"),
                "Недельный процент рассчитан по сохранённым задачам за показанные даты");
            string finishedCount = Read(window, "summary-completed-Subgoal");
            planner.ClearArchive(first.Id);
            Click(window, "nav-Tasks");
            Click(window, "nav-Summary");
            Assert(planner.Measure(goal).Percent == 100 && Read(window, "summary-completed-Subgoal") == finishedCount,
                "Очистка архива не уменьшает прогресс цели и месячную статистику");
            planner.SetChecked(planner.Find(task2.Id), false);
            Click(window, "nav-Tasks");
            Click(window, "nav-Summary");
            Assert(Has(window, "summary-goal-" + goal.Id) && !planner.Find(goal.Id).CompletedOn.HasValue,
                "Возобновлённая цель возвращается в сводку");
            Assert(planner.Find(first.Id).Title == first.Title, "Возврат задачи после очистки архива восстанавливает исходное название подцели");
            var habit = planner.Entries.First(item => item.Kind == EntryKind.Habit);
            planner.SetHabit(habit, true);
            Click(window, "nav-Tasks");
            Click(window, "nav-Summary");
            Assert(Read(window, "summary-habits-today") == "100%", "Процент привычек сегодня обновляется из сохранённых отметок");
            for (int i = 0; i < 8; i++) planner.Save(new Entry { Kind = EntryKind.Goal, Title = "План " + (i + 1),
                Day = today, Period = Period.Year });
            Click(window, "nav-Tasks");
            Click(window, "nav-Summary");
            var grid = Find<Grid>(window, "summary-goal-grid");
            Assert(grid.Children.Count == 6 && Has(window, "summary-goals-next"), "Много целей показываются страницами по шесть колец");
            Click(window, "summary-goals-next");
            Assert(Find<Button>(window, "summary-goals-prev").IsEnabled, "Переключение страниц целей работает");
            Click(window, "summary-goals-prev");
            window.Width = 1240;
            window.Height = 805;
            Layout(window);
            Screenshot(window, folder, "summary-new.png");
            Find<ScrollViewer>(window, "main-scroll").ScrollToBottom();
            Layout(window);
            Screenshot(window, folder, "summary-stats.png");
            Find<ScrollViewer>(window, "main-scroll").ScrollToTop();
            window.Width = 740;
            window.Height = 580;
            Layout(window);
            Assert(Find<Grid>(window, "summary-goal-grid").RowDefinitions.Count == 6,
                "Кольца целей перестраиваются в один столбец в узком окне");
            Screenshot(window, folder, "summary-compact.png");
            Click(window, "nav-Goals");
            Assert(!Has(window, "entity-progress-label") && Read(window, "entity-dashboard-title") == "Прогресс цели" &&
                Has(window, "goal-dashboard-open"), "В дашборде показана конкретная цель без среднего процента");
            Click(window, "nav-Subgoals");
            Assert(!Has(window, "entity-dashboard-title"), "Раздел подцелей начинается сразу с фильтров и карточек");
            var longGoal = planner.Save(new Entry { Kind = EntryKind.Goal, Title = "Длинная цель", Day = today, Period = Period.Year });
            Entry last = null;
            for (int i = 0; i < 24; i++) last = planner.Save(new Entry { Kind = EntryKind.Subgoal, Title = "Этап " + (i + 1), ParentId = longGoal.Id });
            Click(window, "nav-Goals");
            Click(window, "open-" + longGoal.Id);
            var drawerScroll = Find<ScrollViewer>(window, "drawer-scroll");
            drawerScroll.ScrollToBottom();
            Layout(window);
            double offset = drawerScroll.VerticalOffset;
            Click(window, "check-" + last.Id);
            Assert(offset > 0 && Math.Abs(Find<ScrollViewer>(window, "drawer-scroll").VerticalOffset - offset) < 1,
                "Отметка в длинной цели сохраняет позицию прокрутки карточки");
            Assert(Has(window, "open-" + last.Id) && planner.Find(last.Id).Checked,
                "Выполненная подцель остаётся в длинном списке цели");
            Click(window, "close-drawer");
        }

        private static void Wheel(UIElement target, int delta)
        {
            target.RaiseEvent(new MouseWheelEventArgs(Mouse.PrimaryDevice, Environment.TickCount, delta)
            { RoutedEvent = Mouse.PreviewMouseWheelEvent });
        }

        private static void VerifyTaskScreen(MainWindow window, Store store, PlannerService planner)
        {
            DateTime today = planner.Today;
            var goal = planner.Save(new Entry { Kind = EntryKind.Goal, Period = Period.Month, Day = today, Title = "Проверка подцелей" });
            var closed = planner.Save(new Entry { Kind = EntryKind.Subgoal, ParentId = goal.Id, Title = "Выполненная подцель" });
            var active = planner.Save(new Entry { Kind = EntryKind.Subgoal, ParentId = goal.Id, Title = "Открытая подцель" });
            var old = planner.Save(new Entry { Kind = EntryKind.Task, ParentId = closed.Id, Day = today.AddDays(-1), Title = "Вчерашняя задача" });
            planner.SetChecked(old, true);
            planner.SetChecked(planner.Find(closed.Id), true);
            for (int i = 0; i < 4; ++i)
            {
                var task = planner.Save(new Entry { Kind = EntryKind.Task, Day = today.AddDays(-1), Title = "Старое дело " + i });
                planner.SetChecked(task, true);
            }
            Click(window, "nav-Goals");
            Click(window, "nav-Tasks");
            Assert(Read(window, "day-progress") == "—", "Вчерашние отметки не заполняют кольцо пустого дня");
            Assert(Has(window, "filter-0") && Has(window, "filter-1") && !Has(window, "filter-2"), "В задачах два фильтра");
            Click(window, "add");
            Assert(!Has(window, "no-date"), "У новой задачи нельзя отключить дату");
            var choices = Find<ComboBox>(window, "parent").Items.Cast<ComboBoxItem>().Select(item => (string)item.Tag).ToList();
            Assert(choices.Contains(active.Id) && !choices.Contains(closed.Id), "Форма новой задачи предлагает только незакрытые подцели");
            Select(window, "parent", "parent-choice-" + active.Id);
            Title(window, "Сегодня первое");
            Click(window, "save");
            Click(window, "add");
            Title(window, "Сегодня второе");
            Click(window, "save");
            Assert(Read(window, "day-progress") == "0%", "Пять выполненных вчера и две новые сегодня дают утром 0%, а не 71%");
            Click(window, "check-" + EntryByTitle(planner, "Сегодня первое").Id);
            Assert(Read(window, "day-progress") == "50%", "Выполнение одной из двух сегодняшних задач обновляет кольцо");
            Click(window, "weekly-chart-5");
            Assert(Read(window, "day-progress") == "100%" && !Has(window, "open-" + EntryByTitle(planner, "Сегодня второе").Id),
                "График переключает список и кольцо на вчерашний день");
            Click(window, "task-week-prev");
            Assert(Read(window, "task-selected-date") == CalendarRules.Label(Period.Day, today.AddDays(-8)), "График листается назад на семь дней");
            Click(window, "task-week-next");
            Assert(Read(window, "day-progress") == "100%", "График листается вперёд к прежнему дню и проценту");
            Click(window, "task-day-next");
            Click(window, "add");
            Title(window, "Задача на завтра");
            Find<TextBox>(window, "date-text").Text = "";
            Click(window, "save");
            Assert(!planner.Entries.Any(entry => entry.Title == "Задача на завтра"), "Пустая дата блокирует сохранение");
            Find<TextBox>(window, "date-text").Text = today.AddDays(1).ToString("dd.MM.yyyy");
            Click(window, "save");
            var tomorrow = EntryByTitle(planner, "Задача на завтра");
            Assert(!Has(window, "open-" + tomorrow.Id) && Read(window, "day-progress") == "50%",
                "Задача на завтра не появляется и не влияет на прогресс сегодня");
            Click(window, "task-day-next");
            Assert(Has(window, "open-" + tomorrow.Id) && !Has(window, "open-" + EntryByTitle(planner, "Сегодня второе").Id)
                && Read(window, "day-progress") == "0%", "На завтра показаны только его задачи и процент");
            var overdue = planner.Save(new Entry { Kind = EntryKind.Task, Day = today.AddDays(-2), Title = "Опоздание" });
            Click(window, "filter-1");
            Assert(Has(window, "overdue-card-" + overdue.Id) && !Has(window, "open-" + tomorrow.Id),
                "Просроченные видны отдельным фильтром и выделены алым");
            Click(window, "task-today");
            var oldUndated = new Entry { Kind = EntryKind.Task, Title = "Старая задача без даты" };
            store.Save(oldUndated);
            var upgraded = new PlannerService(store, planner.Clock);
            Assert(upgraded.Find(oldUndated.Id).Day == today, "Старые активные задачи без даты получают сегодняшнюю дату");
            planner.Reload();
            Click(window, "nav-Goals");
            Click(window, "open-" + goal.Id);
            Click(window, "open-" + closed.Id);
            Assert(!Has(window, "detail-add-child"), "Из закрытой подцели нельзя начать добавление задачи");
            Click(window, "detail-completed");
            Click(window, "open-" + old.Id);
            Click(window, "edit");
            Assert((string)((ComboBoxItem)Find<ComboBox>(window, "parent").SelectedItem).Tag == closed.Id,
                "Редактирование старой задачи сохраняет существующую привязку");
            Title(window, "Вчерашняя задача с правкой");
            Click(window, "save");
            Assert(planner.Find(old.Id).ParentId == closed.Id && planner.Find(closed.Id).Checked,
                "Обычная правка старой задачи не сбрасывает связь и отметку подцели");
            Click(window, "close-drawer");
            planner.ClearPlanning();
            Click(window, "nav-Tasks");
        }

        public static void Run(MainWindow window, Store store, PlannerService planner, string folder)
        {
            if (planner.Entries.Any()) throw new InvalidOperationException("Проверка требует пустую базу.");
            window.Show();
            Layout(window);
            Click(window, "settings");
            Click(window, "open-synchronization");
            Assert(Has(window, "sync-address") && Has(window, "sync-code") && Has(window, "sync-connect"),
                "Синхронизация открывает форму адреса и одноразового кода с действием подключения");
            Click(window, "setup-iphone");
            Assert(Has(window, "phone-setup-start"), "Настройка iPhone доступна одной кнопкой внутри планера");
            Click(window, "close-drawer");
            Assert(Has(window, "nav-Tasks") && Has(window, "nav-Subgoals") && Has(window, "nav-Goals") &&
                !Has(window, "nav-Day") && !Has(window, "nav-Week"), "Новая навигация по сущностям");
            VerifyTaskScreen(window, store, planner);
            VerifyFinance(window, store, planner, folder);
            VerifyBackups(window, folder);
            Click(window, "new-column");
            Find<TextBox>(window, "column-name").Text = "Работа";
            Click(window, "save-column");
            var work = planner.Columns.Single();
            VerifyGoalFilterScroll(window, store, planner, work);
            Click(window, "nav-Goals");
            Click(window, "column-create-" + work.Id);
            Assert(Find<ComboBox>(window, "goal-period").Items.Cast<ComboBoxItem>()
                .Select(item => (string)item.Content).SequenceEqual(new[] { "Неделя", "Месяц", "Год" }),
                "Сроки называются Неделя, Месяц, Год");
            Title(window, "Запустить проект");
            Select(window, "goal-period", "goal-period-Month");
            Assert(Read(window, "goal-deadline").Contains(planner.Today.AddMonths(1).ToString("dd.MM.yyyy")),
                "Форма показывает дату завершения от даты старта");
            Click(window, "save");
            var goal = EntryByTitle(planner, "Запустить проект");
            Assert(goal.Day == planner.Today && goal.TargetDay == planner.Today.AddMonths(1),
                "Месяц отсчитывается от сегодня");
            Click(window, "detail-add-child");
            Title(window, "Подготовить запуск");
            Find<CheckBox>(window, "no-date").IsChecked = false;
            Find<TextBox>(window, "date-text").Text = planner.Today.ToString("dd.MM.yyyy");
            Find<TextBox>(window, "end-date-text").Text = planner.Today.AddDays(7).ToString("dd.MM.yyyy");
            Click(window, "save");
            var step = EntryByTitle(planner, "Подготовить запуск");
            Assert(step.ParentId == goal.Id && step.TargetDay == planner.Today.AddDays(7) && step.BoardColumn == work.Id,
                "Подцель сохраняет диапазон, цель и наследует столбец");
            Click(window, "detail-add-child");
            Title(window, "Подготовить страницу");
            Find<TextBox>(window, "time").Text = "13:00";
            Click(window, "save");
            var task = EntryByTitle(planner, "Подготовить страницу");
            Click(window, "nav-Subgoals");
            Click(window, "open-" + step.Id);
            Click(window, "detail-add-child");
            Title(window, "Проверить оплату");
            Click(window, "save");
            var task2 = EntryByTitle(planner, "Проверить оплату");
            Assert(task2.Day == planner.Today && !task2.Time.HasValue && task2.ParentId == step.Id, "Связанная задача сохраняется с датой и без времени");
            var a = planner.Save(new Entry { Kind = EntryKind.Subgoal, Title = "Определить продукт", ParentId = goal.Id });
            var b = planner.Save(new Entry { Kind = EntryKind.Subgoal, Title = "Собрать версию", ParentId = goal.Id });
            var c = planner.Save(new Entry { Kind = EntryKind.Subgoal, Title = "Обратная связь", ParentId = goal.Id });
            planner.SetChecked(a, true);
            planner.SetChecked(b, true);
            planner.SetChecked(task, true);
            Assert(planner.Measure(step).Percent == 50 && planner.Measure(goal).Percent == 50,
                "Частичная подцель не засчитывается как завершённая в цели");
            planner.SetChecked(task2, true);
            Assert(planner.Measure(step).Complete && planner.Measure(goal).Percent == 75,
                "Завершённая подцель добавляет четверть прогресса");
            planner.SetChecked(c, true);
            Assert(planner.Measure(goal).Percent == 100, "Все подцели завершают цель");
            planner.SetChecked(planner.Find(task.Id), false);
            Assert(planner.Measure(step).Percent == 50 && planner.Measure(goal).Percent == 75,
                "Снятие отметки пересчитывает обе связи");
            Click(window, "nav-Tasks");
            Assert(Has(window, "open-" + task.Id) && !Has(window, "open-" + task2.Id), "Завершённая задача скрывается в архив");
            Click(window, "settings");
            Click(window, "open-archive");
            Assert(Has(window, "archive-task-" + task2.Id), "Завершённая задача доступна в архиве");
            Click(window, "archive-restore-" + task2.Id);
            Click(window, "close-drawer");
            Assert(Has(window, "open-" + task2.Id), "Архив восстанавливает задачу на её день");
            Click(window, "add");
            Title(window, "Самостоятельная задача");
            Click(window, "save");
            var free = EntryByTitle(planner, "Самостоятельная задача");
            Assert(free.ParentId == null && free.Day == planner.Today && free.Time == null, "Самостоятельная задача создаётся с датой и без времени");
            Click(window, "filter-0");
            Screenshot(window, folder, "tasks.png");
            Click(window, "nav-Subgoals");
            Assert(Has(window, "open-" + step.Id) && Has(window, "parent-" + step.Id),
                "Раздел подцелей показывает связь с целью");
            Click(window, "filter-4");
            Assert(!Has(window, "open-" + step.Id) && !Has(window, "open-" + c.Id), "Фильтр без срока скрывает датированные и архивные подцели");
            Click(window, "filter-0");
            Screenshot(window, folder, "subgoals.png");
            Click(window, "nav-Goals");
            Screenshot(window, folder, "goals.png");
            Click(window, "open-" + goal.Id);
            Click(window, "open-" + step.Id);
            Assert(Has(window, "detail-add-child") && Read(window, "detail-progress") == "0%",
                "Из цели открывается подцель со своим прогрессом");
            Click(window, "close-drawer");
            bool rejected = false;
            try { planner.Save(new Entry { Kind = EntryKind.Subgoal, Title = "Без цели" }); }
            catch (ArgumentException) { rejected = true; }
            Assert(rejected, "Подцель требует родительскую цель");
            var year = planner.Save(new Entry { Kind = EntryKind.Goal, Title = "Годовая цель", Day = planner.Today, Period = Period.Year });
            var week = planner.Save(new Entry { Kind = EntryKind.Goal, Title = "Неделя", Day = planner.Today, Period = Period.Week });
            Assert(year.TargetDay == planner.Today.AddYears(1) && week.TargetDay == planner.Today.AddDays(7), "Неделя и год отсчитываются от начала");
            var monthEnd = planner.Save(new Entry { Kind = EntryKind.Goal, Title = "Конец месяца", Day = new DateTime(2027, 1, 31), Period = Period.Month });
            Assert(monthEnd.TargetDay == new DateTime(2027, 2, 28), "Последний день короткого месяца");
            var leap = planner.Save(new Entry { Kind = EntryKind.Goal, Title = "Високосный год", Day = new DateTime(2028, 2, 29), Period = Period.Year });
            Assert(leap.TargetDay == new DateTime(2029, 2, 28), "Високосный год");
            var study = planner.SaveColumn(new BoardColumn { Position = 1 }, "Учёба");
            var moved = planner.Find(goal.Id).Copy();
            moved.BoardColumn = study.Id;
            planner.Save(moved);
            Assert(planner.Find(task.Id).BoardColumn == study.Id && planner.ColumnFor(planner.Find(step.Id)) == study.Id,
                "Перемещение цели переносит направление всех потомков");
            planner.SetChecked(planner.Find(task2.Id), true);
            int before = planner.Measure(step).Percent;
            planner.ClearArchive();
            Assert(planner.Measure(step).Percent == before, "Очистка архива сохраняет прогресс");
            planner.Delete(planner.Find(step.Id));
            planner.UndoDelete();
            Assert(planner.Find(task.Id).ParentId == step.Id, "Отмена удаления восстанавливает связи");
            TestUpdates(store, task.Id, folder);
            foreach (string name in new[] { "emerald", "ocean", "winter", "summer", "burgundy" })
            {
                Click(window, "settings");
                Click(window, "theme-" + name);
                Click(window, "close-drawer");
            }
            Assert(store.Setting("palette", "") == "burgundy", "Пять тем доступны в новой структуре");
            Click(window, "nav-Habits");
            Click(window, "add");
            Title(window, "Чтение");
            Click(window, "save");
            Click(window, "nav-Events");
            Click(window, "add");
            Title(window, "Конференция");
            Click(window, "save");
            Click(window, "nav-Summary");
            Assert(Has(window, "summary-tasks-overview") && Has(window, "summary-habits"), "Сводка открывается с задачами и привычками");
            Screenshot(window, folder, "summary.png");
            Click(window, "pomodoro");
            Click(window, "pomodoro-sounds");
            Assert(SoundChoice(window, "focus") == "Шаг вперёд", "Мелодии помодоро сохранены");
            VerifyCustomSound(window, store, folder);
            Click(window, "close-drawer");
            Click(window, "nav-Tasks");
            window.Width = 740;
            window.Height = 580;
            Layout(window);
            Screenshot(window, folder, "compact.png");
            Assert(Find<ScrollViewer>(window, "board-scroll").ScrollableWidth > 0, "Доска прокручивается в узком окне");
            using (var persisted = new Store(Path.Combine(folder, "planner.sqlite")))
            {
                var restored = new PlannerService(persisted, () => planner.Now);
                Assert(restored.Find(goal.Id).TargetDay == goal.TargetDay && restored.Find(free.Id).Day == planner.Today &&
                    restored.Find(task.Id).ParentId == step.Id, "Сроки, даты задач и связи сохраняются в базе");
            }
            VerifyChronologicalOrder(window, store, planner, folder);
            VerifySummaryCompletion(window, store, planner, folder);
            VerifyBoardWheel(window, planner);
            VerifyIllustratedDashboards(window, planner, folder);
            File.WriteAllLines(Path.Combine(folder, "test-result.txt"), Results);
            window.Close();
        }

        private static void VerifyIllustratedDashboards(MainWindow window, PlannerService planner, string folder)
        {
            window.Width = 1240;
            window.Height = 805;
            foreach (PlannerStyle style in PlannerStyle.Themes)
            {
                Click(window, "settings");
                Click(window, "theme-" + style.Key);
                Click(window, "close-drawer");
                Click(window, "nav-Goals");
                Assert(Has(window, "dashboard-landscape-Goals-" + style.Key) && !Has(window, "seasonal-drawing"),
                    style.Name + ": рисунок находится внутри дашборда целей, а не рядом с заголовком");
                var art = Find<Border>(window, "dashboard-landscape-Goals-" + style.Key);
                var title = Find<Button>(window, "goal-dashboard-open");
                Assert(art.Background is ImageBrush && art.ActualWidth > 150 &&
                    title.TranslatePoint(new Point(title.ActualWidth, 0), window).X <= art.TranslatePoint(new Point(), window).X,
                    style.Name + ": данные цели и иллюстрация имеют отдельное место");
                Screenshot(window, folder, "goal-art-" + style.Key + ".png");
                Click(window, "nav-Habits");
                Assert(Has(window, "dashboard-landscape-Habits-" + style.Key), style.Name + ": иллюстрация есть в привычках");
                Click(window, "nav-Events");
                Assert(Has(window, "dashboard-landscape-Events-" + style.Key), style.Name + ": иллюстрация есть в событиях");
                Click(window, "nav-Summary");
                Assert(Has(window, "dashboard-landscape-Summary-" + style.Key), style.Name + ": иллюстрация есть в сводке");
            }
            Click(window, "nav-Goals");
            string oldTitle = AutomationProperties.GetName(Find<Button>(window, "goal-dashboard-open"));
            Click(window, "goal-dashboard-next");
            string nextTitle = AutomationProperties.GetName(Find<Button>(window, "goal-dashboard-open"));
            var next = planner.Entries.First(entry => entry.Kind == EntryKind.Goal && entry.Title == nextTitle);
            Assert(oldTitle != nextTitle && Read(window, "entity-progress") == planner.Measure(next).Percent + "%",
                "Переключение целей меняет название и процент одной и той же записи");
            Click(window, "goal-dashboard-open");
            Assert(Read(window, "detail-title") == nextTitle, "Название на дашборде открывает выбранную цель");
            Click(window, "close-drawer");
            window.Width = 740;
            window.Height = 580;
            Layout(window);
            Assert(Find<Border>(window, "dashboard-landscape-Goals-burgundy").ActualWidth >= 80,
                "Иллюстрация остаётся видна в узком окне");
            Screenshot(window, folder, "goal-art-compact.png");
            Click(window, "nav-Habits");
            Screenshot(window, folder, "habit-art-compact.png");
        }

        public static void RunLegacy(MainWindow window, Store store, PlannerService planner, string folder)
        {
            if (planner.Entries.Any()) throw new InvalidOperationException("Проверка требует пустую тестовую базу.");
            DateTime today = planner.Today;
            var week = CalendarRules.Range(Period.Week, today);
            window.Show();
            Layout(window);
            Assert(Find<Image>(window, "planner-logo").Source == window.Icon, "Логотип виден в меню и окне");
            Assert(Read(window, "day-progress") == "—" && !Has(window, "column-create-none"), "Чистый день без фиктивного столбца");

            foreach (string name in new[] { "Работа", "Учёба", "Личное", "Спорт" })
            {
                Click(window, "new-column");
                Find<TextBox>(window, "column-name").Text = name;
                Click(window, "save-column");
            }
            var work = planner.Columns.Single(item => item.Title == "Работа");
            var study = planner.Columns.Single(item => item.Title == "Учёба");
            var sport = planner.Columns.Single(item => item.Title == "Спорт");
            Assert(planner.Columns.Count == 4 && Find<ScrollViewer>(window, "board-scroll").ScrollableWidth > 0,
                "Четыре реальных столбца и горизонтальная прокрутка");

            Click(window, "nav-Month");
            Click(window, "column-create-" + work.Id);
            var scope = Find<ComboBox>(window, "goal-period");
            Assert(scope.Items.Count == 3, "Доступны неделя, месяц и год");
            Title(window, "Завершить рабочий проект");
            Click(window, "save");
            var goal = EntryByTitle(planner, "Завершить рабочий проект");
            Click(window, "detail-add-child");
            Title(window, "Подготовить первую версию");
            Click(window, "save");
            var step = EntryByTitle(planner, "Подготовить первую версию");
            Assert(step.ParentId == goal.Id, "Подцель связана с целью");
            Click(window, "close-drawer");
            var lane = Find<Border>(window, "month-lane-" + work.Id);
            string stamp = today.ToString("yyyyMMdd");
            Assert(FindVisual(lane, "open-" + goal.Id) != null &&
                FindVisual(lane, "month-date-" + work.Id + "-" + stamp) != null &&
                !Has(window, "month-date-" + step.Id + "-" + stamp), "В месяце один календарь на ветку, цели лежат под ним");
            Assert(FindVisual(Find<Border>(window, "month-lane-" + study.Id), "open-" + goal.Id) == null,
                "Месячная цель показана только в назначенной ветке");

            Click(window, "nav-Week");
            Click(window, "add");
            Click(window, "add-goal");
            Title(window, "Сдать план на неделю");
            Click(window, "save");
            var weekly = EntryByTitle(planner, "Сдать план на неделю");
            Assert(weekly.Period == Period.Week && weekly.Day == week.Start, "Недельная цель сохранена");
            Click(window, "close-drawer");
            Assert(Has(window, "open-" + weekly.Id), "Недельная цель доступна в своей неделе");
            for (int i = 0; i < 7; i++)
            {
                string key = week.Start.AddDays(i).ToString("yyyyMMdd");
                Assert(Grid.GetRow(Find<FrameworkElement>(window, "week-cell-" + key + "-" + work.Id)) == i + 1 &&
                    Grid.GetRow(Find<FrameworkElement>(window, "week-cell-" + key + "-" + study.Id)) == i + 1,
                    "Дата " + key + " выровнена по веткам");
            }

            Click(window, "nav-Day");
            Click(window, "column-create-" + work.Id);
            Title(window, "Собрать черновик");
            Find<TextBox>(window, "time").Text = "10:30";
            Select(window, "parent", "parent-choice-" + step.Id);
            Click(window, "save");
            var task = EntryByTitle(planner, "Собрать черновик");
            Click(window, "column-create-" + study.Id);
            Title(window, "Разобрать материалы");
            Click(window, "save");
            var other = EntryByTitle(planner, "Разобрать материалы");
            TestUpdates(store, task.Id, folder);
            Assert(task.Day == today && task.Time == new TimeSpan(10, 30, 0) && task.ParentId == step.Id,
                "Дата, время и подцель сохраняются");
            Click(window, "check-" + task.Id);
            Assert(!Has(window, "open-" + task.Id) && Has(window, "open-" + other.Id) && Read(window, "day-progress") == "50%",
                "После отметки карточка исчезает с доски, процент сохраняет выполненное");
            Click(window, "nav-Week");
            Assert(!Has(window, "open-" + task.Id) && Has(window, "open-" + other.Id) &&
                Read(window, "period-task-progress") == "50%", "Архивные задачи скрыты и в неделе");
            Screenshot(window, folder, "week.png");
            Click(window, "nav-Month");
            Click(window, "month-date-" + work.Id + "-" + stamp);
            Assert(!Has(window, "open-" + task.Id) && Has(window, "open-" + step.Id),
                "Календарь открывает подцель ветки, выполненная задача остаётся в архиве");
            Click(window, "close-drawer");
            Screenshot(window, folder, "month.png");

            Click(window, "settings");
            Click(window, "open-archive");
            Assert(Has(window, "archive-task-" + task.Id), "Выполненная задача открывается из настроек");
            Screenshot(window, folder, "archive.png");
            Click(window, "archive-restore-" + task.Id);
            Assert(!Has(window, "archive-task-" + task.Id) && !planner.Find(task.Id).Checked,
                "Архив умеет вернуть задачу");
            Click(window, "close-drawer");
            Click(window, "nav-Day");
            Assert(Has(window, "open-" + task.Id), "Возврат восстановил задачу в той же ветке");
            Click(window, "check-" + task.Id);
            Click(window, "settings");
            Click(window, "open-archive");
            Click(window, "archive-delete-" + task.Id);
            Click(window, "archive-confirm");
            Assert(!Has(window, "archive-task-" + task.Id) && planner.Find(task.Id).Title == "" &&
                planner.Find(task.Id).Time == null && planner.Measure(planner.Find(step.Id)).Complete &&
                Read(window, "day-progress") == "50%", "Удалено содержимое задачи, сохранены прогресс и связь");
            Click(window, "close-drawer");

            var old = new Entry
            {
                Kind = EntryKind.Task, Title = "Истёкшая задача", Notes = "Проверочная заметка", Day = today.AddMonths(-1),
                Checked = true, CompletedOn = today.AddMonths(-1), ArchivedOn = today.AddMonths(-1)
            };
            var retained = new Entry
            {
                Kind = EntryKind.Task, Title = "Недавняя задача", Day = today.AddDays(-8),
                Checked = true, CompletedOn = today.AddDays(-8), ArchivedOn = today.AddDays(-8)
            };
            store.Save(old);
            store.Save(retained);
            planner.SyncArchive();
            Assert(planner.Find(old.Id).Title == "" && planner.Find(old.Id).Notes == "" &&
                planner.ArchivedTasks.Single().Id == retained.Id, "Архив автоматически обрезается по последнему месяцу");
            Click(window, "settings");
            Click(window, "open-archive");
            Click(window, "archive-clear");
            Click(window, "archive-confirm");
            Assert(!planner.ArchivedTasks.Any() && planner.Find(retained.Id).Title == "",
                "Очистка архива удаляет все архивные карточки");
            Click(window, "close-drawer");                

            Click(window, "column-settings-" + sport.Id);
            Click(window, "remove-column");
            Click(window, "confirm-column-remove");
            Assert(planner.Columns.Count == 3 && !Has(window, "column-settings-" + sport.Id) && !Has(window, "column-create-none"),
                "Удалённый столбец исчезает без подставного столбца");
            Screenshot(window, folder, "day.png");

            Click(window, "nav-Year");
            Click(window, "column-create-" + work.Id);
            Title(window, "Собрать портфолио");
            Click(window, "save");
            var annual = EntryByTitle(planner, "Собрать портфолио");
            Assert(annual.Period == Period.Year && !Has(window, "open-" + goal.Id), "В году только годовые цели");
            Click(window, "close-drawer");
            Screenshot(window, folder, "year.png");

            Click(window, "nav-Habits");
            Click(window, "add");
            Title(window, "Читать утром");
            Assert(!Has(window, "priority-0") && !Has(window, "time"), "В форме привычки нет важности");
            Click(window, "save");
            var habit = EntryByTitle(planner, "Читать утром");
            Click(window, "check-" + habit.Id);
            var first = Find<Border>(window, "habit-" + habit.Id + "-step-1");
            var last = Find<Border>(window, "habit-" + habit.Id + "-step-63");
            Assert(AutomationProperties.GetName(first) == "Отмечено" && AutomationProperties.GetName(last) == "Не отмечено",
                "Первая отметка находится слева, отсчёт идёт от начала серии");
            Assert(Read(window, "habit-progress") == "100%", "Дашборд привычек показывает реальный процент");
            Click(window, "open-" + habit.Id);
            Click(window, "edit");
            Assert(!Has(window, "priority-3"), "Приоритет отсутствует и при редактировании привычки");
            Click(window, "close-drawer");
            Screenshot(window, folder, "habits.png");

            Click(window, "nav-Summary");
            Assert(!Has(window, "summary-Day") && !Has(window, "summary-Month") && !Has(window, "previous") &&
                Has(window, "summary-tasks") && Has(window, "summary-habits"), "Единая сводка без переключателей периода");
            Assert(!Has(window, "open-" + annual.Id) && !Has(window, "open-" + step.Id), "Сводка агрегирует цели и подцели");
            Screenshot(window, folder, "summary.png");
            Click(window, "settings");
            Click(window, "theme-emerald");
            Click(window, "close-drawer");
            window.Width = 740;
            window.Height = 510;
            Layout(window);
            Click(window, "nav-Habits");
            Assert(Find<Border>(window, "habit-" + habit.Id + "-step-63").IsVisible, "Привычки помещаются в узком окне");
            Screenshot(window, folder, "habits-compact.png");

            window.Close();
            using (var reopenedStore = new Store(Path.Combine(folder, "planner.sqlite")))
            {
                var reopened = new PlannerService(reopenedStore, () => today);
                Assert(reopenedStore.Setting("palette", "") == "emerald" && reopened.Columns.Count == 3 &&
                    !reopened.ArchivedTasks.Any() && reopened.Find(task.Id).Title == "" &&
                    reopened.Find(weekly.Id).Period == Period.Week, "Изменения и очищенный архив переживают перезапуск");
            }
            VerifyPlanner31(store, planner, today, habit.Id, folder);
            planner.ClearPlanning();
            Assert(planner.Entries.Single().Id == habit.Id && planner.Columns.Count == 3 &&
                planner.Marks(habit).Contains(today), "Сброс планирования удаляет только цели, подцели и задачи");
            File.WriteAllLines(Path.Combine(folder, "test-result.txt"), Results);
        }

        private static void VerifyPlanner31(Store store, PlannerService planner, DateTime today, string habitId, string folder)
        {
            DateTime clock = today.AddHours(9);
            planner.Clock = () => clock;
            var window = new MainWindow(store, planner, true);
            try
            {
                Entry selected = planner.Save(new Entry
                {
                    Kind = EntryKind.Task, Day = today.AddDays(-2), Title = "Перенести отчёт", Time = new TimeSpan(13, 0, 0),
                    BoardColumn = planner.Columns[0].Id, DurationMinutes = 75
                });
                Entry another = planner.Save(new Entry { Kind = EntryKind.Task, Day = today.AddDays(-3), Title = "Перенести материалы" });
                Entry remaining = planner.Save(new Entry { Kind = EntryKind.Task, Day = today.AddDays(-4), Title = "Уточнить сроки" });
                window.Show();
                Layout(window);
                Click(window, "nav-Week");
                Click(window, "nav-Day");
                Click(window, "overdue");
                Assert(!Find<Button>(window, "overdue-today").IsEnabled, "Пакетный перенос ждёт выбора");
                Click(window, "overdue-check-" + selected.Id);
                Click(window, "overdue-check-" + another.Id);
                Click(window, "overdue-today");
                Assert(planner.Find(selected.Id).Day == today && planner.Find(another.Id).Day == today &&
                    planner.Find(remaining.Id).Day < today && planner.Find(selected.Id).DurationMinutes == 75 &&
                    planner.Find(selected.Id).Time == selected.Time && planner.Find(selected.Id).BoardColumn == selected.BoardColumn,
                    "Переносит только выбранные задачи и сохраняет параметры");
                Assert(Read(window, "remaining-work") == "1 ч 15 мин" && Has(window, "next-timed-task"),
                    "На дне видны ближайшая задача и остаток оценённой нагрузки");
                Screenshot(window, folder, "day-31.png");
                VerifyStyles(window, store, selected.Id, folder);
                Click(window, "overdue");
                Click(window, "overdue-all");
                Click(window, "overdue-other");
                Find<MainWindow.DateField>(window, "overdue-date").Value = today.AddDays(-1);
                Click(window, "overdue-move");
                Assert(Has(window, "overdue-move") && planner.Find(remaining.Id).Day != today.AddDays(-1),
                    "Прошедшая дата отклоняется");
                Find<MainWindow.DateField>(window, "overdue-date").Value = today.AddDays(2);
                Click(window, "overdue-move");
                Assert(!Has(window, "overdue") && planner.Find(remaining.Id).Day == today.AddDays(2),
                    "Произвольная дата назначается из окна просроченных");

                Click(window, "open-" + selected.Id);
                Click(window, "edit");
                var amount = Find<TextBox>(window, "duration");
                Assert(amount.Text == "75", "Длительность редактируется");
                amount.Text = "0";
                Click(window, "save");
                Assert(Find<TextBlock>(window, "form-error").Visibility == Visibility.Visible, "Нулевая длительность отклонена");
                amount.Text = "90";
                Click(window, "save");
                Click(window, "close-drawer");
                for (int i = 0; i < 8; i++)
                    planner.Save(new Entry { Kind = EntryKind.Task, Day = today, Title = "Проверка прокрутки " + i,
                        BoardColumn = selected.BoardColumn });
                Click(window, "nav-Week");
                Assert(Read(window, "week-load-" + today.ToString("yyyyMMdd")) == "1 ч 30 мин",
                    "Недельная нагрузка обновляется после редактирования");
                var corner = Find<Border>(window, "week-frozen-corner");
                var weekHeader = Find<Border>(window, "week-frozen-column-" + selected.BoardColumn);
                window.Width = 830;
                window.Height = 500;
                Layout(window);
                var board = Find<ScrollViewer>(window, "board-scroll");
                board.ScrollToHorizontalOffset(250);
                var vertical = EnumerableAncestors(board).OfType<ScrollViewer>().First();
                double headerY = weekHeader.TransformToAncestor(vertical).Transform(new Point()).Y;
                vertical.ScrollToVerticalOffset(headerY + 58);
                Layout(window);
                Assert(((TranslateTransform)corner.RenderTransform).X > 0 && ((TranslateTransform)corner.RenderTransform).Y > 0 &&
                     ((TranslateTransform)weekHeader.RenderTransform).Y > 0 &&
                     ((TranslateTransform)corner.RenderTransform).Y == ((TranslateTransform)weekHeader.RenderTransform).Y,
                     "Даты и заголовки закреплены при прокрутке: " + board.HorizontalOffset + ", " + vertical.VerticalOffset + ", " +
                     ((TranslateTransform)corner.RenderTransform).X + ", " + ((TranslateTransform)corner.RenderTransform).Y);
                Screenshot(window, folder, "week-sticky.png");

                window.Width = 1240;
                window.Height = 805;
                Layout(window);
                Click(window, "nav-Month");
                string populated = "month-date-" + selected.BoardColumn + "-" + today.ToString("yyyyMMdd");
                var busy = Find<Button>(window, populated);
                var empty = Find<Button>(window, "month-date-" + selected.BoardColumn + "-" + today.AddDays(1).ToString("yyyyMMdd"));
                Assert(Has(window, populated + "-count") &&
                    !Has(window, "month-date-" + selected.BoardColumn + "-" + today.AddDays(1).ToString("yyyyMMdd") + "-count") &&
                    ((SolidColorBrush)busy.Background).Color.A > ((SolidColorBrush)empty.Background).Color.A,
                    "Календарь выделяет занятые даты и скрывает нули");
                Screenshot(window, folder, "month-31.png");

                DateTime old = today.AddDays(-34);
                planner.Save(new Entry { Kind = EntryKind.Task, Day = old, Title = "Сравнить предыдущий период" });
                Click(window, "nav-Summary");
                Assert(Read(window, "summary-task-delta").Contains("п. п."), "В сводке есть сравнение двух периодов");
                Screenshot(window, folder, "summary-31.png");

                Click(window, "pomodoro");
                Assert(Read(window, "pomodoro-clock") == "25:00", "Помодоро открывается с 25 минутами");
                Click(window, "pomodoro-sounds");
                Assert(SoundChoice(window, "focus") == "Шаг вперёд" && SoundChoice(window, "break") == "В ритм",
                    "У этапов разные мелодии по умолчанию");
                Select(window, "sound-choice-break", "sound-break-light");
                Assert(store.Setting("sound-break-preset", "") == "light" && SoundChoice(window, "focus") == "Шаг вперёд",
                    "Встроенные мелодии выбираются независимо");
                Click(window, "sound-back");
                Click(window, "pomodoro-sounds");
                Assert(SoundChoice(window, "break") == "Мягкий подъём", "Выбранный звук сохраняется");
                Select(window, "sound-choice-break", "sound-break-rhythm");
                Layout(window);
                Screenshot(window, folder, "sounds.png");
                Click(window, "sound-focus");
                Assert(window.LastPomodoroSound == PomodoroPhase.Focus, "Прослушивание выбирает мелодию фокуса");
                Click(window, "sound-break");
                Assert(window.LastPomodoroSound == PomodoroPhase.Break, "Прослушивание выбирает мелодию перерыва");
                Click(window, "sound-stop");
                VerifyCustomSound(window, store, folder);
                Click(window, "sound-back");
                foreach (var preset in PomodoroPreset.All)
                {
                    using (var wave = PomodoroSound.CreateWave(preset))
                    using (var player = new System.Media.SoundPlayer(wave))
                    {
                        player.Load();
                        Assert(player.IsLoadCompleted && wave.Length == 44 + (long)Math.Round(22050 * preset.Length) * 2,
                            "Встроенная мелодия читается: " + preset.Title);
                    }
                }
                Click(window, "pomodoro-settings");
                Find<TextBox>(window, "pomodoro-minutes").Text = "2";
                Find<TextBox>(window, "pomodoro-break-minutes").Text = "1";
                Click(window, "pomodoro-save");
                Click(window, "pomodoro-toggle");
                clock = clock.AddSeconds(35);
                window.TestUpdatePomodoro();
                Assert(Read(window, "pomodoro-clock") == "01:25", "Таймер отсчитывает время");
                Click(window, "pomodoro-toggle");
                clock = clock.AddMinutes(10);
                window.TestUpdatePomodoro();
                Assert(Read(window, "pomodoro-clock") == "01:25", "Пауза останавливает отсчёт");
                Click(window, "pomodoro-toggle");
                var stored = new PomodoroTimer(() => clock.ToUniversalTime(), store.Setting("pomodoro", ""));
                Assert(stored.Running && stored.ClockLabel() == "01:25" && stored.FocusMinutes == 2,
                    "Таймер и настройки восстанавливаются из сохранённого состояния");
                clock = clock.AddSeconds(85);
                window.TestUpdatePomodoro();
                Assert(Read(window, "pomodoro-clock") == "01:00" && Read(window, "notice") == "Фокус завершён" &&
                    window.LastPomodoroSound == PomodoroPhase.Focus,
                    "Фокус завершается с уведомлением и переключается на перерыв");
                Click(window, "pomodoro-toggle");
                clock = clock.AddSeconds(60);
                window.TestUpdatePomodoro();
                Assert(Read(window, "pomodoro-clock") == "02:00" && Read(window, "notice") == "Перерыв завершён" &&
                    window.LastPomodoroSound == PomodoroPhase.Break,
                    "Перерыв заканчивается и открывает следующий фокус");
                Screenshot(window, folder, "pomodoro.png");
                Click(window, "close-drawer");
                VerifyLaunchQuotes(window, store, folder);
                var paused = new PomodoroTimer(() => clock.ToUniversalTime(), store.Setting("pomodoro", ""));
                Assert(!paused.Running && paused.Phase == PomodoroPhase.Focus && planner.Find(habitId) != null,
                    "Следующий этап ждёт старта, привычки доступны");
            }
            finally { window.Close(); }
        }

        private static void VerifyStyles(MainWindow window, Store store, string taskId, string folder)
        {
            var palettes = new HashSet<Color>();
            var scenes = new HashSet<int>();
            Assert(PlannerStyle.Resolve("emerald").Name == "Лесной" && PlannerStyle.Resolve("burgundy").Name == "Осенний",
                "Настройки предыдущих версий сопоставлены с новыми стилями");
            foreach (PlannerStyle style in PlannerStyle.Themes)
            {
                Click(window, "settings");
                var button = Find<Button>(window, "theme-" + style.Key);
                Click(window, "theme-" + style.Key);
                button = Find<Button>(window, "theme-" + style.Key);
                Assert(store.Setting("palette", "") == style.Key &&
                    AutomationProperties.GetName(button) == style.Name + ", выбран",
                    "Стиль «" + style.Name + "» применяется из настроек");
                if (style.Key == "ocean") Screenshot(window, folder, "styles-settings.png");
                Click(window, "close-drawer");
                var scene = Find<Border>(window, "day-landscape-" + style.Key);
                scenes.Add(((ImageBrush)scene.Background).ImageSource.GetHashCode());
                palettes.Add(((SolidColorBrush)window.Background).Color);
                Assert(Has(window, "open-" + taskId) && Has(window, "next-timed-task") && scene.ActualWidth > 250,
                    "В стиле «" + style.Name + "» видны гравюра и текущая задача");
                Screenshot(window, folder, "style-" + style.Key + ".png");
            }
            Assert(palettes.Count == 5 && scenes.Count == 5, "Пять разных фонов и пять разных изображений");
            using (var reopened = new Store(Path.Combine(folder, "planner.sqlite")))
                Assert(reopened.Setting("palette", "") == "burgundy", "Стиль сохраняется при повторном открытии базы");
            window.Width = 740;
            window.Height = 510;
            Layout(window);
            Assert(Find<TextBlock>(window, "day-progress").ActualWidth > 0 &&
                Find<Border>(window, "day-landscape-burgundy").ActualWidth > 200,
                "Прогресс и гравюра видны в узком окне");
            Screenshot(window, folder, "style-compact.png");
            window.Width = 1240;
            window.Height = 805;
            Layout(window);
        }

        private static void VerifyCustomSound(MainWindow window, Store store, string folder)
        {
            string file = Path.Combine(folder, "Sample Focus.wav");
            using (var input = PomodoroSound.CreateWave(PomodoroPreset.Resolve("", PomodoroPhase.Focus)))
            using (var output = File.Create(file)) input.CopyTo(output);
            window.SetCustomSound(PomodoroPhase.Focus, file);
            Layout(window);
            string filename = store.Setting("sound-focus", "");
            string copied = Path.Combine(folder, "Sounds", filename);
            File.Delete(file);
            Assert(File.Exists(copied) && SoundChoice(window, "focus") == "Sample Focus.wav" &&
                SoundChoice(window, "break") == "В ритм", "Мелодия копируется отдельно для выбранного этапа");
            Select(window, "sound-choice-focus", "sound-focus-light");
            Assert(File.Exists(copied) && store.Setting("sound-focus-preset", "") == "light",
                "Переключение на встроенный звук сохраняет личный файл");
            Select(window, "sound-choice-focus", "sound-focus-custom");
            using (var player = new System.Media.SoundPlayer(copied))
            {
                player.Load();
                Assert(player.IsLoadCompleted, "Локальная копия WAV открывается после удаления оригинала");
            }
            VerifyMedia(copied, "WAV");
            string mp3 = Path.Combine(folder, "Sample Break.mp3");
            // MPEG-1 Layer III frames with empty granules make a silent local decoder fixture.
            var frame = new byte[417];
            frame[0] = 0xFF;
            frame[1] = 0xFB;
            frame[2] = 0x90;
            frame[3] = 0x64;
            using (var output = File.Create(mp3))
                for (int i = 0; i < 80; i++) output.Write(frame, 0, frame.Length);
            window.SetCustomSound(PomodoroPhase.Break, mp3);
            Layout(window);
            string copiedMp3 = Path.Combine(folder, "Sounds", store.Setting("sound-break", ""));
            VerifyMedia(copiedMp3, "MP3");
            Click(window, "sound-clear-break");

            Find<Slider>(window, "sound-volume").Value = 65;
            Assert(store.Setting("pomodoro-volume", "") == "65", "Громкость сохраняется");
            Click(window, "sound-clear-focus");
            Assert(!File.Exists(copied) && SoundChoice(window, "focus") == "Шаг вперёд",
                "Сброс возвращает встроенную мелодию");
        }

        private static string SoundChoice(MainWindow window, string stage)
        {
            var picker = Find<ComboBox>(window, "sound-choice-" + stage);
            return (string)((ComboBoxItem)picker.SelectedItem).Content;
        }

        private static void VerifyMedia(string file, string format)
        {
            var media = new MediaPlayer { Volume = 0 };
            bool opened = false;
            string error = null;
            media.MediaOpened += (sender, e) => opened = true;
            media.MediaFailed += (sender, e) => error = e.ErrorException.Message;
            try
            {
                media.Open(new Uri(file));
                for (int i = 0; i < 16 && !opened && error == null; i++) RunDispatcherFor(100);
                Assert(opened, "Декодер Windows открывает " + format + (error == null ? "" : ": " + error));
            }
            finally { media.Close(); }
        }

        private static void VerifyLaunchQuotes(MainWindow window, Store store, string folder)
        {
            var deck = LaunchQuote.ReadAll();
            Assert(deck.Count >= 200 && deck.Select(quote => quote.Id).Distinct().Count() == deck.Count
                && deck.Select(quote => quote.Words).Distinct().Count() == deck.Count,
                "Встроено не менее 200 различных цитат");
            var random = new Random(31);
            var ids = new HashSet<string>();
            string last = null;
            foreach (var quote in deck)
            {
                last = LaunchQuote.Draw(deck, store, random).Id;
                if (!ids.Add(last)) throw new InvalidOperationException("Цитата повторилась до завершения цикла.");
            }
            using (var reopened = new Store(Path.Combine(folder, "planner.sqlite")))
            {
                Assert(reopened.Setting("launch-quote-last", "") == last
                    && LaunchQuote.Draw(deck, reopened, random).Id != last, "Порядок сохраняется, на границе циклов нет повтора");
            }
            window.ShowLaunchQuote();
            Layout(window);
            Assert(Has(window, "launch-quote-text") && Has(window, "launch-quote-author")
                && !Find<Button>(window, "launch-continue").IsVisible && !Has(window, "nav-Day"), "На старте видны только цитата и автор");
            RunDispatcherFor(1500);
            Assert(!Find<Button>(window, "launch-continue").IsVisible, "Кнопка скрыта в первые три секунды");
            RunDispatcherFor(1700);
            Assert(Find<Button>(window, "launch-continue").IsVisible, "Кнопка появляется через три секунды");
            Screenshot(window, folder, "launch-quote.png");
            Click(window, "launch-continue");
            Assert(!Has(window, "launch-quote-text") && Has(window, "nav-Day"), "«Продолжить» открывает планер");
            Click(window, "nav-Month");
            Assert(Has(window, "seasonal-drawing"), "Рисунок отображается в шапке месяца");
            Screenshot(window, folder, "month-33.png");
        }

        private static void RunDispatcherFor(int milliseconds)
        {
            var frame = new DispatcherFrame();
            var timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(milliseconds) };
            timer.Tick += (sender, e) => { timer.Stop(); frame.Continue = false; };
            timer.Start();
            Dispatcher.PushFrame(frame);
        }

        private static IEnumerable<DependencyObject> EnumerableAncestors(DependencyObject node)
        {
            while ((node = VisualTreeHelper.GetParent(node)) != null) yield return node;
        }

        private static void Layout(Window window)
        {
            window.UpdateLayout();
            window.Dispatcher.Invoke(DispatcherPriority.Background, new Action(() => { }));
            window.UpdateLayout();
        }

        private static void Click(MainWindow window, string id)
        {
            Layout(window);
            var button = Find<Button>(window, id);
            if (!button.IsEnabled) throw new InvalidOperationException("Кнопка недоступна: " + id);
            button.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            Layout(window);
        }

        private static void Select(MainWindow window, string control, string item)
        {
            var box = Find<ComboBox>(window, control);
            box.SelectedItem = box.Items.Cast<ComboBoxItem>().Single(value => AutomationProperties.GetAutomationId(value) == item);
        }

        private static void Title(Window window, string title) { Find<TextBox>(window, "entry-title").Text = title; }
        private static string Read(Window window, string id) { return Find<TextBlock>(window, id).Text; }
        private static bool Has(Window window, string id) { return FindVisual(window, id) != null; }

        private static T Find<T>(DependencyObject root, string id) where T : DependencyObject
        {
            T result = FindVisual(root, id) as T;
            if (result == null) throw new InvalidOperationException("Элемент не найден: " + id);
            return result;
        }

        private static DependencyObject FindVisual(DependencyObject root, string id)
        {
            if (AutomationProperties.GetAutomationId(root) == id) return root;
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(root); i++)
            {
                var found = FindVisual(VisualTreeHelper.GetChild(root, i), id);
                if (found != null) return found;
            }
            return null;
        }

        private static Entry EntryByTitle(PlannerService planner, string title)
        {
            Entry entry = planner.Entries.SingleOrDefault(item => item.Title == title);
            if (entry == null) throw new InvalidOperationException("Запись не сохранилась: " + title);
            return entry;
        }

        private static void Assert(bool condition, string name)
        {
            if (!condition) throw new InvalidOperationException(name);
            Results.Add("OK  " + name);
        }

        private static void Screenshot(Window window, string folder, string filename)
        {
            Layout(window);
            var visual = (FrameworkElement)window.Content;
            var bitmap = new RenderTargetBitmap((int)visual.ActualWidth, (int)visual.ActualHeight, 96, 96, PixelFormats.Pbgra32);
            bitmap.Render(visual);
            var encoder = new PngBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(bitmap));
            using (var file = File.Create(Path.Combine(folder, filename))) encoder.Save(file);
        }
    }
}
