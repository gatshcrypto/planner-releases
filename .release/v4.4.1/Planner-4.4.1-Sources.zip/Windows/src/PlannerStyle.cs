using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Planner
{
    internal sealed class PlannerStyle
    {
        internal static readonly PlannerStyle[] Themes =
        {
            new PlannerStyle("emerald", "Лесной", "#F4F0E5", "#222923", "#275541",
                "#142B22", "#284536", "#C0DCC1", 0),
            new PlannerStyle("ocean", "Морской", "#EDF2F4", "#182A38", "#244F75",
                "#122536", "#213E54", "#B6D7F2", 1),
            new PlannerStyle("winter", "Зимний", "#F0F5F9", "#1F2E3C", "#3A6383",
                "#243B51", "#476985", "#CCE9FA", 2),
            new PlannerStyle("summer", "Летний", "#FFF4D8", "#362B19", "#765117",
                "#402B17", "#725124", "#FFE3A0", 3),
            new PlannerStyle("burgundy", "Осенний", "#FAEEE7", "#34232A", "#793B4C",
                "#38232C", "#623844", "#F5C9B9", 4)
        };

        internal readonly string Key, Name, Paper, Text, Accent, Dark, DarkEnd, Light;
        internal readonly int Tile;
        private static BitmapSource atlas;
        private BitmapSource image;

        private PlannerStyle(string key, string name, string paper, string text, string accent, string dark,
            string darkEnd, string light, int tile)
        {
            Key = key;
            Name = name;
            Paper = paper;
            Text = text;
            Accent = accent;
            Dark = dark;
            DarkEnd = darkEnd;
            Light = light;
            Tile = tile;
        }

        internal static PlannerStyle Resolve(string key)
        {
            return Themes.FirstOrDefault(style => style.Key == key) ?? Themes[0];
        }

        internal BitmapSource Landscape()
        {
            if (image != null) return image;
            if (atlas == null)
            {
                using (var stream = typeof(PlannerStyle).Assembly.GetManifestResourceStream("Planner.Landscapes"))
                {
                    var bitmap = BitmapFrame.Create(stream, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad);
                    bitmap.Freeze();
                    atlas = bitmap;
                }
            }
            int width = atlas.PixelWidth / 3, height = atlas.PixelHeight / 2;
            var crop = new CroppedBitmap(atlas, new Int32Rect((Tile % 3) * width + 2,
                (Tile / 3) * height + 2, width - 4, height - 4));
            crop.Freeze();
            image = crop;
            return image;
        }
    }

    internal sealed partial class MainWindow
    {
        private static Brush Blend(string start, string end, double amount)
        {
            Color left = ColorOf(start), right = ColorOf(end);
            var mixed = new SolidColorBrush(Color.FromRgb(
                (byte)Math.Round(left.R + (right.R - left.R) * amount),
                (byte)Math.Round(left.G + (right.G - left.G) * amount),
                (byte)Math.Round(left.B + (right.B - left.B) * amount)));
            mixed.Freeze();
            return mixed;
        }

        private static ImageBrush LandscapeBrush(PlannerStyle style, AlignmentY vertical = AlignmentY.Center)
        {
            var visual = new ImageBrush(style.Landscape())
            {
                Stretch = Stretch.UniformToFill, AlignmentX = AlignmentX.Center, AlignmentY = vertical
            };
            visual.Freeze();
            return visual;
        }

        private UIElement StyleOptions()
        {
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            for (int index = 0; index < PlannerStyle.Themes.Length; index++)
            {
                PlannerStyle choice = PlannerStyle.Themes[index];
                bool active = currentStyle == choice;
                if (index % 2 == 0) grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                var tile = Button(choice.Name, () => ChooseStyle(choice), "theme-" + choice.Key,
                    active ? "selected" : "outline");
                Identify(tile, "theme-" + choice.Key, choice.Name + (active ? ", выбран" : ""));
                tile.Padding = new Thickness(4);
                tile.HorizontalContentAlignment = HorizontalAlignment.Stretch;
                tile.Margin = new Thickness(0, 0, index % 2 == 0 ? 7 : 0, 7);
                tile.BorderBrush = active ? accent : Line;
                var face = new StackPanel();
                var picture = new Border { Background = LandscapeBrush(choice), Height = 48, CornerRadius = new CornerRadius(5) };
                face.Children.Add(picture);
                var footer = new DockPanel { LastChildFill = true, Margin = new Thickness(5, 3, 5, 0), MinHeight = 23 };
                if (active)
                {
                    var mark = Glyph("\uE73E", accent, 13);
                    DockPanel.SetDock(mark, Dock.Right);
                    footer.Children.Add(mark);
                }
                footer.Children.Add(Text(choice.Name, 13, active ? accent : TextInk, true));
                face.Children.Add(footer);
                tile.Content = face;
                Grid.SetRow(tile, index / 2);
                Grid.SetColumn(tile, index % 2);
                grid.Children.Add(tile);
            }
            return grid;
        }

        private void ChooseStyle(PlannerStyle choice)
        {
            store.SetSetting("palette", choice.Key);
            if (currentStyle == choice) return;
            // Keep the open section, its scroll position and any actionable notification.
            double vertical = scroller.VerticalOffset;
            double horizontal = boardScroller == null ? 0 : boardScroller.HorizontalOffset;
            var pending = noticeHost;
            ((Panel)pending.Parent).Children.Remove(pending);

            SetColors();
            BuildShell();
            Refresh(false);
            scroller.ScrollToVerticalOffset(vertical);
            if (boardScroller != null) boardScroller.ScrollToHorizontalOffset(horizontal);
            if (noticeBox != null) noticeBox.Background = accentWash;
            ShowSettings();
            var selected = FindControl(drawer, "theme-" + choice.Key) as Button;
            if (selected != null) selected.Focus();
        }
    }
}
