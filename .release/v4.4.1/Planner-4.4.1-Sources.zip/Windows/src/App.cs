using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Markup;

namespace Planner
{
    internal static class App
    {
        [STAThread]
        public static int Main(string[] args)
        {
#if PLANNER_TESTS
            if (args.Contains("--publisher-test"))
            {
                int folderArg = Array.IndexOf(args, "--data-dir");
                if (folderArg < 0) return 2;
                return CloudflarePublisherTest.Run(Path.GetFullPath(args[folderArg + 1]));
            }
            if (args.Contains("--sync-test"))
            {
                int folderArg = Array.IndexOf(args, "--data-dir"), originArg = Array.IndexOf(args, "--sync-origin");
                if (folderArg < 0 || originArg < 0) return 2;
                return SyncIntegration.Run(Path.GetFullPath(args[folderArg + 1]), args[originArg + 1]);
            }
#endif
            Thread.CurrentThread.CurrentCulture = CalendarRules.Russian;
            Thread.CurrentThread.CurrentUICulture = CalendarRules.Russian;
            FrameworkElement.LanguageProperty.OverrideMetadata(typeof(FrameworkElement),
                new FrameworkPropertyMetadata(XmlLanguage.GetLanguage("ru-RU")));
            #if PLANNER_TESTS
            bool testing = args.Contains("--ui-test");
            if (testing && !args.Contains("--data-dir")) return 2;
#else
            bool testing = false;
#endif
            var application = new Application();
            application.ShutdownMode = ShutdownMode.OnExplicitShutdown;
            string errorFile = null;
            try
            {
                int dataArgument = Array.IndexOf(args, "--data-dir");
                string folder = dataArgument >= 0 && dataArgument + 1 < args.Length ?
                    Path.GetFullPath(args[dataArgument + 1]) :
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Planner");
                errorFile = Path.Combine(folder, "test-result.txt");
                string key;
                using (var hash = SHA256.Create())
                    key = BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(folder.ToUpperInvariant())));
                using (var instance = new Mutex(false, @"Local\Planner-" + key))
                {
                    bool owns;
                    try { owns = instance.WaitOne(0); }
                    catch (AbandonedMutexException) { owns = true; }
                    if (!owns)
                    {
                        MessageBox.Show("Планер уже открыт для этой базы данных.", "Планер");
                        return 1;
                    }
                    try
                    {
                        string database = Path.Combine(folder, "planner.sqlite");
                        bool backup = File.Exists(database) && InstallationPaths.IsInstalled();
                        using (var store = new Store(database))
                        {
                            if (backup)
                            {
                                try { store.BackupFor(UpdateClient.Current); }
                                catch (IOException) { }
                                catch (UnauthorizedAccessException) { }
                                catch (InvalidOperationException) { }
                            }
                            var service = new PlannerService(store, () => testing ? new DateTime(2026, 11, 19, 9, 0, 0) : DateTime.Now);
                            var window = new MainWindow(store, service, testing);
                            application.MainWindow = window;
#if PLANNER_TESTS
                            if (testing)
                            {
                                UiTest.Run(window, store, service, folder);
                                if (window.IsVisible) window.Close();
                                return 0;
                            }
#endif
                            window.Closed += (sender, e) => application.Shutdown();
                            window.ShowLaunchQuote();
                            return application.Run(window);
                        }
                    }
                    finally { instance.ReleaseMutex(); }
                }
            }
            catch (Exception error)
            {
                if (testing && errorFile != null) File.WriteAllText(errorFile, error.ToString(), Encoding.UTF8);
                else MessageBox.Show("Не удалось открыть планер.\n\n" + error.Message, "Планер",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return 1;
            }
        }
    }
}


