using System.Reflection;
using System.Runtime.Versioning;

[assembly: AssemblyTitle("Планер")]
[assembly: AssemblyProduct("Планер")]
[assembly: TargetFramework(".NETFramework,Version=v4.8")]
[assembly: AssemblyVersion("4.4.1.0")]
[assembly: AssemblyFileVersion("4.4.1.0")]
