#if PLANNER_TESTS
using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Windows.Controls;

namespace Planner
{
    internal static partial class UiTest
    {
        private static void VerifyGoalFilterScroll(MainWindow window, Store store, PlannerService planner, BoardColumn column)
        {
            var goals = Enumerable.Range(0, 15).Select(index => planner.Save(new Entry { Kind = EntryKind.Goal,
                Title = "Проверка прокрутки " + index, Day = planner.Today, TargetDay = planner.Today.AddMonths(1),
                Period = Period.Month, BoardColumn = column.Id })).ToList();
            Click(window, "nav-Goals");
            var scroll = Find<ScrollViewer>(window, "main-scroll");
            scroll.ScrollToVerticalOffset(110); Layout(window);
            double offset = scroll.VerticalOffset;
            Click(window, "filter-4");
            Assert(offset > 50 && Math.Abs(scroll.VerticalOffset - offset) < 2, "Фильтр месячных целей сохраняет положение страницы");
            Click(window, "filter-0");
            Assert(Math.Abs(scroll.VerticalOffset - offset) < 2, "Возврат ко всем целям сохраняет прокрутку");
            foreach (var goal in goals) store.Delete(goal.Id);
            planner.Reload();
            Click(window, "nav-Tasks");
        }

        private static void VerifyBackups(MainWindow window, string folder)
        {
            string root = Path.Combine(folder, "backup-check"), external = Path.Combine(root, "external");
            Directory.CreateDirectory(root);
            DateTime first = new DateTime(2026, 11, 27, 12, 0, 0), second = first.AddMinutes(20);
            using (var source = new Store(Path.Combine(root, "planner.sqlite")))
            {
                var habit = new Entry { Kind = EntryKind.Habit, Title = "Чтение", Day = first.Date };
                var task = new Entry { Kind = EntryKind.Task, Title = "Исходная", Day = first.Date };
                source.Save(task); source.Save(habit); source.SetMark(habit.Id, first.Date, true);
                var account = new FinanceAccount { Name = "Карта", Opening = 432109 };
                source.SaveFinanceAccount(account);
                var original = source.ExportSync(); var shadow = SyncDocument.Clone(original);
                SyncDocument.Items(shadow, "entries").Single(item => SyncDocument.Text(item, "id") == task.Id)["reminderAt"] = "2026-11-27T14:00:00Z";
                source.SetSetting("sync-native-base", SyncDocument.Write(original));
                source.SetSetting("sync-shadow", SyncDocument.Write(shadow));
                string latest = BackupManager.CreateAsync(source, external, first).GetAwaiter().GetResult();
                byte[] daily = File.ReadAllBytes(Path.Combine(external, "Planner-2026-11-27.zip"));
                using (var zip = new ZipArchive(File.OpenRead(latest), ZipArchiveMode.Read))
                {
                    var database = zip.GetEntry("planner.sqlite");
                    string restored = Path.Combine(root, "restored.sqlite");
                    using (var input = database.Open()) using (var output = File.Create(restored)) input.CopyTo(output);
                    using (var copy = new Store(restored))
                        Assert(copy.ReadEntries().Any(item => item.Id == task.Id) && copy.ReadMarks().Any(item => item.Id == habit.Id) &&
                            copy.ReadFinanceAccounts().Single().Opening == 432109, "Автокопия восстанавливает задачи, историю привычек и точные остатки счетов");
                    using (var input = new StreamReader(zip.GetEntry("planner.json").Open(), Encoding.UTF8))
                        Assert(input.ReadToEnd().Contains("reminderAt"), "Переносимая JSON-копия сохраняет поля мобильного приложения");
                    Assert(zip.Entries.All(item => !item.FullName.Contains("auth") && !item.FullName.Contains("owner")) &&
                        zip.GetEntry("Восстановление.txt") != null, "Копия содержит инструкцию, без файлов ключей и авторизации");
                }
                task.Title = "Свежая редакция"; source.Save(task);
                BackupManager.CreateAsync(source, external, second).GetAwaiter().GetResult();
                Assert(daily.SequenceEqual(File.ReadAllBytes(Path.Combine(external, "Planner-2026-11-27.zip"))),
                    "Обновление последней копии не заменяет начало дня");
                using (var zip = new ZipArchive(File.OpenRead(latest), ZipArchiveMode.Read))
                using (var input = new StreamReader(zip.GetEntry("planner.json").Open(), Encoding.UTF8))
                    Assert(input.ReadToEnd().Contains("Свежая редакция"), "Последняя копия включает изменения текущего дня");
                string unavailable = Path.Combine(root, "not-a-folder"); File.WriteAllText(unavailable, "occupied");
                bool failed = false;
                try { BackupManager.CreateAsync(source, unavailable, second.AddMinutes(20)).GetAwaiter().GetResult(); }
                catch (IOException) { failed = true; }
                Assert(failed && File.Exists(Path.Combine(root, "Backups", "Daily", "Planner-latest.zip")) &&
                    File.ReadAllText(unavailable) == "occupied", "При недоступной внешней папке остаётся локальная копия, чужие файлы не меняются");
                Assert(!Directory.GetDirectories(Path.Combine(root, "Backups", "Daily"), "staging-*").Any(), "Временные файлы автокопии убираются после успеха и ошибки");
            }
            Click(window, "settings");
            Click(window, "open-backups");
            Assert(Has(window, "backup-folder") && Has(window, "backup-now") && Has(window, "backup-guide"),
                "В настройках доступны папка резервных копий, сохранение и инструкция восстановления");
            Click(window, "backup-now");
            DateTime deadline = DateTime.UtcNow.AddSeconds(10);
            while (!Find<Button>(window, "backup-now").IsEnabled && DateTime.UtcNow < deadline) RunDispatcherFor(30);
            Assert(File.Exists(Path.Combine(folder, "Backups", "Daily", "Planner-latest.zip")) &&
                Read(window, "backup-status").Contains("Последняя копия"), "Кнопка резервного копирования сохраняет архив в работающем приложении");
            Screenshot(window, folder, "backup-settings.png");
            Click(window, "close-drawer");
        }
    }
}
#endif
