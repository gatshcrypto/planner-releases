using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Planner
{
    internal sealed partial class Store
    {
        public Dictionary<string, object> ExportSync()
        {
            string[] kinds = { "task", "goal", "subgoal", "habit", "event" }, periods = { "", "week", "month", "year" };
            var marks = ReadMarks().ToLookup(mark => mark.Id, mark => Date(mark.Day));
            return SyncDocument.Object("schema", 1,
                "entries", ReadEntries().Select(item => SyncDocument.Object(
                    "id", item.Id, "kind", kinds[(int)item.Kind], "title", item.Title,
                    "priority", item.Priority, "parentId", item.ParentId, "columnId", item.BoardColumn,
                    "day", Date(item.Day), "period", item.Period.HasValue ? periods[(int)item.Period.Value] : null,
                    "checked", item.Checked, "notes", item.Notes, "time", item.Time.HasValue ? item.Time.Value.ToString(@"hh\:mm") : null,
                    "mastered", Date(item.Mastered), "targetDay", Date(item.TargetDay),
                    "completedOn", Date(item.CompletedOn), "archivedOn", Date(item.ArchivedOn),
                    "durationMinutes", item.DurationMinutes, "marks", marks[item.Id].OrderBy(day => day).ToArray())).ToArray(),
                "columns", ReadColumns().Select(item => SyncDocument.Object("id", item.Id, "title", item.Title, "position", item.Position)).ToArray(),
                "accounts", ReadFinanceAccounts().Select(item => SyncDocument.Object("id", item.Id, "name", item.Name, "opening", Number(item.Opening), "archived", item.Archived)).ToArray(),
                "categories", ReadFinanceCategories().Select(item => SyncDocument.Object("id", item.Id, "name", item.Name, "kind", item.Kind == FinanceKind.Income ? "income" : "expense", "archived", item.Archived)).ToArray(),
                "operations", ReadFinanceOperations().Select(item => SyncDocument.Object("id", item.Id, "kind", item.Kind.ToString().ToLowerInvariant(),
                    "day", Date(item.Day), "amount", Number(item.Amount), "accountId", item.AccountId,
                    "destinationId", item.DestinationId, "categoryId", item.CategoryId, "notes", item.Notes,
                    "createdAt", new DateTime(item.Order, DateTimeKind.Utc).ToString("o"))).ToArray(),
                "settings", SyncDocument.Object("theme", Setting("palette", "emerald")), "deleted", SyncDocument.Object());
        }

        public void ImportSync(Dictionary<string, object> document, string revision)
        {
            var entries = SyncDocument.Items(document, "entries");
            var identifiers = new HashSet<string>(entries.Select(item => SyncDocument.Text(item, "id")));
            foreach (var item in entries)
            {
                string kind = SyncDocument.Text(item, "kind"), parent = SyncDocument.Text(item, "parentId");
                if (kind == "subgoal" && !entries.Any(p => SyncDocument.Text(p, "id") == parent && SyncDocument.Text(p, "kind") == "goal"))
                    throw new InvalidOperationException("У подцели отсутствует цель. Выберите версию данных в настройках синхронизации.");
                if (parent != null && kind == "task" && !entries.Any(p => SyncDocument.Text(p, "id") == parent && SyncDocument.Text(p, "kind") == "subgoal"))
                    throw new InvalidOperationException("У задачи отсутствует подцель. Выберите версию данных в настройках синхронизации.");
            }
            Atomic(() =>
            {
                var columns = SyncDocument.Items(document, "columns");
                foreach (var item in columns) SaveColumn(new BoardColumn { Id = S(item, "id"), Title = S(item, "title"), Position = I(item, "position") });
                string[] order = { "goal", "subgoal", "task", "habit", "event" };
                foreach (var item in entries.OrderBy(item => Array.IndexOf(order, S(item, "kind"))))
                {
                    EntryKind kind;
                    if (!Enum.TryParse(S(item, "kind"), true, out kind)) throw new InvalidOperationException("Неизвестный тип записи.");
                    Period parsed;
                    var entry = new Entry { Id = S(item, "id"), Kind = kind, Title = S(item, "title") ?? "", Priority = I(item, "priority"),
                        ParentId = S(item, "parentId"), BoardColumn = S(item, "columnId"), Day = D(item, "day"),
                        Period = Enum.TryParse(S(item, "period"), true, out parsed) ? (Period?)parsed : null,
                        Checked = B(item, "checked"), Notes = S(item, "notes") ?? "", Time = ReadTime(S(item, "time")),
                        Mastered = D(item, "mastered"), TargetDay = D(item, "targetDay"), CompletedOn = D(item, "completedOn"), ArchivedOn = D(item, "archivedOn"),
                        DurationMinutes = SyncDocument.Get(item, "durationMinutes") == null ? (int?)null : I(item, "durationMinutes") };
                    Save(entry);
                }
                foreach (var item in ReadEntries().Where(item => !identifiers.Contains(item.Id))) Delete(item.Id);
                foreach (var column in ReadColumns().Where(item => !columns.Any(c => S(c, "id") == item.Id))) DeleteColumn(column.Id);
                Execute("DELETE FROM habit_marks");
                foreach (var item in entries.Where(item => S(item, "kind") == "habit"))
                {
                    var days = SyncDocument.Get(item, "marks") as System.Collections.IEnumerable;
                    if (days != null) foreach (string day in days) SetMark(S(item, "id"), ReadDate(day).Value, true);
                }
                Execute("DELETE FROM finance_operations");
                var accounts = SyncDocument.Items(document, "accounts"); var categories = SyncDocument.Items(document, "categories");
                foreach (var item in accounts) SaveFinanceAccount(new FinanceAccount { Id = S(item, "id"), Name = S(item, "name"), Opening = Long(S(item, "opening")), Archived = B(item, "archived") });
                foreach (var item in categories) SaveFinanceCategory(new FinanceCategory { Id = S(item, "id"), Name = S(item, "name"), Kind = S(item, "kind") == "income" ? FinanceKind.Income : FinanceKind.Expense, Archived = B(item, "archived") });
                foreach (var item in ReadFinanceAccounts().Where(item => !accounts.Any(a => S(a, "id") == item.Id))) DeleteFinanceAccount(item.Id);
                foreach (var item in ReadFinanceCategories().Where(item => !categories.Any(c => S(c, "id") == item.Id))) DeleteFinanceCategory(item.Id);
                foreach (var item in SyncDocument.Items(document, "operations"))
                {
                    FinanceKind kind; if (!Enum.TryParse(S(item, "kind"), true, out kind)) throw new InvalidOperationException("Неизвестная операция.");
                    DateTime created;
                    SaveFinanceOperation(new FinanceOperation { Id = S(item, "id"), Kind = kind, Day = D(item, "day").Value,
                        Amount = Long(S(item, "amount")), AccountId = S(item, "accountId"), DestinationId = S(item, "destinationId"),
                        CategoryId = S(item, "categoryId"), Notes = S(item, "notes") ?? "",
                        Order = DateTime.TryParse(S(item, "createdAt"), CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out created) ? created.ToUniversalTime().Ticks : DateTime.UtcNow.Ticks });
                }
                string theme = S(SyncDocument.Map(document, "settings"), "theme");
                if (theme != null) SetSetting("palette", theme);
                SetSetting("sync-shadow", SyncDocument.Write(document));
                SetSetting("sync-native-base", SyncDocument.Write(ExportSync()));
                SetSetting("sync-revision", revision);
            });
        }
        private static string S(Dictionary<string, object> item, string key) { return SyncDocument.Text(item, key); }
        private static int I(Dictionary<string, object> item, string key) { return Convert.ToInt32(SyncDocument.Get(item, key), CultureInfo.InvariantCulture); }
        private static bool B(Dictionary<string, object> item, string key) { return Object.Equals(SyncDocument.Get(item, key), true); }
        private static DateTime? D(Dictionary<string, object> item, string key) { return ReadDate(S(item, key)); }
    }
}
