﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Planner
{
    internal sealed partial class MainWindow
    {
        private string taskFilter = "Все", goalFilter = "Все", subgoalFilter = "Все";
        private DateTime? taskChartEnd;
        private string dashboardGoalId;

        private void RenderEntities(EntryKind kind)
        {
            var all = planner.Entries.Where(entry => entry.Kind == kind).ToList();
            string selected = EntityFilter(kind);
            var filtered = all.Where(entry => MatchesFilter(entry, selected)).ToList();
            var dayTasks = kind == EntryKind.Task ? all.Where(entry => entry.Day == anchor).ToList() : null;
            if (kind == EntryKind.Task && selected == "Все") filtered = dayTasks;
            if (kind != EntryKind.Subgoal)
            {
                content.Children.Add(EntityDashboard(kind, dayTasks ?? all));
                content.Children.Add(Gap(16));
            }
            var controls = new WrapPanel { Margin = new Thickness(0, 0, 0, 14) };
            string[] choices = kind == EntryKind.Task ? new[] { "Все", "Просроченные" } :
                kind == EntryKind.Goal ? new[] { "Все", "В работе", "Выполнены", "Неделя", "Месяц", "Год" } :
                new[] { "Все", "В работе", "Выполнены", "Со сроком", "Без срока" };
            foreach (string value in choices)
            {
                string filter = value;
                var control = Button(filter, () =>
                {
                    if (kind == EntryKind.Task) taskFilter = filter;
                    else if (kind == EntryKind.Goal) goalFilter = filter;
                    else subgoalFilter = filter;
                    RefreshKeepingScroll();
                }, "filter-" + Array.IndexOf(choices, value), selected == filter ? "selected" : "plain");
                control.Margin = new Thickness(0, 0, 5, 4);
                controls.Children.Add(control);
            }
            if (kind == EntryKind.Task && selected == "Просроченные" && filtered.Count > 0)
                controls.Children.Add(Button("Перенести задачи", ShowOverdue, "overdue"));
            content.Children.Add(controls);
            BoardTitle(kind == EntryKind.Task ? (selected == "Все" ? CalendarRules.Label(Period.Day, anchor) : "Просроченные задачи") :
                kind == EntryKind.Goal ? "Цели" : "Подцели");
            var active = Order(filtered.Where(entry => entry.Title.Length > 0 &&
                (kind != EntryKind.Task || !entry.Checked) &&
                (kind != EntryKind.Subgoal || selected == "Выполнены" || !planner.IsArchived(entry)))).ToList();
            var board = Horizontal();
            foreach (BoardColumn column in planner.Columns)
            {
                string id = column.Id;
                Action add = () => CreateInColumn(kind, id);
                var stack = new StackPanel();
                stack.Children.Add(ColumnHeader(column, add));
                foreach (Entry entry in active.Where(item => planner.ColumnFor(item) == id))
                    stack.Children.Add(EntityCard(entry));
                stack.Children.Add(QuietAdd("Добавить", add, "quick-" + id));
                var surface = ColumnSurface(stack);
                surface.Width = 342;
                if (kind != EntryKind.Subgoal) MakeDropZone(surface, id, null, kind == EntryKind.Goal);
                board.Children.Add(surface);
            }
            board.Children.Add(AddColumnButton());
            content.Children.Add(HorizontalBoard(board));
            var incoming = active.Where(entry => planner.ColumnFor(entry) == null).ToList();
            if (incoming.Count > 0)
            {
                content.Children.Add(Gap(14));
                Head(content, "Входящие");
                foreach (Entry entry in incoming) content.Children.Add(EntityCard(entry));
            }
            if (kind == EntryKind.Task && active.Count == 0)
                Empty(content, selected == "Просроченные" ? "Просроченных задач нет" :
                    dayTasks.Count > 0 ? "Все задачи дня выполнены" : "На этот день задач нет");
            else if (all.Count == 0)
            {
                content.Children.Add(Gap(15));
                Empty(content, kind == EntryKind.Task ? "Задач пока нет" : kind == EntryKind.Goal ?
                    "Целей пока нет" : "Подцелей пока нет", "Добавить", BeginCreate);
            }
            else if (active.Count == 0)
                Empty(content, "Нет записей по выбранному фильтру");
        }

        private string EntityFilter(EntryKind kind)
        {
            return kind == EntryKind.Task ? taskFilter : kind == EntryKind.Goal ? goalFilter : subgoalFilter;
        }

        private bool MatchesFilter(Entry entry, string filter)
        {
            switch (filter)
            {
                case "Без срока": return !entry.Day.HasValue;
                case "Со сроком": return entry.Day.HasValue;
                case "Просроченные": return entry.Day < planner.Today && !entry.Checked;
                case "В работе": return entry.Kind == EntryKind.Subgoal ? !planner.IsArchived(entry) : !planner.Measure(entry).Complete;
                case "Выполнены": return entry.Kind == EntryKind.Subgoal ? planner.IsArchived(entry) : planner.Measure(entry).Complete;
                case "Неделя": return entry.Period == Period.Week;
                case "Месяц": return entry.Period == Period.Month;
                case "Год": return entry.Period == Period.Year;
                default: return true;
            }
        }

        private void CreateInColumn(EntryKind kind, string column)
        {
            if (kind == EntryKind.Goal) NewGoal(Period.Month, column);
            else if (kind == EntryKind.Task)
                NewTask(anchor, null, null, column);
            else
            {
                var parents = planner.Entries.Where(entry => entry.Kind == EntryKind.Goal && planner.ColumnFor(entry) == column).ToList();
                if (parents.Count == 0)
                {
                    var empty = new StackPanel();
                    Empty(empty, "В столбце пока нет целей", "Новая цель", () => NewGoal(Period.Month, column));
                    OpenDrawer("Новая подцель", empty);
                }
                else ShowForm(new Entry { Kind = EntryKind.Subgoal,
                    ParentId = parents.Count == 1 ? parents[0].Id : null }, false, null, parents);
            }
        }

        private UIElement EntityCard(Entry entry)
        {
            if (entry.Kind == EntryKind.Task)
            {
                var task = Card(EntryRow(entry, true), new Thickness(4, 3, 4, 3));
                task.Margin = new Thickness(0, 0, 0, 8);
                if (entry.Day < planner.Today && !entry.Checked)
                {
                    task.BorderBrush = Ink("#D2263B");
                    task.Background = Ink("#FFF0F1");
                    Identify(task, "overdue-card-" + entry.Id);
                }
                return task;
            }
            var body = new StackPanel();
            body.Children.Add(EntryRow(entry, false, entry.Kind == EntryKind.Subgoal));
            Progress progress = planner.Measure(entry);
            if (entry.Kind != EntryKind.Subgoal)
            {
                var bar = ProgressLine(progress, false);
                bar.Margin = new Thickness(8, 6, 8, 8);
                body.Children.Add(bar);
            }
            if (entry.TargetDay < planner.Today && !progress.Complete)
            {
                var overdue = Text("Срок истёк", 12, Ink("#A43236"));
                overdue.Margin = new Thickness(8, 0, 0, 5);
                body.Children.Add(overdue);
            }
            var box = Card(body, new Thickness(4, 4, 4, 4));
            box.Margin = new Thickness(0, 0, 0, 9);
            return box;
        }

        private Border EntityDashboard(EntryKind kind, IList<Entry> entries)
        {
            if (kind == EntryKind.Task)
            {
                var hero = DayDashboard(entries, anchor);
                var trend = new StackPanel();
                DateTime end = taskChartEnd ?? anchor;
                var navigation = new DockPanel { LastChildFill = true };
                var weeks = Horizontal();
                weeks.Children.Add(IconButton("\uE76B", "Предыдущие 7 дней", () => PageTaskDays(-7), "task-week-prev", "plain"));
                weeks.Children.Add(IconButton("\uE76C", "Следующие 7 дней", () => PageTaskDays(7), "task-week-next", "plain"));
                DockPanel.SetDock(weeks, Dock.Right);
                navigation.Children.Add(weeks);
                var daysControl = Horizontal();
                daysControl.Children.Add(IconButton("\uE76B", "Предыдущий день", () => OpenDay(anchor.AddDays(-1)), "task-day-prev", "plain"));
                var date = Text(CalendarRules.Label(Period.Day, anchor), 14, TextInk, true);
                Identify(date, "task-selected-date");
                daysControl.Children.Add(date);
                daysControl.Children.Add(IconButton("\uE76C", "Следующий день", () => OpenDay(anchor.AddDays(1)), "task-day-next", "plain"));
                if (anchor != planner.Today)
                    daysControl.Children.Add(Button("К сегодня", () => OpenDay(planner.Today), "task-today", "plain"));
                navigation.Children.Add(daysControl);
                trend.Children.Add(navigation);
                var days = Enumerable.Range(0, 7).Select(offset => end.AddDays(offset - 6));
                trend.Children.Add(PercentBars(days.Select(day => new ChartDatum(day.ToString("dd.MM"),
                    planner.Count(planner.Tasks(CalendarRules.Range(Period.Day, day))), () => OpenDay(day),
                    selected: day == anchor)).ToList(), 48, false));
                var stack = new StackPanel();
                stack.Children.Add(hero);
                stack.Children.Add(Gap(10));
                stack.Children.Add(DashboardCard(trend));
                return new Border { Child = stack };
            }
            var active = Order(entries.Where(entry => !planner.Measure(entry).Complete)).ToList();
            Entry selected = active.FirstOrDefault(entry => entry.Id == dashboardGoalId) ?? active.FirstOrDefault();
            var main = new StackPanel();
            var title = Display("Прогресс цели", 25);
            title.Foreground = White;
            Identify(title, "entity-dashboard-title");
            main.Children.Add(title);
            if (selected == null)
            {
                var empty = Text("Активных целей нет", 17, SoftWhite);
                empty.Margin = new Thickness(0, 20, 0, 18);
                main.Children.Add(empty);
            }
            else
            {
                dashboardGoalId = selected.Id;
                var row = new Grid { Margin = new Thickness(0, 14, 0, 8) };
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(142) });
                row.ColumnDefinitions.Add(new ColumnDefinition());
                row.Children.Add(Ring(planner.Measure(selected), 120, true, "entity-progress"));
                var legend = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
                var name = Button(selected.Title, () => ShowDetails(selected.Id), "goal-dashboard-open");
                name.Content = Text(selected.Title, 19, White, true);
                name.HorizontalContentAlignment = HorizontalAlignment.Left;
                name.Padding = new Thickness(0, 3, 0, 3);
                name.ToolTip = selected.Title;
                // Keep the title readable against the dark illustration on hover.
                name.Template = HeroTitleTemplate();
                legend.Children.Add(name);
                var date = Text(PlannerService.Dates(selected), 12, SoftWhite);
                date.Margin = new Thickness(0, 5, 0, 0);
                legend.Children.Add(date);
                Grid.SetColumn(legend, 1);
                row.Children.Add(legend);
                main.Children.Add(row);
                if (active.Count > 1)
                {
                    int index = active.FindIndex(entry => entry.Id == selected.Id);
                    var navigation = Horizontal();
                    navigation.Children.Add(GoalDashboardArrow("\uE76B", "Предыдущая цель", active[(index - 1 + active.Count) % active.Count].Id, "goal-dashboard-prev"));
                    navigation.Children.Add(Text((index + 1) + " / " + active.Count, 12, SoftWhite));
                    navigation.Children.Add(GoalDashboardArrow("\uE76C", "Следующая цель", active[(index + 1) % active.Count].Id, "goal-dashboard-next"));
                    main.Children.Add(navigation);
                }
            }
            return Hero(main);
        }

        private void PageTaskDays(int offset)
        {
            taskChartEnd = (taskChartEnd ?? anchor).AddDays(offset);
            OpenDay(anchor.AddDays(offset));
        }

        private Button GoalDashboardArrow(string icon, string label, string id, string controlId)
        {
            var button = IconButton(icon, label, () => { dashboardGoalId = id; Refresh(); }, controlId, "primary");
            button.Width = 30;
            button.MinHeight = 28;
            button.Padding = new Thickness(3);
            button.Margin = new Thickness(5, 0, 5, 0);
            return button;
        }

        private ControlTemplate HeroTitleTemplate()
        {
            var presenter = new FrameworkElementFactory(typeof(ContentPresenter));
            presenter.SetValue(FrameworkElement.MarginProperty, new TemplateBindingExtension(Control.PaddingProperty));
            return new ControlTemplate(typeof(Button)) { VisualTree = presenter };
        }

        private void ShowCompletedEntities(EntryKind kind)
        {
            if (kind == EntryKind.Goal) goalFilter = "Выполнены";
            else subgoalFilter = "Выполнены";
            Section target = kind == EntryKind.Goal ? Section.Goals : Section.Subgoals;
            if (section == target) Refresh(false);
            else Navigate(target);
        }
    }
}
