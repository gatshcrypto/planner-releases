using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Planner
{
    internal sealed partial class MainWindow
    {
        private void ShowMonthDay(DateTime day, IList<Entry> tasks, IList<Entry> subgoals)
        {
            var panel = new StackPanel();
            Head(panel, "Задачи");
            RenderRows(panel, tasks.Where(task => !task.Checked), "Активных задач нет");
            panel.Children.Add(Gap(12));
            Head(panel, "Подцели");
            RenderRows(panel, subgoals, "Подцелей нет");
            OpenDrawer(CalendarRules.Label(Period.Day, day), panel);
        }

        private Grid CalendarGrid(DateRange month, double rowHeight, Func<DateTime, bool, UIElement> build)
        {
            var grid = new Grid();
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(26) });
            string[] names = { "Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс" };
            for (int column = 0; column < 7; column++)
            {
                grid.ColumnDefinitions.Add(new ColumnDefinition());
                var name = Text(names[column], 11, Muted, true);
                name.HorizontalAlignment = HorizontalAlignment.Center;
                Grid.SetColumn(name, column);
                grid.Children.Add(name);
            }
            DateTime first = CalendarRules.Range(Period.Week, month.Start).Start;
            int weeks = ((month.End - first).Days + 6) / 7;
            for (int row = 0; row < weeks; row++)
            {
                grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rowHeight) });
                for (int column = 0; column < 7; column++)
                {
                    DateTime day = first.AddDays(row * 7 + column);
                    UIElement cell = build(day, month.Contains(day));
                    Grid.SetRow(cell, row + 1);
                    Grid.SetColumn(cell, column);
                    grid.Children.Add(cell);
                }
            }
            return grid;
        }

        private IEnumerable<Entry> Events()
        {
            return Order(planner.Entries.Where(item => item.Kind == EntryKind.Event));
        }

        private Entry UpcomingEvent(IEnumerable<Entry> items)
        {
            return Order(items.Where(item => item.Day >= planner.Today)).FirstOrDefault();
        }

        private void RenderEvents()
        {
            DateRange month = CalendarRules.Range(Period.Month, eventDate);
            var all = Events().ToList();
            var byDate = all.ToLookup(item => item.Day.Value);
            var upcoming = UpcomingEvent(all);
            shownUpcomingEvent = upcoming == null ? null : upcoming.Id;
            var top = new DockPanel { LastChildFill = true, MinHeight = 38 };
            var nearest = new StackPanel();
            nearest.Children.Add(Text("Ближайшее событие", 12, SoftWhite, true));
            if (upcoming == null) nearest.Children.Add(Text("Запланированных событий пока нет", 18, White));
            else
            {
                var link = Button(upcoming.Title + "   ·   " + upcoming.Day.Value.ToString("d MMMM", CalendarRules.Russian),
                    () => ShowDetails(upcoming.Id), "next-event", "plain");
                link.Foreground = White;
                link.FontSize = 15;
                link.ToolTip = upcoming.Title;
                link.HorizontalContentAlignment = HorizontalAlignment.Left;
                link.HorizontalAlignment = HorizontalAlignment.Left;
                link.Padding = new Thickness(0, 3, 4, 3);
                link.MinHeight = 26;
                link.Content = Text(upcoming.Title + "   ·   " + upcoming.Day.Value.ToString("d MMMM", CalendarRules.Russian), 15, White, true);
                nearest.Children.Add(link);
            }
            top.Children.Add(nearest);
            content.Children.Add(Hero(top));
            content.Children.Add(Gap(17));

            var layout = new Grid();
            layout.ColumnDefinitions.Add(new ColumnDefinition());
            layout.ColumnDefinitions.Add(new ColumnDefinition());
            layout.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            layout.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            var calendar = DashboardCard(CalendarGrid(month, 63, (day, inMonth) => EventCell(day, inMonth, byDate[day].ToList())));
            calendar.VerticalAlignment = VerticalAlignment.Top;
            layout.Children.Add(calendar);

            var agenda = new StackPanel();
            Head(agenda, CalendarRules.Label(Period.Day, eventDate));
            var entries = byDate[eventDate].ToList();
            if (entries.Count > 0)
            {
                agenda.Children.Add(Text("Весь день", 12, Muted, true));
                RenderRows(agenda, entries, null);
                agenda.Children.Add(QuietAdd("Добавить событие", () => NewEvent(eventDate), "agenda-add"));
            }
            else Empty(agenda, "На эту дату событий нет.", "Добавить событие", () => NewEvent(eventDate));
            var agendaCard = DashboardCard(agenda);
            agendaCard.VerticalAlignment = VerticalAlignment.Top;
            layout.Children.Add(agendaCard);
            Action arrange = () =>
            {
                bool wide = layout.ActualWidth >= 718;
                layout.ColumnDefinitions[1].Width = new GridLength(wide ? 265 : 0);
                Grid.SetColumn(agendaCard, wide ? 1 : 0);
                Grid.SetRow(agendaCard, wide ? 0 : 1);
                agendaCard.Margin = wide ? new Thickness(9, 0, 0, 0) : new Thickness(0, 9, 0, 0);
            };
            layout.SizeChanged += (sender, e) => { if (e.WidthChanged) arrange(); };
            content.Children.Add(layout);
        }

        private UIElement EventCell(DateTime day, bool inMonth, IList<Entry> items)
        {
            bool selected = day == eventDate;
            string id = day.ToString("yyyyMMdd");
            var host = new Grid { Margin = new Thickness(2) };
            var pick = Button("", () =>
            {
                eventDate = day;
                CloseDrawer(false);
                Refresh();
            }, "calendar-" + id, selected ? "selected" : "outline");
            pick.Padding = new Thickness(5, 3, 3, 2);
            pick.HorizontalContentAlignment = HorizontalAlignment.Stretch;
            pick.VerticalContentAlignment = VerticalAlignment.Top;
            var labels = new StackPanel();
            labels.Children.Add(Text(day.Day.ToString(), 13, selected || day == planner.Today ? accent :
                inMonth ? TextInk : Muted, selected || day == planner.Today));
            foreach (Entry entry in items.Take(items.Count > 2 ? 1 : 2))
            {
                var label = Text(entry.Title, 10, selected ? TextInk : accent, true);
                label.TextWrapping = TextWrapping.NoWrap;
                label.TextTrimming = TextTrimming.CharacterEllipsis;
                labels.Children.Add(label);
            }
            if (items.Count > 2) labels.Children.Add(Text("+" + (items.Count - 1), 9, Muted));
            pick.Content = labels;
            Identify(pick, null, CalendarRules.Label(Period.Day, day) + ", событий " + items.Count);
            if (items.Count > 0) pick.ToolTip = string.Join("\n", items.Select(item => item.Title));
            host.Children.Add(pick);
            var add = IconButton("\uE710", "Добавить событие", () => NewEvent(day), "calendar-add-" + id, "plain");
            add.HorizontalAlignment = HorizontalAlignment.Right;
            add.VerticalAlignment = VerticalAlignment.Top;
            add.Width = 21;
            add.MinHeight = 22;
            add.Padding = new Thickness(2);
            add.Visibility = selected ? Visibility.Visible : Visibility.Hidden;
            host.MouseEnter += (sender, e) => add.Visibility = Visibility.Visible;
            host.MouseLeave += (sender, e) => add.Visibility = selected ? Visibility.Visible : Visibility.Hidden;
            host.Children.Add(add);
            return host;
        }
    }
}
