using System;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace Planner
{
    internal sealed partial class MainWindow
    {
        private Brush Paper, SidePaper, CardPaper, LanePaper, BoardOffWhite;
        private Brush TextInk, Muted, Line, Hover;
        private static readonly Brush White = Ink("#FFFFFF");
        private static readonly Brush Clear = Brushes.Transparent;
        private static readonly Brush[] PriorityColors = { Ink("#7C766D"), Ink("#2562A3"), Ink("#A06A11"), Ink("#B14044") };
        private static readonly string[] Priorities = { "Обычная", "Средняя", "Высокая", "Срочная" };
        private static readonly string[] PriorityNames = { "Серая", "Синяя", "Жёлтая", "Красная" };
        private static readonly FontFamily BodyFont = new FontFamily("Segoe UI");
        private static readonly FontFamily DisplayFont = new FontFamily("Georgia");
        private static readonly FontFamily SymbolFont = new FontFamily("Segoe MDL2 Assets");
        private static readonly string[] SectionNames = { "Задачи", "Подцели", "Цели", "Привычки", "События", "Учёт финансов", "Сводка финансов", "Сводка" };
        private static readonly string[] SectionIcons = { "\uE73A", "\uE8FD", "\uECA5", "\uE8D9", "\uE8C7", "\uE8D4", "\uE9D9", "\uE9D2" };
        private Brush accent, accentWash, accentHover;
        private PlannerStyle currentStyle;
        private readonly Thickness noThickness = new Thickness(0);

        private static Brush Ink(string hex)
        {
            var brush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(hex));
            brush.Freeze();
            return brush;
        }

        private void SetSharedStyles()
        {
            var style = (Style)XamlReader.Parse(@"<Style TargetType='ScrollBar'
                xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
                xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'>
                <Setter Property='Background' Value='Transparent'/>
                <Setter Property='Width' Value='11'/>
                <Setter Property='Template'>
                    <Setter.Value>
                        <ControlTemplate TargetType='ScrollBar'>
                            <ControlTemplate.Resources>
                                <Style x:Key='TrackButton' TargetType='RepeatButton'>
                                    <Setter Property='Focusable' Value='False'/>
                                    <Setter Property='IsTabStop' Value='False'/>
                                    <Setter Property='Template'>
                                        <Setter.Value><ControlTemplate TargetType='RepeatButton'><Border Background='Transparent'/></ControlTemplate></Setter.Value>
                                    </Setter>
                                </Style>
                            </ControlTemplate.Resources>
                            <Track x:Name='PART_Track' IsDirectionReversed='True'>
                                <Track.DecreaseRepeatButton>
                                    <RepeatButton x:Name='PageBefore' Style='{StaticResource TrackButton}' Command='ScrollBar.PageUpCommand'/>
                                </Track.DecreaseRepeatButton>
                                <Track.Thumb>
                                    <Thumb Focusable='False'>
                                        <Thumb.Template>
                                            <ControlTemplate TargetType='Thumb'>
                                                <Border x:Name='Handle' Background='{DynamicResource Planner.Scroll}' CornerRadius='4' Margin='3'/>
                                                <ControlTemplate.Triggers>
                                                    <Trigger Property='IsMouseOver' Value='True'>
                                                        <Setter TargetName='Handle' Property='Background' Value='{DynamicResource Planner.Muted}'/>
                                                    </Trigger>
                                                </ControlTemplate.Triggers>
                                            </ControlTemplate>
                                        </Thumb.Template>
                                    </Thumb>
                                </Track.Thumb>
                                <Track.IncreaseRepeatButton>
                                    <RepeatButton x:Name='PageAfter' Style='{StaticResource TrackButton}' Command='ScrollBar.PageDownCommand'/>
                                </Track.IncreaseRepeatButton>
                            </Track>
                            <ControlTemplate.Triggers>
                                <Trigger Property='Orientation' Value='Horizontal'>
                                    <Setter TargetName='PART_Track' Property='IsDirectionReversed' Value='False'/>
                                    <Setter TargetName='PageBefore' Property='Command' Value='ScrollBar.PageLeftCommand'/>
                                    <Setter TargetName='PageAfter' Property='Command' Value='ScrollBar.PageRightCommand'/>
                                </Trigger>
                            </ControlTemplate.Triggers>
                        </ControlTemplate>
                    </Setter.Value>
                </Setter>
                <Style.Triggers>
                    <Trigger Property='Orientation' Value='Horizontal'>
                        <Setter Property='Height' Value='11'/>
                        <Setter Property='Width' Value='Auto'/>
                    </Trigger>
                </Style.Triggers>
            </Style>");
            Resources.Add(typeof(ScrollBar), style);
        }

        private void SetColors()
        {
            currentStyle = PlannerStyle.Resolve(store.Setting("palette", "emerald"));
            accent = Ink(currentStyle.Accent);
            accentHover = Blend(currentStyle.Accent, "#000000", .22);
            accentWash = Blend(currentStyle.Paper, currentStyle.Accent, .13);
            Paper = Ink(currentStyle.Paper);
            SidePaper = Blend(currentStyle.Paper, currentStyle.Accent, .07);
            CardPaper = Blend(currentStyle.Paper, "#FFFFFF", .78);
            LanePaper = Blend(currentStyle.Paper, currentStyle.Accent, .10);
            BoardOffWhite = Blend(currentStyle.Paper, "#FFFFFF", .34);
            TextInk = Ink(currentStyle.Text);
            Muted = Blend(currentStyle.Text, currentStyle.Paper, .34);
            Line = Blend(currentStyle.Paper, currentStyle.Accent, .21);
            Hover = Blend(currentStyle.Paper, currentStyle.Accent, .10);
            Background = Paper;
            Resources["Planner.Scroll"] = Blend(currentStyle.Paper, currentStyle.Accent, .34);
            Resources["Planner.Muted"] = Muted;
            Resources["Planner.Card"] = CardPaper;
            Resources["Planner.Line"] = Line;
            Resources["Planner.Hover"] = Hover;
        }

        private TextBlock Text(string value, double size = 14, Brush color = null, bool strong = false)
        {
            return new TextBlock
            {
                Text = value,
                FontFamily = BodyFont,
                FontSize = size,
                Foreground = color ?? TextInk,
                FontWeight = strong ? FontWeights.SemiBold : FontWeights.Normal,
                TextWrapping = TextWrapping.Wrap,
                VerticalAlignment = VerticalAlignment.Center
            };
        }

        private TextBlock Display(string value, double size)
        {
            TextBlock block = Text(value, size);
            block.FontFamily = DisplayFont;
            return block;
        }

        private TextBlock Glyph(string glyph, Brush color, double size = 15)
        {
            TextBlock block = Text(glyph, size, color);
            block.FontFamily = SymbolFont;
            block.HorizontalAlignment = HorizontalAlignment.Center;
            return block;
        }

        private Button Button(string label, Action action, string id = null, string look = "plain")
        {
            Button button = ControlButton(action, look);
            button.Content = label;
            Identify(button, id, label);
            return button;
        }

        private Button IconButton(string glyph, string label, Action action, string id, string look = "outline")
        {
            Button button = ControlButton(action, look);
            button.Content = Glyph(glyph, look == "primary" ? White : TextInk, 14);
            button.Width = 38;
            Identify(button, id, label);
            button.ToolTip = label;
            return button;
        }

        private Button ControlButton(Action action, string look)
        {
            var button = new Button
            {
                FontFamily = BodyFont, FontSize = 13, Cursor = System.Windows.Input.Cursors.Hand,
                FontWeight = FontWeights.SemiBold, MinHeight = 36, Padding = new Thickness(11, 5, 11, 5),
                Foreground = look == "primary" ? White : TextInk,
                Background = look == "primary" ? accent : look == "selected" ? accentWash : Clear,
                BorderBrush = look == "outline" ? Line : Clear,
                BorderThickness = new Thickness(1),
                HorizontalContentAlignment = HorizontalAlignment.Center,
                VerticalContentAlignment = VerticalAlignment.Center
            };
            var border = new FrameworkElementFactory(typeof(Border));
            border.Name = "Frame";
            border.SetValue(Border.CornerRadiusProperty, new CornerRadius(9));
            border.SetValue(Border.BackgroundProperty, new TemplateBindingExtension(Control.BackgroundProperty));
            border.SetValue(Border.BorderBrushProperty, new TemplateBindingExtension(Control.BorderBrushProperty));
            border.SetValue(Border.BorderThicknessProperty, new TemplateBindingExtension(Control.BorderThicknessProperty));
            var presenter = new FrameworkElementFactory(typeof(ContentPresenter));
            presenter.SetValue(FrameworkElement.MarginProperty, new TemplateBindingExtension(Control.PaddingProperty));
            presenter.SetValue(FrameworkElement.HorizontalAlignmentProperty, new TemplateBindingExtension(Control.HorizontalContentAlignmentProperty));
            presenter.SetValue(FrameworkElement.VerticalAlignmentProperty, new TemplateBindingExtension(Control.VerticalContentAlignmentProperty));
            presenter.SetValue(ContentPresenter.RecognizesAccessKeyProperty, true);
            border.AppendChild(presenter);
            var template = new ControlTemplate(typeof(Button)) { VisualTree = border };
            var over = new Trigger { Property = UIElement.IsMouseOverProperty, Value = true };
            over.Setters.Add(new Setter(Border.BackgroundProperty, look == "primary" ? accentHover : Hover, "Frame"));
            template.Triggers.Add(over);
            var focus = new Trigger { Property = UIElement.IsKeyboardFocusedProperty, Value = true };
            focus.Setters.Add(new Setter(Border.BorderBrushProperty, look == "primary" ? White : accent, "Frame"));
            template.Triggers.Add(focus);
            var disabled = new Trigger { Property = UIElement.IsEnabledProperty, Value = false };
            disabled.Setters.Add(new Setter(UIElement.OpacityProperty, .45, "Frame"));
            template.Triggers.Add(disabled);
            button.Template = template;
            button.Click += (sender, e) => RunAction(action);
            return button;
        }

        private Button Link(string label, Action action, string id = null)
        {
            Button button = Button(label, action, id);
            button.Foreground = accent;
            button.FontSize = 12;
            button.Padding = new Thickness(4, 1, 4, 1);
            button.MinHeight = 24;
            button.HorizontalAlignment = HorizontalAlignment.Left;
            return button;
        }

        private static void Identify(DependencyObject element, string id, string label = null)
        {
            if (id != null) AutomationProperties.SetAutomationId(element, id);
            if (label != null) AutomationProperties.SetName(element, label);
        }

        private Border Rule()
        {
            return new Border { Height = 1, Background = Line, Margin = new Thickness(0, 7, 0, 7) };
        }

        private Border Card(UIElement content, Thickness padding)
        {
            return new Border
            {
                Background = CardPaper, BorderBrush = Line, BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(10), Padding = padding, Child = content
            };
        }

        private StackPanel Horizontal() { return new StackPanel { Orientation = Orientation.Horizontal }; }

        private Border Gap(double height) { return new Border { Height = height }; }

        private void Head(StackPanel panel, string title, string hint = null)
        {
            var block = Text(title, 18, TextInk, true);
            block.Margin = new Thickness(0, 0, 0, hint == null ? 10 : 3);
            panel.Children.Add(block);
            if (hint != null)
            {
                var description = Text(hint, 13, Muted);
                description.Margin = new Thickness(0, 0, 0, 10);
                panel.Children.Add(description);
            }
        }

        private Border Meter(Progress progress)
        {
            var fill = new Grid { ClipToBounds = true };
            if (progress.Done > 0)
            {
                fill.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(progress.Done, GridUnitType.Star) });
                fill.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(progress.Total - progress.Done, GridUnitType.Star) });
                fill.Children.Add(new Border { Background = accent, CornerRadius = new CornerRadius(3) });
            }
            var bar = new Border { Height = 6, CornerRadius = new CornerRadius(3), Background = Line, Child = fill };
            Identify(bar, null, progress.Total == 0 ? "Нет записей" : CountText(progress));
            return bar;
        }

        private string CountText(Progress progress) { return progress.Total == 0 ? "—" : progress.Percent + "%"; }

        private Border Metrics(string label, Progress progress, string id = null)
        {
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            var info = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 16, 0) };
            info.Children.Add(Text(label, 13, Muted, true));
            var value = Display(CountText(progress), 28);
            Identify(value, id);
            info.Children.Add(value);
            grid.Children.Add(info);
            var right = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            if (progress.Total > 0)
            {
                right.Children.Add(Meter(progress));
            }
            Grid.SetColumn(right, 1);
            grid.Children.Add(right);
            return Card(grid, new Thickness(18, 13, 18, 15));
        }

        private void Empty(StackPanel host, string message, string action = null, Action invoke = null)
        {
            var stack = new StackPanel();
            stack.Children.Add(Text(message, 14, Muted));
            if (invoke != null)
            {
                var link = Link(action, invoke);
                link.Margin = new Thickness(-4, 5, 0, 0);
                stack.Children.Add(link);
            }
            host.Children.Add(Card(stack, new Thickness(16, 14, 16, 14)));
        }

        private void AnimateEntrance(UIElement element)
        {
            if (testing || !SystemParameters.ClientAreaAnimation) return;
            var motion = new TranslateTransform();
            element.RenderTransform = motion;
            var easing = new CubicEase { EasingMode = EasingMode.EaseOut };
            motion.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(8, 0, TimeSpan.FromMilliseconds(235))
                { EasingFunction = easing });
            element.BeginAnimation(OpacityProperty, new DoubleAnimation(.15, 1, TimeSpan.FromMilliseconds(200))
                { EasingFunction = easing });
        }

        private FrameworkElement PriorityDot(Entry entry)
        {
            var mark = Glyph("\uE7C1", PriorityColors[entry.Priority], 14);
            mark.Margin = new Thickness(2, 0, 4, 0);
            mark.ToolTip = "Важность · " + Priorities[entry.Priority] + " (" + PriorityNames[entry.Priority].ToLower(CalendarRules.Russian) + ")";
            Identify(mark, null, "Важность — " + Priorities[entry.Priority]);
            return mark;
        }
    }
}

