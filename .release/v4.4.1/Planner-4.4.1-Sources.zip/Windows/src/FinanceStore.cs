using System;
using System.Collections.Generic;
using System.Globalization;

namespace Planner
{
    internal sealed partial class Store
    {
        private void MigrateFinance()
        {
            Atomic(() =>
            {
                Execute(@"CREATE TABLE finance_accounts (
                    id TEXT PRIMARY KEY NOT NULL, name TEXT NOT NULL,
                    opening INTEGER NOT NULL, archived INTEGER NOT NULL CHECK(archived IN (0,1)))");
                Execute(@"CREATE TABLE finance_categories (
                    id TEXT PRIMARY KEY NOT NULL, name TEXT NOT NULL,
                    kind INTEGER NOT NULL CHECK(kind IN (0,1)), archived INTEGER NOT NULL CHECK(archived IN (0,1)))");
                Execute(@"CREATE TABLE finance_operations (
                    id TEXT PRIMARY KEY NOT NULL, kind INTEGER NOT NULL CHECK(kind IN (0,1,2)),
                    day TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount>0),
                    account_id TEXT NOT NULL REFERENCES finance_accounts(id) ON DELETE RESTRICT,
                    destination_id TEXT REFERENCES finance_accounts(id) ON DELETE RESTRICT,
                    category_id TEXT REFERENCES finance_categories(id) ON DELETE RESTRICT,
                    notes TEXT NOT NULL, creation_order INTEGER NOT NULL,
                    CHECK((kind=2 AND destination_id IS NOT NULL AND destination_id<>account_id AND category_id IS NULL)
                        OR (kind<>2 AND destination_id IS NULL AND category_id IS NOT NULL)))");
                Execute("CREATE INDEX finance_day ON finance_operations(day)");
                Execute("CREATE INDEX finance_account ON finance_operations(account_id)");
                Execute("CREATE INDEX finance_category ON finance_operations(category_id)");
                Execute("PRAGMA user_version = 7");
            });
        }

        public List<FinanceAccount> ReadFinanceAccounts()
        {
            return Query("SELECT id,name,opening,archived FROM finance_accounts ORDER BY archived,name,id",
                row => new FinanceAccount { Id = row.String(0), Name = row.String(1), Opening = Long(row.String(2)), Archived = row.Int(3) == 1 });
        }

        public List<FinanceCategory> ReadFinanceCategories()
        {
            return Query("SELECT id,name,kind,archived FROM finance_categories ORDER BY archived,name,id",
                row => new FinanceCategory { Id = row.String(0), Name = row.String(1), Kind = (FinanceKind)row.Int(2), Archived = row.Int(3) == 1 });
        }

        public List<FinanceOperation> ReadFinanceOperations()
        {
            return Query("SELECT id,kind,day,amount,account_id,destination_id,category_id,notes,creation_order FROM finance_operations ORDER BY day DESC,creation_order DESC,id",
                row => new FinanceOperation { Id = row.String(0), Kind = (FinanceKind)row.Int(1), Day = ReadDate(row.String(2)).Value,
                    Amount = Long(row.String(3)), AccountId = row.String(4), DestinationId = row.String(5), CategoryId = row.String(6),
                    Notes = row.String(7), Order = Long(row.String(8)) });
        }

        public void SaveFinanceAccount(FinanceAccount item)
        {
            Execute(@"INSERT INTO finance_accounts(id,name,opening,archived) VALUES (?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET name=excluded.name,opening=excluded.opening,archived=excluded.archived",
                item.Id, item.Name, Number(item.Opening), item.Archived ? 1 : 0);
        }

        public void SaveFinanceCategory(FinanceCategory item)
        {
            Execute(@"INSERT INTO finance_categories(id,name,kind,archived) VALUES (?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET name=excluded.name,kind=excluded.kind,archived=excluded.archived",
                item.Id, item.Name, (int)item.Kind, item.Archived ? 1 : 0);
        }

        public void SaveFinanceOperation(FinanceOperation item)
        {
            Execute(@"INSERT INTO finance_operations(id,kind,day,amount,account_id,destination_id,category_id,notes,creation_order)
                VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET kind=excluded.kind,day=excluded.day,
                amount=excluded.amount,account_id=excluded.account_id,destination_id=excluded.destination_id,
                category_id=excluded.category_id,notes=excluded.notes",
                item.Id, (int)item.Kind, Date(item.Day), Number(item.Amount), item.AccountId, item.DestinationId,
                item.CategoryId, item.Notes, Number(item.Order));
        }

        public void DeleteFinanceOperation(string id) { Execute("DELETE FROM finance_operations WHERE id=?", id); }
        public void DeleteFinanceAccount(string id) { Execute("DELETE FROM finance_accounts WHERE id=?", id); }
        public void DeleteFinanceCategory(string id) { Execute("DELETE FROM finance_categories WHERE id=?", id); }
        private static string Number(long number) { return number.ToString(CultureInfo.InvariantCulture); }
        private static long Long(string value) { return Int64.Parse(value, CultureInfo.InvariantCulture); }
    }
}
