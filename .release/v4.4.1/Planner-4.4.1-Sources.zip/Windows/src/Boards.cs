using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Planner
{
    internal sealed partial class MainWindow
    {
        private const double BoardWidth = 320;
        private const string BoardDrag = "Planner.BoardEntry";
        private Button boardBack, boardForward;
        private Action updateWeekHeader;

        private string ColumnName(string id)
        {
            var column = planner.Columns.FirstOrDefault(item => item.Id == id);
            return column == null ? "Входящие" : column.Title;
        }

        private string FirstColumn()
        {
            var column = planner.Columns.FirstOrDefault();
            return column == null ? null : column.Id;
        }

        private List<Entry> BoardTasks(DateRange range)
        {
            return Order(planner.Tasks(range)).ToList();
        }

        private void RenderDay()
        {
            var tasks = BoardTasks(CalendarRules.Range(Period.Day, anchor));
            content.Children.Add(DayDashboard(tasks, anchor));
            content.Children.Add(Gap(20));
            BoardTitle("Задачи дня");
            RenderColumnBoard(tasks.Where(item => !item.Checked).ToList(), false);
        }

        private void RenderPlanning(Period period)
        {
            if (period == Period.Month) { RenderMonth(); return; }
            var week = CalendarRules.Range(Period.Week, anchor);
            var tasks = BoardTasks(week);
            content.Children.Add(WeekDashboard(week, tasks));
            content.Children.Add(Gap(13));
            BoardTitle("Задачи недели");
            RenderWeek(week, tasks.Where(item => !item.Checked).ToList());
            var goals = planner.Goals(Period.Week, anchor).ToList();
            if (goals.Any())
            {
                content.Children.Add(Gap(18));
                Head(content, "Цели недели");
                RenderRows(content, Order(goals), null);
            }
        }

        private void RenderYear()
        {
            var goals = Order(planner.Goals(Period.Year, anchor)).ToList();
            content.Children.Add(YearDashboard(goals));
            content.Children.Add(Gap(20));
            BoardTitle("Годовые цели");
            RenderColumnBoard(goals, true);
        }

        private void BoardTitle(string title)
        {
            var bar = new DockPanel { LastChildFill = true, Margin = new Thickness(0, 0, 0, 6) };
            var controls = Horizontal();
            var before = IconButton("\uE76B", "Прокрутить столбцы влево", () => ScrollColumns(-1), "board-left", "plain");
            var after = IconButton("\uE76C", "Прокрутить столбцы вправо", () => ScrollColumns(1), "board-right", "plain");
            boardBack = before;
            boardForward = after;
            before.IsEnabled = after.IsEnabled = false;
            before.MinHeight = after.MinHeight = 30;
            controls.Children.Add(before);
            controls.Children.Add(after);
            DockPanel.SetDock(controls, Dock.Right);
            bar.Children.Add(controls);
            bar.Children.Add(Text(title, 18, TextInk, true));
            content.Children.Add(bar);
        }

        private void ScrollColumns(int direction)
        {
            if (boardScroller != null)
                boardScroller.ScrollToHorizontalOffset(boardScroller.HorizontalOffset + direction * BoardWidth);
        }

        private ScrollViewer HorizontalBoard(UIElement child)
        {
            boardScroller = new ScrollViewer
            {
                HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
                VerticalScrollBarVisibility = ScrollBarVisibility.Disabled,
                Content = child, Padding = new Thickness(0, 0, 0, 6)
            };
            Identify(boardScroller, "board-scroll");
            Button back = boardBack, forward = boardForward;
            boardScroller.ScrollChanged += (sender, e) =>
            {
                var view = (ScrollViewer)sender;
                if (back != null) back.IsEnabled = view.HorizontalOffset > .5;
                if (forward != null) forward.IsEnabled = view.HorizontalOffset + .5 < view.ScrollableWidth;
            };
            boardScroller.PreviewMouseWheel += (sender, e) =>
            {
                if ((Keyboard.Modifiers & ModifierKeys.Shift) != 0)
                {
                    var scroll = (ScrollViewer)sender;
                    scroll.ScrollToHorizontalOffset(scroll.HorizontalOffset - e.Delta * 1.5);
                }
                else
                {
                    double distance = SystemParameters.WheelScrollLines < 0 ? scroller.ViewportHeight :
                        SystemParameters.WheelScrollLines * 16;
                    scroller.ScrollToVerticalOffset(scroller.VerticalOffset - e.Delta / 120.0 * distance);
                }
                e.Handled = true;
            };
            return boardScroller;
        }

        private void RenderColumnBoard(IList<Entry> entries, bool yearly)
        {
            var board = Horizontal();
            foreach (BoardColumn column in planner.Columns)
            {
                string id = column.Id;
                var items = entries.Where(item => item.BoardColumn == id).ToList();
                var stack = new StackPanel();
                Action add = yearly ? (Action)(() => NewGoal(Period.Year, id)) :
                    () => NewTask(anchor, null, null, id);
                stack.Children.Add(ColumnHeader(column, add));
                foreach (Entry item in items) stack.Children.Add(BoardCard(item, yearly));
                if (items.Count == 0)
                    stack.Children.Add(QuietAdd(yearly ? "Добавить цель" : "Добавить задачу", add, "quick-" + (id ?? "none")));
                var frame = ColumnSurface(stack);
                frame.Width = BoardWidth;
                MakeDropZone(frame, id, null, yearly);
                board.Children.Add(frame);
            }
            board.Children.Add(AddColumnButton());
            content.Children.Add(HorizontalBoard(board));
            RenderIncoming(entries, yearly);
        }

        private void RenderIncoming(IEnumerable<Entry> entries, bool showTaskDate = false)
        {
            var incoming = entries.Where(item => item.BoardColumn == null).ToList();
            if (incoming.Count == 0) return;
            content.Children.Add(Gap(12));
            Head(content, "Входящие");
            RenderRows(content, incoming, null, null, null, showTaskDate);
        }

        private Border ColumnSurface(UIElement child)
        {
            return new Border
            {
                Background = LanePaper, BorderBrush = Line, BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(17), Padding = new Thickness(12, 7, 12, 12),
                Child = child, Margin = new Thickness(0, 0, 13, 5), MinHeight = 135
            };
        }

        private Button AddColumnButton()
        {
            var add = Button("＋  Добавить столбец", () => ShowColumn(null), "new-column", "outline");
            add.MinWidth = 167;
            add.HorizontalAlignment = HorizontalAlignment.Left;
            add.VerticalAlignment = VerticalAlignment.Top;
            add.Margin = new Thickness(1, 1, 9, 0);
            return add;
        }

        private UIElement ColumnHeader(BoardColumn column, Action add)
        {
            string id = column.Id;
            var bar = new DockPanel { LastChildFill = true, Margin = new Thickness(2, 0, 1, 4), MinHeight = 41 };
            var edit = IconButton("\uE712", "Настроить столбец", () => ShowColumn(column), "column-settings-" + id, "plain");
            edit.Width = 29;
            edit.Padding = new Thickness(3);
            DockPanel.SetDock(edit, Dock.Right);
            bar.Children.Add(edit);
            if (add != null)
            {
                var plus = IconButton("\uE710", "Добавить запись", add, "column-create-" + id, "plain");
                plus.Width = 29;
                plus.Padding = new Thickness(3);
                DockPanel.SetDock(plus, Dock.Right);
                bar.Children.Add(plus);
            }
            var name = Text(column.Title, 16, TextInk, true);
            name.TextWrapping = TextWrapping.NoWrap;
            name.TextTrimming = TextTrimming.CharacterEllipsis;
            name.ToolTip = name.Text;
            bar.Children.Add(name);
            return bar;
        }

        private Button QuietAdd(string label, Action add, string id)
        {
            var item = Link("＋  " + label, add, id);
            item.MinHeight = 31;
            item.Margin = new Thickness(1, 2, 0, 0);
            return item;
        }

        private UIElement BoardCard(Entry item, bool yearly)
        {
            var box = Card(EntryRow(item), new Thickness(3, 1, 4, 2));
            box.Margin = new Thickness(0, 0, 0, 6);
            box.CornerRadius = new CornerRadius(10);
            Point? start = null;
            box.PreviewMouseLeftButtonDown += (sender, e) => start = e.GetPosition(this);
            box.PreviewMouseLeftButtonUp += (sender, e) => start = null;
            box.PreviewMouseMove += (sender, e) =>
            {
                if (e.LeftButton != MouseButtonState.Pressed) { start = null; return; }
                if (!start.HasValue) return;
                Point end = e.GetPosition(this);
                if (Math.Abs(start.Value.X - end.X) < SystemParameters.MinimumHorizontalDragDistance &&
                    Math.Abs(start.Value.Y - end.Y) < SystemParameters.MinimumVerticalDragDistance) return;
                start = null;
                DragDrop.DoDragDrop(box, new DataObject(BoardDrag, item.Id), DragDropEffects.Move);
            };
            return box;
        }

        private void MakeDropZone(Border zone, string columnId, DateTime? day, bool yearly)
        {
            zone.AllowDrop = true;
            Brush normal = zone.Background;
            zone.DragOver += (sender, e) =>
            {
                Entry entry = e.Data.GetDataPresent(BoardDrag) ? planner.Find(e.Data.GetData(BoardDrag) as string) : null;
                bool allowed = entry != null && (yearly ? entry.Kind == EntryKind.Goal :
                    entry.Kind == EntryKind.Task && entry.ParentId == null);
                zone.Background = allowed ? accentWash : normal;
                e.Effects = allowed ? DragDropEffects.Move : DragDropEffects.None;
                e.Handled = true;
            };
            zone.DragLeave += (sender, e) => zone.Background = normal;
            zone.Drop += (sender, e) =>
            {
                zone.Background = normal;
                e.Handled = true;
                if (!e.Data.GetDataPresent(BoardDrag)) return;
                Entry entry = planner.Find(e.Data.GetData(BoardDrag) as string);
                if (entry == null || (yearly ? entry.Kind != EntryKind.Goal : entry.Kind != EntryKind.Task)) return;
                if (!yearly && entry.ParentId != null) return;
                if (entry.BoardColumn == columnId && (!day.HasValue || entry.Day == day)) return;
                RunAction(() =>
                {
                    Entry moved = entry.Copy();
                    moved.BoardColumn = columnId;
                    if (day.HasValue) moved.Day = day;
                    planner.Save(moved);
                    Refresh();
                });
            };
        }

        private void RenderWeek(DateRange week, IList<Entry> tasks)
        {
            if (planner.Columns.Count == 0)
            {
                content.Children.Add(AddColumnButton());
                RenderIncoming(tasks, true);
                return;
            }

            var grid = new Grid { Background = LanePaper };
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(111) });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            var railTransform = new TranslateTransform();
            var headerTransform = new TranslateTransform();
            var cornerTransform = new TranslateTransform();
            var first = new Border { Background = LanePaper, Padding = new Thickness(13, 9, 5, 6),
                Child = Text("День", 13, Muted, true), RenderTransform = cornerTransform };
            Identify(first, "week-frozen-corner");
            Panel.SetZIndex(first, 8);
            grid.Children.Add(first);
            var rows = Enumerable.Range(0, 7).Select(index => week.Start.AddDays(index)).ToList();
            var workload = planner.Tasks(week).Where(task => task.DurationMinutes.HasValue)
                .GroupBy(task => task.Day.Value).ToDictionary(group => group.Key, group => group.Sum(task => task.DurationMinutes.Value));
            var dateLabels = new List<Tuple<Border, Button, TranslateTransform>>();
            foreach (DateTime day in rows)
            {
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto, MinHeight = 45 });
                bool today = day == planner.Today;
                var date = new StackPanel();
                date.Children.Add(Text(day.ToString("dd.MM", CalendarRules.Russian), 17, today ? accent : TextInk, true));
                date.Children.Add(Text(CalendarRules.Capital(day.ToString("dddd", CalendarRules.Russian)), 11, Muted));
                int load;
                if (workload.TryGetValue(day, out load))
                {
                    var amount = Text(FormatLoad(load), 11, accent, true);
                    Identify(amount, "week-load-" + day.ToString("yyyyMMdd"));
                    date.Children.Add(amount);
                }
                var label = Button("", () => OpenDay(day), "week-day-" + day.ToString("yyyyMMdd"), today ? "selected" : "plain");
                Identify(label, "week-day-" + day.ToString("yyyyMMdd"), CalendarRules.Label(Period.Day, day));
                label.HorizontalContentAlignment = HorizontalAlignment.Left;
                label.VerticalAlignment = VerticalAlignment.Top;
                label.Padding = new Thickness(8, 3, 6, 3);
                label.Content = date;
                var labelTransform = new TranslateTransform();
                label.RenderTransform = labelTransform;
                var frame = new Border
                {
                    Background = today ? accentWash : LanePaper, Padding = new Thickness(4, 3, 2, 3),
                    CornerRadius = new CornerRadius(7), Child = label,
                    RenderTransform = railTransform
                };
                dateLabels.Add(Tuple.Create(frame, label, labelTransform));
                Grid.SetRow(frame, rows.IndexOf(day) + 1);
                Panel.SetZIndex(frame, 4);
                grid.Children.Add(frame);
            }

            int indexColumn = 0;
            var lookup = tasks.ToLookup(item => Tuple.Create(item.BoardColumn, item.Day.Value));
            foreach (BoardColumn column in planner.Columns)
            {
                indexColumn++;
                string id = column.Id;
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(BoardWidth) });
                var heading = new Border { Background = LanePaper, Padding = new Thickness(9, 0, 6, 0),
                    Child = ColumnHeader(column, () => NewTask(null, null, week, id)), RenderTransform = headerTransform };
                Identify(heading, "week-frozen-column-" + id);
                Grid.SetColumn(heading, indexColumn);
                Panel.SetZIndex(heading, 6);
                grid.Children.Add(heading);
                for (int row = 0; row < rows.Count; row++)
                {
                    DateTime day = rows[row];
                    var items = new StackPanel();
                    foreach (Entry item in lookup[Tuple.Create(id, day)]) items.Children.Add(BoardCard(item, false));
                    if (items.Children.Count == 0)
                    {
                        var add = IconButton("\uE710", "Добавить задачу на " + day.ToString("dd.MM"),
                            () => NewTask(day, null, week, id), "week-add-" + day.ToString("yyyyMMdd") + "-" + (id ?? "none"), "plain");
                        add.Opacity = .55;
                        add.Padding = new Thickness(3);
                        add.MinHeight = 27;
                        add.Width = 28;
                        add.HorizontalAlignment = HorizontalAlignment.Left;
                        items.Children.Add(add);
                    }
                    var cell = new Border
                    {
                        Background = day == planner.Today ? accentWash : row % 2 == 0 ? CardPaper : BoardOffWhite,
                        CornerRadius = new CornerRadius(8), Margin = new Thickness(1, 1, 2, 2),
                        Padding = new Thickness(6, 4, 6, 1), Child = items
                    };
                    Identify(cell, "week-cell-" + day.ToString("yyyyMMdd") + "-" + (id ?? "none"));
                    Grid.SetColumn(cell, indexColumn);
                    Grid.SetRow(cell, row + 1);
                    MakeDropZone(cell, id, day, false);
                    grid.Children.Add(cell);
                }
            }

            var strip = Horizontal();
            var frameBoard = new Border { Background = LanePaper, BorderBrush = Line, BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(16), Padding = new Thickness(0, 3, 6, 6), Child = grid };
            strip.Children.Add(frameBoard);
            var trailing = AddColumnButton();
            trailing.Margin = new Thickness(9, 0, 4, 0);
            strip.Children.Add(trailing);
            var scroll = HorizontalBoard(strip);
            scroll.ScrollChanged += (sender, e) =>
                cornerTransform.X = railTransform.X = Math.Min(scroll.HorizontalOffset, Math.Max(0, grid.ActualWidth - 111));
            updateWeekHeader = () =>
            {
                if (!grid.IsDescendantOf(content)) return;
                double top = grid.TransformToAncestor(content).Transform(new Point()).Y;
                double displacement = Math.Max(0, Math.Min(scroller.VerticalOffset - top, grid.ActualHeight - first.ActualHeight));
                cornerTransform.Y = headerTransform.Y = displacement;
                double headBottom = displacement + first.ActualHeight;
                foreach (var slot in dateLabels)
                {
                    double dateTop = slot.Item1.TransformToAncestor(grid).Transform(new Point()).Y + slot.Item1.Padding.Top;
                    double available = slot.Item1.ActualHeight - slot.Item2.ActualHeight - slot.Item1.Padding.Top - slot.Item1.Padding.Bottom;
                    slot.Item3.Y = Math.Max(0, Math.Min(headBottom - dateTop, available));
                }
            };
            content.Children.Add(scroll);
            RenderIncoming(tasks, true);
        }

        private void OpenDay(DateTime day)
        {
            DateTime end = taskChartEnd ?? anchor;
            if (day > end || day < end.AddDays(-6)) end = day;
            taskChartEnd = end;
            taskFilter = "Все";
            anchor = day;
            if (section == Section.Tasks) { CloseDrawer(false); Refresh(false); }
            else Navigate(Section.Tasks);
        }

        private void ShowColumn(BoardColumn column)
        {
            bool editing = column != null;
            int index = editing ? planner.Columns.FindIndex(item => item.Id == column.Id) : -1;
            var target = column ?? new BoardColumn
            {
                Position = planner.Columns.Count == 0 ? 0 : planner.Columns.Max(item => item.Position) + 1
            };
            var panel = new StackPanel();
            var name = Input("column-name", editing ? target.Title : "");
            name.MaxLength = 65;
            FormLabel(panel, "Название столбца", name);
            var error = Text("", 13, PriorityColors[3], true);
            panel.Children.Add(error);
            Action save = () =>
            {
                try
                {
                    planner.SaveColumn(target, name.Text);
                    CloseDrawer(false);
                    Refresh();
                    if (!editing && boardScroller != null) boardScroller.ScrollToRightEnd();
                }
                catch (ArgumentException invalid) { error.Text = invalid.Message; }
            };
            var actions = Horizontal();
            var saveButton = Button("Сохранить", save, "save-column", "primary");
            saveButton.Margin = new Thickness(0, 0, 7, 0);
            actions.Children.Add(saveButton);
            if (editing)
            {
                var left = IconButton("\uE76B", "Переместить влево", () => MoveColumn(target, -1), "column-left");
                var right = IconButton("\uE76C", "Переместить вправо", () => MoveColumn(target, 1), "column-right");
                left.IsEnabled = index > 0;
                right.IsEnabled = index + 1 < planner.Columns.Count;
                left.Margin = right.Margin = new Thickness(0, 0, 5, 0);
                actions.Children.Add(left);
                actions.Children.Add(right);
                actions.Children.Add(Button("Удалить столбец", () => ConfirmRemoveColumn(target), "remove-column"));
            }
            panel.Children.Add(actions);
            OpenDrawer(editing ? "Настроить столбец" : "Новый столбец", panel, null, save);
            FocusInput(name);
        }

        private void MoveColumn(BoardColumn column, int direction)
        {
            planner.ShiftColumn(column, direction);
            Refresh();
            ShowColumn(planner.Columns.Single(item => item.Id == column.Id));
        }

        private void ConfirmRemoveColumn(BoardColumn column)
        {
            var panel = new StackPanel();
            panel.Children.Add(Text("«" + column.Title + "» · записи останутся во входящих.", 15));
            panel.Children.Add(Gap(14));
            panel.Children.Add(Button("Удалить столбец", () =>
            {
                planner.RemoveColumn(column);
                CloseDrawer(false);
                Refresh();
            }, "confirm-column-remove", "primary"));
            OpenDrawer("Удалить столбец?", panel);
        }
    }
}
