using System;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace Planner
{
    internal enum PomodoroPhase { Focus, Break }

    internal sealed class PomodoroTimer
    {
        private readonly Func<DateTime> clock;
        private TimeSpan remaining;
        private DateTime? end;
        public PomodoroPhase Phase { get; private set; }
        public int FocusMinutes { get; private set; }
        public int BreakMinutes { get; private set; }
        public bool Running { get { return end.HasValue; } }
        public TimeSpan Length { get { return TimeSpan.FromMinutes(Phase == PomodoroPhase.Focus ? FocusMinutes : BreakMinutes); } }
        public TimeSpan Remaining
        {
            get
            {
                TimeSpan time = end.HasValue ? end.Value - clock() : remaining;
                return time < TimeSpan.Zero ? TimeSpan.Zero : time;
            }
        }

        public PomodoroTimer(Func<DateTime> clock, string saved)
        {
            this.clock = clock;
            FocusMinutes = 25;
            BreakMinutes = 5;
            remaining = Length;
            string[] fields = saved.Split('|');
            int focus, pause, mode;
            long ticks, deadline;
            if (fields.Length != 5 || !Int32.TryParse(fields[0], out focus) || !Int32.TryParse(fields[1], out pause) ||
                !Int32.TryParse(fields[2], out mode) || !Int64.TryParse(fields[3], out ticks) ||
                !Int64.TryParse(fields[4], out deadline) || mode < 0 || mode > 1 || focus < 1 || focus > 120 ||
                pause < 1 || pause > 60 || deadline < 0 || deadline > DateTime.MaxValue.Ticks) return;
            FocusMinutes = focus;
            BreakMinutes = pause;
            Phase = (PomodoroPhase)mode;
            remaining = TimeSpan.FromTicks(Math.Min(Length.Ticks, Math.Max(0, ticks)));
            end = deadline == 0 ? (DateTime?)null : new DateTime(deadline, DateTimeKind.Utc);
        }

        public void Toggle()
        {
            if (Running)
            {
                remaining = Remaining;
                end = null;
            }
            else
            {
                if (remaining == TimeSpan.Zero) remaining = Length;
                end = clock().Add(remaining);
            }
        }

        public void Select(PomodoroPhase phase)
        {
            Phase = phase;
            remaining = Length;
            end = null;
        }

        public bool Tick()
        {
            if (!Running || Remaining > TimeSpan.Zero) return false;
            Select(Phase == PomodoroPhase.Focus ? PomodoroPhase.Break : PomodoroPhase.Focus);
            return true;
        }

        public void ChangeDurations(int focus, int pause)
        {
            if (focus < 1 || focus > 120 || pause < 1 || pause > 60)
                throw new ArgumentException("Фокус: 1–120 мин. Перерыв: 1–60 мин.");
            if (Running) throw new ArgumentException("Сначала останови таймер.");
            FocusMinutes = focus;
            BreakMinutes = pause;
            Select(Phase);
        }

        public string Save()
        {
            return String.Format(CultureInfo.InvariantCulture, "{0}|{1}|{2}|{3}|{4}", FocusMinutes, BreakMinutes, (int)Phase,
                remaining.Ticks, end.HasValue ? end.Value.Ticks : 0);
        }

        public string ClockLabel()
        {
            int seconds = (int)Math.Ceiling(Remaining.TotalSeconds);
            return (seconds / 60).ToString("00", CultureInfo.InvariantCulture) + ":" + (seconds % 60).ToString("00", CultureInfo.InvariantCulture);
        }
    }

    internal sealed partial class MainWindow
    {
        private PomodoroTimer pomodoro;
        private readonly PomodoroSound pomodoroSound = new PomodoroSound();
#if PLANNER_TESTS
        internal PomodoroPhase? LastPomodoroSound { get; private set; }
#endif
        private DispatcherTimer pomodoroTick;
        private TextBlock pomodoroRail, pomodoroClock;
        private Border pomodoroRing;

        private void InitializePomodoro()
        {
            pomodoro = new PomodoroTimer(() => testing ? planner.Now.ToUniversalTime() : DateTime.UtcNow,
                store.Setting("pomodoro", ""));
            pomodoroTick = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(220) };
            pomodoroTick.Tick += (sender, args) => RunAction(RefreshPomodoro);
            pomodoroTick.Start();
        }

        private Button PomodoroButton()
        {
            var button = Button("Помодоро", ShowPomodoro, "pomodoro", "plain");
            var bar = Horizontal();
            var clock = Glyph("\uEC92", TextInk, 15);
            clock.Width = 20;
            clock.Margin = new Thickness(0, 0, 10, 0);
            bar.Children.Add(clock);
            pomodoroRail = Text("", 14, TextInk, true);
            bar.Children.Add(pomodoroRail);
            button.Content = bar;
            button.HorizontalContentAlignment = HorizontalAlignment.Left;
            button.ToolTip = "Помодоро";
            UpdatePomodoroText();
            return button;
        }

#if PLANNER_TESTS
        internal void TestUpdatePomodoro()
        {
            RefreshPomodoro();
            UpdateLayout();
        }
#endif

        private void RefreshPomodoro()
        {
            PomodoroPhase previous = pomodoro.Phase;
            if (pomodoro.Tick())
            {
                store.SetSetting("pomodoro", pomodoro.Save());
                UpdatePomodoroText();
                string message = previous == PomodoroPhase.Focus ? "Фокус завершён" : "Перерыв завершён";
                PlayPomodoroSound(previous);
                Notice(message, "Остановить звук", StopPomodoroAlert);
                if (pomodoroClock != null && pomodoroClock.IsLoaded) ShowPomodoro();
            }
            else if (pomodoro.Running) UpdatePomodoroText();
        }

        private void UpdatePomodoroText()
        {
            string clock = pomodoro.ClockLabel();
            if (pomodoroRail != null)
            {
                string label = pomodoro.Running ? clock :
                    pomodoro.Remaining < pomodoro.Length ? clock + " · пауза" : "Помодоро";
                if (pomodoroRail.Text != label) pomodoroRail.Text = label;
            }
            if (pomodoroClock != null && pomodoroClock.IsLoaded && pomodoroClock.Text != clock)
            {
                pomodoroClock.Text = clock;
                double fraction = Math.Max(0, Math.Min(1, 1 - pomodoro.Remaining.TotalSeconds / pomodoro.Length.TotalSeconds));
                if (pomodoroRing != null) pomodoroRing.Child = TimerRing(fraction);
            }
        }

        private Viewbox TimerRing(double fraction)
        {
            const int resolution = 1500;
            var shape = Ring(new Progress((int)(fraction * resolution), resolution), 165, true, null, true);
            return new Viewbox { Child = shape, Width = 165, Height = 165 };
        }

        private void ChangePomodoro(Action change)
        {
            RefreshPomodoro();
            change();
            store.SetSetting("pomodoro", pomodoro.Save());
            UpdatePomodoroText();
            ShowPomodoro();
        }

        private void ShowPomodoro()
        {
            var panel = new StackPanel();
            var modes = Horizontal();
            var focus = Button("Фокус", () => ChoosePomodoroPhase(PomodoroPhase.Focus), "pomodoro-focus",
                pomodoro.Phase == PomodoroPhase.Focus ? "selected" : "outline");
            focus.Margin = new Thickness(0, 0, 6, 0);
            modes.Children.Add(focus);
            modes.Children.Add(Button("Перерыв", () => ChoosePomodoroPhase(PomodoroPhase.Break), "pomodoro-break",
                pomodoro.Phase == PomodoroPhase.Break ? "selected" : "outline"));
            panel.Children.Add(modes);
            panel.Children.Add(Gap(9));

            var timer = new Grid();
            double fraction = Math.Max(0, Math.Min(1, 1 - pomodoro.Remaining.TotalSeconds / pomodoro.Length.TotalSeconds));
            pomodoroRing = new Border { Child = TimerRing(fraction), HorizontalAlignment = HorizontalAlignment.Center };
            timer.Children.Add(pomodoroRing);
            pomodoroClock = Text(pomodoro.ClockLabel(), 36, White, true);
            pomodoroClock.HorizontalAlignment = HorizontalAlignment.Center;
            Identify(pomodoroClock, "pomodoro-clock");
            timer.Children.Add(pomodoroClock);
            panel.Children.Add(Hero(timer, false));
            panel.Children.Add(Gap(12));

            var actions = Horizontal();
            var run = Button(pomodoro.Running ? "Пауза" : pomodoro.Remaining < pomodoro.Length ? "Продолжить" : "Старт",
                () => ChangePomodoro(pomodoro.Toggle), "pomodoro-toggle", "primary");
            run.Margin = new Thickness(0, 0, 5, 0);
            actions.Children.Add(run);
            actions.Children.Add(Button("Сбросить", () => ChangePomodoro(() => pomodoro.Select(pomodoro.Phase)),
                "pomodoro-reset", "outline"));
            var edit = Button("Длительность", ShowPomodoroSettings, "pomodoro-settings");
            edit.IsEnabled = !pomodoro.Running;
            actions.Children.Add(edit);
            actions.Children.Add(Button("Звуки", ShowPomodoroSounds, "pomodoro-sounds"));
            panel.Children.Add(actions);
            OpenDrawer("Помодоро", panel);
        }

        private void PlayPomodoroSound(PomodoroPhase phase)
        {
            string selected = store.Setting(SoundKey(phase) + "-preset", "");
            var preset = PomodoroPreset.Resolve(selected, phase);
            string path = selected.Length == 0 ? CustomSoundPath(phase) : null;
#if PLANNER_TESTS
            LastPomodoroSound = phase;
#endif
            if (testing) return;
            pomodoroSound.Play(preset, path, SoundVolume() / 100.0,
                path == null ? (Action)null : () => Notice("Не удалось открыть мелодию. Включён встроенный звук."));
        }

        private void StopPomodoroAlert()
        {
            pomodoroSound.Stop();
            noticeHost.Children.Clear();
        }

        private void ShowPomodoroSounds()
        {
            var panel = new StackPanel();
            panel.Children.Add(SoundRow(PomodoroPhase.Focus, "Конец фокуса", "focus"));
            panel.Children.Add(SoundRow(PomodoroPhase.Break, "Конец перерыва", "break"));
            var volume = new Slider { Minimum = 0, Maximum = 100, Value = SoundVolume(), SmallChange = 5,
                LargeChange = 10, TickFrequency = 5, IsSnapToTickEnabled = true };
            Identify(volume, "sound-volume", "Громкость мелодий");
            var volumeLabel = Text("Громкость · " + (int)volume.Value + "%", 12, Muted, true);
            volumeLabel.Margin = new Thickness(0, 6, 0, 4);
            volume.ValueChanged += (sender, e) =>
            {
                RunAction(() => store.SetSetting("pomodoro-volume", ((int)volume.Value).ToString(CultureInfo.InvariantCulture)));
                volumeLabel.Text = "Громкость · " + (int)volume.Value + "%";
                pomodoroSound.ChangeVolume(volume.Value / 100);
            };
            volume.Margin = new Thickness(0, 0, 0, 9);
            panel.Children.Add(volumeLabel);
            panel.Children.Add(volume);

            var actions = Horizontal();
            actions.Children.Add(Button("Остановить звук", () => pomodoroSound.Stop(), "sound-stop"));
            actions.Children.Add(Button("Назад", () => { pomodoroSound.Stop(); ShowPomodoro(); }, "sound-back"));
            panel.Children.Add(actions);
            OpenDrawer("Звуки помодоро", panel);
        }

        private FrameworkElement SoundRow(PomodoroPhase phase, string label, string id)
        {
            var panel = new StackPanel { Margin = new Thickness(0, 0, 0, 8) };
            Head(panel, label);
            string key = SoundKey(phase);
            string selected = store.Setting(key + "-preset", "");
            string name = store.Setting(key + "-name", "");
            var preset = PomodoroPreset.Resolve(selected, phase);
            bool useCustom = selected.Length == 0 && name.Length > 0 && CustomSoundPath(phase) != null;
            var picker = SelectList("sound-choice-" + id);
            Identify(picker, "sound-choice-" + id, label);
            picker.Margin = new Thickness(0, 0, 0, 6);
            foreach (var tone in PomodoroPreset.All)
            {
                var option = new ComboBoxItem { Content = tone.Title, Tag = tone.Key };
                Identify(option, key + "-" + tone.Key);
                picker.Items.Add(option);
                if (tone == preset && !useCustom) picker.SelectedItem = option;
            }
            if (name.Length > 0)
            {
                var custom = new ComboBoxItem { Content = name, Tag = "", ToolTip = name };
                Identify(custom, key + "-custom");
                picker.Items.Add(custom);
                if (useCustom) picker.SelectedItem = custom;
            }
            picker.SelectionChanged += (sender, e) =>
            {
                var item = picker.SelectedItem as ComboBoxItem;
                if (item == null) return;
                RunAction(() => store.SetSetting(key + "-preset", (string)item.Tag));
                pomodoroSound.Stop();
            };
            panel.Children.Add(picker);
            var actions = new WrapPanel();
            var preview = Button("Послушать", () => PlayPomodoroSound(phase), "sound-" + id, "outline");
            preview.Margin = new Thickness(0, 0, 5, 0);
            actions.Children.Add(preview);
            actions.Children.Add(Button("Выбрать файл", () => PickSound(phase), "sound-pick-" + id));
            if (name.Length > 0)
                actions.Children.Add(Button("Убрать файл", () => SetCustomSound(phase, null), "sound-clear-" + id));
            panel.Children.Add(actions);
            return Card(panel, new Thickness(10, 8, 10, 5));
        }

        private int SoundVolume()
        {
            int volume;
            return Int32.TryParse(store.Setting("pomodoro-volume", "85"), out volume) ? Math.Min(100, Math.Max(0, volume)) : 85;
        }

        private static string SoundKey(PomodoroPhase phase) { return phase == PomodoroPhase.Focus ? "sound-focus" : "sound-break"; }

        private string CustomSoundPath(PomodoroPhase phase)
        {
            string filename = store.Setting(SoundKey(phase), "");
            return filename.Length == 0 || filename != Path.GetFileName(filename) ? null : Path.Combine(store.DirectoryPath, "Sounds", filename);
        }

        private void PickSound(PomodoroPhase phase)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Title = "Мелодия помодоро", CheckFileExists = true, Filter = "Аудио (*.mp3;*.wav)|*.mp3;*.wav"
            };
            if (dialog.ShowDialog(this) != true) return;
            try { SetCustomSound(phase, dialog.FileName); }
            catch (UnauthorizedAccessException) { Notice("Не удалось скопировать мелодию."); }
        }

        internal void SetCustomSound(PomodoroPhase phase, string source)
        {
            string before = CustomSoundPath(phase);
            string key = SoundKey(phase);
            string copied = null;
            pomodoroSound.Stop();
            try
            {
                if (source != null)
                {
                    string extension = Path.GetExtension(source).ToLowerInvariant();
                    if (extension != ".wav" && extension != ".mp3") throw new ArgumentException("Выбери MP3 или WAV.");
                    string folder = Path.Combine(store.DirectoryPath, "Sounds");
                    Directory.CreateDirectory(folder);
                    copied = Path.Combine(folder, Guid.NewGuid().ToString("N") + extension);
                    File.Copy(source, copied, false);
                }
                store.Atomic(() =>
                {
                    store.SetSetting(key, copied == null ? "" : Path.GetFileName(copied));
                    store.SetSetting(key + "-name", source == null ? "" : Path.GetFileName(source));
                    store.SetSetting(key + "-preset", "");
                });
            }
            catch
            {
                TryRemoveSound(copied);
                throw;
            }
            TryRemoveSound(before);
            ShowPomodoroSounds();
        }

        private static void TryRemoveSound(string file)
        {
            if (file == null) return;
            try { File.Delete(file); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }

        private void ChoosePomodoroPhase(PomodoroPhase phase)
        {
            if (phase == pomodoro.Phase) return;
            if (pomodoro.Remaining == pomodoro.Length && !pomodoro.Running)
            {
                ChangePomodoro(() => pomodoro.Select(phase));
                return;
            }
            var panel = new StackPanel();
            var actions = Horizontal();
            actions.Children.Add(Button("Переключить", () => ChangePomodoro(() => pomodoro.Select(phase)),
                "pomodoro-switch-confirm", "primary"));
            actions.Children.Add(Button("Отмена", ShowPomodoro));
            panel.Children.Add(actions);
            OpenDrawer("Начать другой этап?", panel);
        }

        private void ShowPomodoroSettings()
        {
            var panel = new StackPanel();
            var focus = Input("pomodoro-minutes", pomodoro.FocusMinutes.ToString(CultureInfo.InvariantCulture));
            var pause = Input("pomodoro-break-minutes", pomodoro.BreakMinutes.ToString(CultureInfo.InvariantCulture));
            focus.MaxLength = pause.MaxLength = 3;
            FormLabel(panel, "Фокус, мин", focus);
            FormLabel(panel, "Перерыв, мин", pause);
            var error = Text("", 12, PriorityColors[3], true);
            panel.Children.Add(error);
            Action save = () =>
            {
                try
                {
                    int focusValue, pauseValue;
                    if (!Int32.TryParse(focus.Text, out focusValue) || !Int32.TryParse(pause.Text, out pauseValue))
                        throw new ArgumentException("Укажи время в целых минутах.");
                    ChangePomodoro(() => pomodoro.ChangeDurations(focusValue, pauseValue));
                }
                catch (ArgumentException invalid) { error.Text = invalid.Message; }
            };
            var actions = Horizontal();
            actions.Children.Add(Button("Сохранить", save, "pomodoro-save", "primary"));
            actions.Children.Add(Button("Назад", ShowPomodoro));
            panel.Children.Add(actions);
            OpenDrawer("Длительность помодоро", panel, null, save);
            FocusInput(focus);
        }
    }
}
