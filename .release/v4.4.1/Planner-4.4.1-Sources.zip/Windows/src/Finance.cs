using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Planner
{
    internal enum FinanceKind { Income, Expense, Transfer }

    internal sealed class FinanceAccount
    {
        public string Id = Guid.NewGuid().ToString("N");
        public string Name = "";
        public long Opening;
        public bool Archived;
        public FinanceAccount Copy() { return (FinanceAccount)MemberwiseClone(); }
    }

    internal sealed class FinanceCategory
    {
        public string Id = Guid.NewGuid().ToString("N");
        public string Name = "";
        public FinanceKind Kind;
        public bool Archived;
        public FinanceCategory Copy() { return (FinanceCategory)MemberwiseClone(); }
    }

    internal sealed class FinanceOperation
    {
        public string Id = Guid.NewGuid().ToString("N");
        public FinanceKind Kind;
        public DateTime Day;
        public long Amount;
        public string AccountId, DestinationId, CategoryId;
        public string Notes = "";
        public long Order = DateTime.UtcNow.Ticks;
        public FinanceOperation Copy() { return (FinanceOperation)MemberwiseClone(); }
    }

    internal sealed class FinanceTotals
    {
        // Monetary values are integral kopecks, including aggregated totals.
        public decimal Income, Expense;
        public decimal Net { get { return Income - Expense; } }
        public FinanceTotals(IEnumerable<FinanceOperation> operations)
        {
            Income = operations.Where(item => item.Kind == FinanceKind.Income).Sum(item => (decimal)item.Amount);
            Expense = operations.Where(item => item.Kind == FinanceKind.Expense).Sum(item => (decimal)item.Amount);
        }
    }

    internal static class Money
    {
        public const long Maximum = 99999999999999L;
        public static string Format(decimal kopecks)
        {
            return (kopecks / 100m).ToString("N2", CalendarRules.Russian) + " ₽";
        }

        public static long Parse(string text, bool signed)
        {
            decimal rubles;
            string clean = text.Trim().Replace(" ", "").Replace("\u00a0", "").Replace("\u202f", "").Replace(',', '.');
            if (!Decimal.TryParse(clean, NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint,
                CultureInfo.InvariantCulture, out rubles) || Decimal.Round(rubles, 2) != rubles ||
                rubles > Maximum / 100m || rubles < -Maximum / 100m || (!signed && rubles <= 0))
                throw new ArgumentException(signed ? "Укажите остаток в рублях с точностью до копейки." :
                    "Укажите сумму больше нуля с точностью до копейки.");
            return Decimal.ToInt64(rubles * 100m);
        }

        public static string Input(long amount) { return (amount / 100m).ToString("F2", CalendarRules.Russian); }
    }

    internal sealed class MoneyCalculator
    {
        private readonly string expression;
        private int position;
        private MoneyCalculator(string value) { expression = value.Replace(" ", "").Replace(',', '.').Replace('×', '*').Replace('÷', '/'); }

        public static string Evaluate(string expression)
        {
            if (String.IsNullOrWhiteSpace(expression) || expression.Length > 220)
                throw new ArgumentException("Введите выражение.");
            try
            {
                var parser = new MoneyCalculator(expression);
                decimal result = parser.Sum();
                if (parser.position != parser.expression.Length || Math.Abs(result) > Money.Maximum / 100m)
                    throw new FormatException();
                return Decimal.Round(result, 2, MidpointRounding.AwayFromZero).ToString("F2", CalendarRules.Russian);
            }
            catch (DivideByZeroException) { throw new ArgumentException("На ноль делить нельзя."); }
            catch (OverflowException) { throw new ArgumentException("Слишком большая сумма."); }
            catch (FormatException) { throw new ArgumentException("Проверьте выражение."); }
        }

        private decimal Sum()
        {
            decimal value = Product();
            while (position < expression.Length && (expression[position] == '+' || expression[position] == '-'))
            {
                char operation = expression[position++];
                decimal next = Product();
                value = operation == '+' ? value + next : value - next;
            }
            return value;
        }

        private decimal Product()
        {
            decimal value = Number();
            while (position < expression.Length && (expression[position] == '*' || expression[position] == '/'))
            {
                char operation = expression[position++];
                decimal next = Number();
                value = operation == '*' ? value * next : value / next;
            }
            return value;
        }

        private decimal Number()
        {
            if (position >= expression.Length) throw new FormatException();
            if (expression[position] == '+') { position++; return Number(); }
            if (expression[position] == '-') { position++; return -Number(); }
            if (expression[position] == '(')
            {
                position++;
                decimal nested = Sum();
                if (position >= expression.Length || expression[position++] != ')') throw new FormatException();
                return nested;
            }
            int start = position;
            while (position < expression.Length && (Char.IsDigit(expression[position]) || expression[position] == '.')) position++;
            decimal value;
            if (!Decimal.TryParse(expression.Substring(start, position - start), NumberStyles.AllowDecimalPoint,
                CultureInfo.InvariantCulture, out value)) throw new FormatException();
            return value;
        }
    }

    internal sealed class FinanceService
    {
        private readonly Store store;
        private readonly Func<DateTime> today;
        public List<FinanceAccount> Accounts { get; private set; }
        public List<FinanceCategory> Categories { get; private set; }
        public List<FinanceOperation> Operations { get; private set; }

        public FinanceService(Store store, Func<DateTime> today)
        {
            this.store = store;
            this.today = today;
            Reload();
        }

        internal void Reload()
        {
            Accounts = store.ReadFinanceAccounts();
            Categories = store.ReadFinanceCategories();
            Operations = store.ReadFinanceOperations();
        }

        public IEnumerable<FinanceOperation> ForPeriod(DateRange range)
        {
            return Operations.Where(item => range.Contains(item.Day)).OrderByDescending(item => item.Day)
                .ThenByDescending(item => item.Order).ThenBy(item => item.Id);
        }

        public decimal Balance(FinanceAccount account)
        {
            var dated = Operations.Where(item => item.Day <= today().Date);
            decimal incoming = dated.Where(item => item.Kind == FinanceKind.Income && item.AccountId == account.Id ||
                item.Kind == FinanceKind.Transfer && item.DestinationId == account.Id).Sum(item => (decimal)item.Amount);
            decimal outgoing = dated.Where(item => item.Kind != FinanceKind.Income && item.AccountId == account.Id)
                .Sum(item => (decimal)item.Amount);
            return account.Opening + incoming - outgoing;
        }

        public void Save(FinanceAccount account)
        {
            var saved = account.Copy();
            saved.Name = Name(saved.Name);
            if (Accounts.Any(item => item.Id != saved.Id && String.Equals(item.Name, saved.Name, StringComparison.OrdinalIgnoreCase)))
                throw new ArgumentException("Счёт с таким названием уже существует.");
            if (Math.Abs((decimal)saved.Opening) > Money.Maximum) throw new ArgumentException("Слишком большой остаток.");
            store.SaveFinanceAccount(saved);
            Reload();
        }

        public void Save(FinanceCategory category)
        {
            var saved = category.Copy();
            saved.Name = Name(saved.Name);
            if (saved.Kind != FinanceKind.Income && saved.Kind != FinanceKind.Expense)
                throw new ArgumentException("Выберите доход или расход.");
            if (Categories.Any(item => item.Id != saved.Id && item.Kind == saved.Kind &&
                String.Equals(item.Name, saved.Name, StringComparison.OrdinalIgnoreCase)))
                throw new ArgumentException("Категория с таким названием уже существует.");
            if (Operations.Any(item => item.CategoryId == saved.Id && item.Kind != saved.Kind))
                throw new ArgumentException("У используемой категории нельзя менять тип операции.");
            store.SaveFinanceCategory(saved);
            Reload();
        }

        public void Save(FinanceOperation operation)
        {
            var saved = operation.Copy();
            var existing = Operations.FirstOrDefault(item => item.Id == saved.Id);
            if (saved.Day.Year < 2 || saved.Day.Year > 9998) throw new ArgumentException("Укажите дату операции.");
            if (saved.Amount <= 0 || saved.Amount > Money.Maximum) throw new ArgumentException("Укажите сумму больше нуля.");
            if (!Enum.IsDefined(typeof(FinanceKind), saved.Kind)) throw new ArgumentException("Выберите тип операции.");
            var account = Accounts.FirstOrDefault(item => item.Id == saved.AccountId);
            if (account == null || account.Archived && (existing == null || existing.AccountId != saved.AccountId))
                throw new ArgumentException("Выберите действующий счёт.");
            if (saved.Kind == FinanceKind.Transfer)
            {
                var destination = Accounts.FirstOrDefault(item => item.Id == saved.DestinationId);
                if (destination == null || destination.Id == saved.AccountId || destination.Archived &&
                    (existing == null || existing.DestinationId != destination.Id))
                    throw new ArgumentException("Выберите другой действующий счёт зачисления.");
                saved.CategoryId = null;
            }
            else
            {
                var category = Categories.FirstOrDefault(item => item.Id == saved.CategoryId && item.Kind == saved.Kind);
                if (category == null || category.Archived && (existing == null || existing.CategoryId != saved.CategoryId))
                    throw new ArgumentException("Выберите категорию операции.");
                saved.DestinationId = null;
            }
            saved.Day = saved.Day.Date;
            saved.Notes = (saved.Notes ?? "").Trim();
            if (saved.Notes.Length > 4000) throw new ArgumentException("Заметка слишком длинная.");
            if (existing != null) saved.Order = existing.Order;
            store.SaveFinanceOperation(saved);
            Reload();
        }

        private static string Name(string value)
        {
            string name = (value ?? "").Trim();
            if (name.Length == 0 || name.Length > 100) throw new ArgumentException("Введите название до 100 символов.");
            return name;
        }

        public Action DeleteOperation(string id)
        {
            var original = Operations.Single(item => item.Id == id).Copy();
            store.DeleteFinanceOperation(id);
            Reload();
            return () => { store.SaveFinanceOperation(original); Reload(); };
        }

        public bool AccountUsed(string id) { return Operations.Any(item => item.AccountId == id || item.DestinationId == id); }
        public bool CategoryUsed(string id) { return Operations.Any(item => item.CategoryId == id); }

        public Action RemoveAccount(string id)
        {
            var original = Accounts.Single(item => item.Id == id).Copy();
            if (AccountUsed(id))
            {
                var archived = original.Copy();
                archived.Archived = true;
                Save(archived);
            }
            else { store.DeleteFinanceAccount(id); Reload(); }
            return () => Save(original);
        }

        public Action RemoveCategory(string id)
        {
            var original = Categories.Single(item => item.Id == id).Copy();
            if (CategoryUsed(id))
            {
                var archived = original.Copy();
                archived.Archived = true;
                Save(archived);
            }
            else { store.DeleteFinanceCategory(id); Reload(); }
            return () => Save(original);
        }
    }
}
