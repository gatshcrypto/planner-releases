using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Threading.Tasks;

namespace Planner
{
    internal static class BackupManager
    {
        internal const string Guide = "Планер — восстановление\r\n\r\n" +
            "В архиве planner.sqlite — полная база Windows, planner.json — данные для импорта в мобильном планере. " +
            "native-state.json и mobile-shadow.json сохраняют исходные данные устройств до объединения.\r\n\r\n" +
            "Windows: сначала отключите синхронизацию в настройках или отключите интернет. Полностью закройте планер, " +
            "сохраните нынешнюю базу отдельно, затем замените %LOCALAPPDATA%\\Planner\\planner.sqlite файлом из архива. " +
            "Не заменяйте базу при открытом планере. Проверьте записи офлайн. Прежний сервер может содержать более новую " +
            "версию данных, поэтому не включайте обмен до сверки и сохраните исходный архив.\r\n" +
            "iPhone: откройте свой адрес планера, войдите ключом доступа; в настройках можно импортировать planner.json. " +
            "Импорт объединяет записи по идентификаторам; это не полная замена облачной базы.\r\n\r\n" +
            "Ключ доступа и адрес сохраните отдельно в менеджере паролей. В Windows их файл находится в " +
            "%LOCALAPPDATA%\\Planner\\CloudHosting\\Доступ к планеру.txt. В архивах ключа нет.\r\n" +
            "Смена устройства не требует ChatGPT: установите планер, подключите свой сервер заново. " +
            "Не переносите зашифрованные файлы авторизации Windows на другой компьютер.\r\n\r\n" +
            "Храните отдельные копии установщика и исходников из GitHub Releases, а также резервные коды " +
            "своих аккаунтов GitHub и Cloudflare. При потере сервера его можно развернуть заново из исходников " +
            "и восстановить данные из собственной копии. Копия на том же диске не защищает от поломки диска.\r\n";

        internal static Task<string> CreateAsync(Store store, string destination, DateTime timestamp)
        {
            string local = Path.Combine(store.DirectoryPath, "Backups", "Daily");
            Directory.CreateDirectory(local);
            string staging = Path.Combine(local, "staging-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(staging);
            string database = Path.Combine(staging, "planner.sqlite");
            try { store.SaveBackupSnapshot(database); }
            catch { File.Delete(database); Directory.Delete(staging); throw; }
            string installer = InstallationPaths.IsInstalled() ? Path.Combine(InstallationPaths.ProgramFolder, InstallationPaths.MaintenanceFile) : null;
            return Task.Run(() =>
            {
                string archive = Path.Combine(staging, "snapshot.zip");
                try
                {
                    string nativeJson, shadowJson, mergedJson;
                    using (var preserved = new Store(database))
                    {
                        var native = preserved.ExportSync();
                        nativeJson = SyncDocument.Write(native);
                        shadowJson = preserved.Setting("sync-shadow", nativeJson);
                        var merged = SyncDocument.Overlay(SyncDocument.Parse(shadowJson),
                            SyncDocument.Parse(preserved.Setting("sync-native-base", nativeJson)), native);
                        mergedJson = SyncDocument.Write(merged);
                    }
                    using (var stream = File.Create(archive))
                    using (var zip = new ZipArchive(stream, ZipArchiveMode.Create))
                    {
                        AddFile(zip, "planner.sqlite", database);
                        AddText(zip, "planner.json", mergedJson);
                        AddText(zip, "native-state.json", nativeJson);
                        AddText(zip, "mobile-shadow.json", shadowJson);
                        AddText(zip, "Восстановление.txt", Guide);
                        AddText(zip, "backup-info.json", SyncDocument.Write(SyncDocument.Object(
                            "version", UpdateClient.Current.ToString(3), "createdAt", timestamp.ToUniversalTime().ToString("o"))));
                    }
                    string latest = SaveArchive(archive, local, timestamp);
                    SaveInstaller(installer, local);
                    // Keep the local safety copy even if the external drive is unavailable.
                    if (!String.Equals(Path.GetFullPath(destination).TrimEnd(Path.DirectorySeparatorChar),
                        Path.GetFullPath(local).TrimEnd(Path.DirectorySeparatorChar), StringComparison.OrdinalIgnoreCase))
                    {
                        latest = SaveArchive(archive, destination, timestamp);
                        SaveInstaller(installer, destination);
                    }
                    return latest;
                }
                finally
                {
                    File.Delete(archive);
                    File.Delete(database);
                    Directory.Delete(staging);
                }
            });
        }

        private static string SaveArchive(string source, string folder, DateTime timestamp)
        {
            Directory.CreateDirectory(folder);
            string daily = Path.Combine(folder, "Planner-" + timestamp.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) + ".zip");
            if (!File.Exists(daily)) AtomicCopy(source, daily);
            string latest = Path.Combine(folder, "Planner-latest.zip");
            AtomicCopy(source, latest);
            return latest;
        }

        private static void SaveInstaller(string source, string folder)
        {
            if (source == null) return;
            string destination = Path.Combine(folder, "PlannerSetup-" + UpdateClient.Current.ToString(3) + ".exe");
            if (!File.Exists(destination)) AtomicCopy(source, destination);
        }

        private static void AtomicCopy(string source, string destination)
        {
            string temporary = destination + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                File.Copy(source, temporary);
                if (File.Exists(destination)) File.Replace(temporary, destination, null);
                else File.Move(temporary, destination);
            }
            finally { File.Delete(temporary); }
        }

        private static void AddFile(ZipArchive archive, string name, string source)
        {
            using (var input = File.OpenRead(source))
            using (var output = archive.CreateEntry(name, CompressionLevel.Optimal).Open()) input.CopyTo(output);
        }

        private static void AddText(ZipArchive archive, string name, string value)
        {
            using (var output = new StreamWriter(archive.CreateEntry(name, CompressionLevel.Optimal).Open(), new UTF8Encoding(false))) output.Write(value);
        }
    }
}
