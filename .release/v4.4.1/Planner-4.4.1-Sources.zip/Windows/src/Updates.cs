using System;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace Planner
{
    internal sealed class UpdateClient
    {
        private const string SetupName = "PlannerSetup.exe";
        private const int MaxPackage = 32 * 1024 * 1024;
        private static readonly HttpClient Http = new HttpClient(new HttpClientHandler { AllowAutoRedirect = false });
        private readonly string repository;
        public static readonly Version Current = Assembly.GetExecutingAssembly().GetName().Version;

        public UpdateClient(string repository)
        {
            if (repository != null && Regex.IsMatch(repository, @"\A[A-Za-z0-9-]+/[A-Za-z0-9_.-]+\z"))
                this.repository = repository;
        }

        public bool Configured { get { return repository != null; } }

        public async Task<UpdateRelease> CheckAsync(CancellationToken token)
        {
            var location = new Uri("https://api.github.com/repos/" + repository + "/releases/latest");
            using (HttpResponseMessage result = await GetAsync(location, token).ConfigureAwait(false))
            {
                if (result.StatusCode == HttpStatusCode.NotFound) return null;
                result.EnsureSuccessStatusCode();
                using (var body = new MemoryStream())
                {
                    await CopyAsync(result, body, 1024 * 1024, token).ConfigureAwait(false);
                    body.Position = 0;
                    return ReadRelease(body, repository, Current);
                }
            }
        }

        internal static UpdateRelease ReadRelease(Stream body, string repository, Version current)
        {
            var release = (GitHubRelease)new DataContractJsonSerializer(typeof(GitHubRelease)).ReadObject(body);
            Version version;
            if (release == null || release.Draft || release.Prerelease || release.Tag == null ||
                !Regex.IsMatch(release.Tag, @"\Av\d+\.\d+\.\d+\z") ||
                !Version.TryParse(release.Tag.Substring(1) + ".0", out version) || version <= current ||
                release.Assets == null)
                return null;

            var expected = new Uri("https://github.com/" + repository + "/releases/download/" + release.Tag + "/" + SetupName);
            foreach (ReleaseAsset asset in release.Assets)
            {
                Uri address;
                if (asset == null || asset.Name != SetupName || asset.Size <= 0 || asset.Size > MaxPackage ||
                    asset.Digest == null || !Regex.IsMatch(asset.Digest, @"\Asha256:[0-9a-fA-F]{64}\z") ||
                    !Uri.TryCreate(asset.Url, UriKind.Absolute, out address) ||
                    !String.Equals(address.AbsoluteUri, expected.AbsoluteUri, StringComparison.OrdinalIgnoreCase))
                    continue;
                return new UpdateRelease { Version = version, Location = expected, Size = asset.Size,
                    Digest = asset.Digest.Substring(7) };
            }
            return null;
        }

        public static async Task<string> DownloadAsync(UpdateRelease release, string directory, CancellationToken token)
        {
            Directory.CreateDirectory(directory);
            string destination = Path.Combine(directory, "PlannerSetup-" + release.Version.ToString(3) + "-" +
                Guid.NewGuid().ToString("N") + ".exe");
            try
            {
                using (HttpResponseMessage result = await GetAsync(release.Location, token).ConfigureAwait(false))
                {
                    result.EnsureSuccessStatusCode();
                    using (var output = new FileStream(destination, FileMode.CreateNew, FileAccess.Write, FileShare.None,
                        32768, true))
                        await CopyAsync(result, output, release.Size, token).ConfigureAwait(false);
                }
                if (!ValidPackage(destination, release))
                    throw new InvalidDataException("Файл обновления не прошёл проверку.");
                return destination;
            }
            catch
            {
                File.Delete(destination);
                throw;
            }
        }

        internal static bool ValidPackage(string path, UpdateRelease release)
        {
            using (var input = File.OpenRead(path))
            using (var sha = SHA256.Create())
                return input.Length == release.Size && String.Equals(
                    BitConverter.ToString(sha.ComputeHash(input)).Replace("-", ""), release.Digest,
                    StringComparison.OrdinalIgnoreCase);
        }

        private static async Task<HttpResponseMessage> GetAsync(Uri location, CancellationToken token)
        {
            for (int redirect = 0; redirect < 5; redirect++)
            {
                if (location.Scheme != "https" || !location.IsDefaultPort || location.UserInfo.Length != 0 ||
                    (location.Host != "api.github.com" && location.Host != "github.com" &&
                     location.Host != "release-assets.githubusercontent.com" && location.Host != "objects.githubusercontent.com"))
                    throw new InvalidDataException("Неизвестный адрес обновления.");
                using (var request = new HttpRequestMessage(HttpMethod.Get, location))
                {
                    request.Headers.UserAgent.ParseAdd("Planner-Windows/" + Current.ToString(3));
                    var response = await Http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, token)
                        .ConfigureAwait(false);
                    if ((int)response.StatusCode < 300 || (int)response.StatusCode >= 400 ||
                        response.Headers.Location == null)
                        return response;
                    using (response)
                        location = new Uri(location, response.Headers.Location);
                }
            }
            throw new IOException("Слишком много перенаправлений.");
        }

        private static async Task CopyAsync(HttpResponseMessage response, Stream output, int maximum, CancellationToken token)
        {
            using (var input = await response.Content.ReadAsStreamAsync().ConfigureAwait(false))
            {
                var buffer = new byte[32768];
                int total = 0, read;
                while ((read = await input.ReadAsync(buffer, 0, buffer.Length, token).ConfigureAwait(false)) > 0)
                {
                    total += read;
                    if (total > maximum) throw new InvalidDataException("Превышен размер файла обновления.");
                    await output.WriteAsync(buffer, 0, read, token).ConfigureAwait(false);
                }
            }
        }

        [DataContract]
        private sealed class GitHubRelease
        {
            [DataMember(Name = "tag_name")] public string Tag { get; set; }
            [DataMember(Name = "draft")] public bool Draft { get; set; }
            [DataMember(Name = "prerelease")] public bool Prerelease { get; set; }
            [DataMember(Name = "assets")] public ReleaseAsset[] Assets { get; set; }
        }

        [DataContract]
        private sealed class ReleaseAsset
        {
            [DataMember(Name = "name")] public string Name { get; set; }
            [DataMember(Name = "size")] public int Size { get; set; }
            [DataMember(Name = "digest")] public string Digest { get; set; }
            [DataMember(Name = "browser_download_url")] public string Url { get; set; }
        }
    }

    internal sealed class UpdateRelease
    {
        public Version Version;
        public Uri Location;
        public int Size;
        public string Digest;
    }

    internal sealed partial class MainWindow
    {
        private readonly CancellationTokenSource updateLifetime = new CancellationTokenSource();
        private UpdateClient updateClient;
        private UpdateRelease availableUpdate;
        private Button updateButton;
        private Button settingsUpdateButton;
        private TextBlock updateStatusText;
        private DispatcherTimer updateTimer;
        private bool updateBusy, updatesInstalled;
        private string updateStatus;

        private void InitializeUpdates()
        {
            updatesInstalled = InstallationPaths.IsInstalled();
            updateClient = new UpdateClient(ConfigurationManager.AppSettings["ReleaseRepository"]);
            if (updatesInstalled && updateClient.Configured && !testing)
            {
                Loaded += CheckOnLoad;
                updateTimer = new DispatcherTimer { Interval = TimeSpan.FromHours(6) };
                updateTimer.Tick += (sender, e) => CheckForUpdates(false);
                updateTimer.Start();
            }
            Closed += (sender, e) =>
            {
                if (updateTimer != null) updateTimer.Stop();
                updateLifetime.Cancel();
            };
        }

        private void CheckOnLoad(object sender, RoutedEventArgs e)
        {
            Loaded -= CheckOnLoad;
            CheckForUpdates(false);
        }

        private void AddUpdateSettings(StackPanel panel)
        {
            panel.Children.Add(Gap(12));
            panel.Children.Add(Text("Версия " + UpdateClient.Current.ToString(3), 12, Muted));
            if (!updatesInstalled || !updateClient.Configured) return;
            updateStatusText = Text("", 12, Muted);
            panel.Children.Add(updateStatusText);
            settingsUpdateButton = Button("Проверить обновления", RunUpdateAction, "settings-update", "outline");
            settingsUpdateButton.Margin = new Thickness(0, 6, 0, 0);
            panel.Children.Add(settingsUpdateButton);
            RefreshUpdateControls();
        }

        private void RefreshUpdateControls()
        {
            updateButton.Visibility = availableUpdate != null ? Visibility.Visible : Visibility.Collapsed;
            updateButton.IsEnabled = !updateBusy;
            if (settingsUpdateButton != null)
            {
                string title = availableUpdate == null ? "Проверить обновления" : "Обновить и перезапустить";
                settingsUpdateButton.Content = Text(title, 13, TextInk, true);
                System.Windows.Automation.AutomationProperties.SetName(settingsUpdateButton, title);
                settingsUpdateButton.IsEnabled = !updateBusy;
                updateStatusText.Text = updateStatus ?? "";
                updateStatusText.Visibility = String.IsNullOrEmpty(updateStatus) ? Visibility.Collapsed : Visibility.Visible;
            }
        }

        private void RunUpdateAction()
        {
            if (availableUpdate == null) CheckForUpdates(true);
            else ApplyUpdate();
        }

        private async void CheckForUpdates(bool explicitCheck)
        {
            if (updateBusy) return;
            updateBusy = true;
            if (explicitCheck) updateStatus = "Проверяем обновления…";
            RefreshUpdateControls();
            try
            {
                using (var request = CancellationTokenSource.CreateLinkedTokenSource(updateLifetime.Token))
                {
                    request.CancelAfter(TimeSpan.FromSeconds(12));
                    availableUpdate = await updateClient.CheckAsync(request.Token);
                    updateStatus = availableUpdate == null ? "Установлена последняя доступная версия." :
                        "Доступна версия " + availableUpdate.Version.ToString(3);
                }
            }
            catch (Exception error)
            {
                if (explicitCheck) updateStatus = UpdateErrorMessage(error);
            }
            finally
            {
                updateBusy = false;
                if (!updateLifetime.IsCancellationRequested) RefreshUpdateControls();
            }
        }

        private async void ApplyUpdate()
        {
            if (updateBusy || availableUpdate == null) return;
            updateBusy = true;
            updateStatus = "Скачиваем обновление…";
            RefreshUpdateControls();
            string setup = null;
            try
            {
                using (var request = CancellationTokenSource.CreateLinkedTokenSource(updateLifetime.Token))
                {
                    request.CancelAfter(TimeSpan.FromSeconds(60));
                    setup = await UpdateClient.DownloadAsync(availableUpdate,
                        Path.Combine(store.DirectoryPath, "Updates"), request.Token);
                    request.Token.ThrowIfCancellationRequested();
                }
                store.BackupFor(availableUpdate.Version);
                using (Process current = Process.GetCurrentProcess())
                using (Process process = Process.Start(new ProcessStartInfo(setup, "--apply " +
                    current.Id.ToString(CultureInfo.InvariantCulture)) { UseShellExecute = false })) { }
                Close();
            }
            catch (Exception error)
            {
                if (setup != null)
                {
                    try { File.Delete(setup); }
                    catch (IOException) { }
                    catch (UnauthorizedAccessException) { }
                }
                updateStatus = UpdateErrorMessage(error);
                if (!updateLifetime.IsCancellationRequested)
                {
                    if (drawer.Visibility != Visibility.Visible)
                        MessageBox.Show(this, updateStatus, "Планер", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            finally
            {
                updateBusy = false;
                if (!updateLifetime.IsCancellationRequested) RefreshUpdateControls();
            }
        }

        private static string UpdateErrorMessage(Exception error)
        {
            if (error is OperationCanceledException) return "Сервер обновлений не ответил вовремя. Повторите проверку.";
            Exception cause = error.GetBaseException();
            if (cause is System.Security.Authentication.AuthenticationException)
                return "Не удалось установить защищённое соединение с GitHub.";
            if (error is HttpRequestException)
                return "Нет соединения с сервером обновлений. " + cause.Message;
            if (error is InvalidDataException) return error.Message;
            return "Не удалось завершить обновление. " + cause.Message;
        }
    }
}
