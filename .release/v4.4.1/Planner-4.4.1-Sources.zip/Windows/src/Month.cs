using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Planner
{
    internal sealed partial class MainWindow
    {
        private void RenderMonth()
        {
            DateRange range = CalendarRules.Range(Period.Month, anchor);
            var tasks = BoardTasks(range);
            var goals = Order(planner.Goals(Period.Month, anchor)).ToList();
            var steps = planner.Entries.Where(item => item.Kind == EntryKind.Subgoal && item.Day.HasValue &&
                range.Contains(item.Day.Value)).ToList();

            content.Children.Add(MonthDashboard(range, tasks, goals, steps));
            content.Children.Add(Gap(18));
            BoardTitle("Календари");
            var lanes = Horizontal();
            foreach (BoardColumn column in planner.Columns)
            {
                string columnId = column.Id;
                var columnTasks = tasks.Where(item => item.BoardColumn == columnId).ToList();
                var columnSteps = steps.Where(item => planner.Find(item.ParentId).BoardColumn == columnId).ToList();
                var columnGoals = goals.Where(item => item.BoardColumn == columnId).ToList();
                lanes.Children.Add(MonthLane(range, column, columnTasks, columnSteps, columnGoals));
            }
            lanes.Children.Add(AddColumnButton());
            content.Children.Add(HorizontalBoard(lanes));
            RenderIncoming(goals);
        }

        private Border MonthLane(DateRange range, BoardColumn column, IList<Entry> tasks, IList<Entry> steps, IList<Entry> goals)
        {
            var panel = new StackPanel();
            panel.Children.Add(ColumnHeader(column, () => NewGoal(Period.Month, column.Id)));
            var byTask = tasks.ToLookup(item => item.Day.Value);
            var byStep = steps.ToLookup(item => item.Day.Value);
            var group = new StackPanel();
            var legend = Text("ЗАДАЧИ  /  ПОДЦЕЛИ", 10, Muted, true);
            legend.Margin = new Thickness(4, 1, 0, 4);
            group.Children.Add(legend);
            group.Children.Add(CalendarGrid(range, 34, (day, inMonth) =>
            {
                var dayTasks = byTask[day].ToList();
                var daySteps = byStep[day].ToList();
                string id = "month-date-" + column.Id + "-" + day.ToString("yyyyMMdd");
                bool current = day == planner.Today;
                var cell = Button("", () => ShowMonthDay(day, dayTasks, daySteps), id, "plain");
                if (inMonth)
                {
                    int density = Math.Min(dayTasks.Count, 4);
                    if (density > 0)
                    {
                        Color color = ((SolidColorBrush)accent).Color;
                        cell.Background = new SolidColorBrush(Color.FromArgb((byte)(14 + density * 14), color.R, color.G, color.B));
                    }
                    if (current)
                    {
                        cell.BorderBrush = accent;
                        cell.BorderThickness = new Thickness(1);
                    }
                }
                cell.Padding = new Thickness(1, 1, 1, 1);
                cell.MinHeight = 30;
                cell.IsEnabled = inMonth;
                Identify(cell, null, CalendarRules.Label(Period.Day, day) + ", задач " + dayTasks.Count + ", подцелей " + daySteps.Count);
                var label = new StackPanel();
                var date = Text(day.Day.ToString(), 13, current ? accent : inMonth ? TextInk : Muted, true);
                date.HorizontalAlignment = HorizontalAlignment.Center;
                label.Children.Add(date);
                if (inMonth && dayTasks.Count + daySteps.Count > 0)
                {
                    var counts = Text(dayTasks.Count + "/" + daySteps.Count, 10, TextInk, true);
                    Identify(counts, id + "-count");
                    counts.HorizontalAlignment = HorizontalAlignment.Center;
                    label.Children.Add(counts);
                }
                cell.Content = label;
                return cell;
            }));
            var calendar = Card(group, new Thickness(7, 6, 7, 6));
            panel.Children.Add(calendar);
            panel.Children.Add(Gap(12));
            var goalsLabel = Text("Цели месяца", 13, Muted, true);
            goalsLabel.Margin = new Thickness(4, 0, 0, 6);
            panel.Children.Add(goalsLabel);
            foreach (Entry goal in goals) panel.Children.Add(BoardCard(goal, true));
            if (goals.Count == 0)
                panel.Children.Add(QuietAdd("Новая цель", () => NewGoal(Period.Month, column.Id), "new-month-goal-" + column.Id));
            var lane = ColumnSurface(panel);
            lane.Width = 354;
            Identify(lane, "month-lane-" + column.Id);
            return lane;
        }
    }
}
