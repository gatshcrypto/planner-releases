using System;
using System.Globalization;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Planner
{
    internal sealed partial class MainWindow
    {
        private bool backupBusy, backupClosed;
        private DateTime backupAttempt;
        private string backupError;
        private TextBlock backupStatus;
        private Button backupNow, backupChooseFolder;

        private string BackupFolder()
        {
            return store.Setting("backup-folder", Path.Combine(store.DirectoryPath, "Backups", "Daily"));
        }

        private void CheckAutomaticBackup()
        {
            if (testing || backupBusy || DateTime.UtcNow - backupAttempt < TimeSpan.FromMinutes(15)) return;
            DateTime last;
            if (DateTime.TryParse(store.Setting("backup-last-utc", ""), CultureInfo.InvariantCulture,
                DateTimeStyles.RoundtripKind, out last) && DateTime.UtcNow - last.ToUniversalTime() < TimeSpan.FromMinutes(15)) return;
            RunBackup(false);
        }

        private void RunBackup(bool notify)
        {
            if (backupBusy) return;
            backupBusy = true;
            backupAttempt = DateTime.UtcNow;
            backupError = null;
            UpdateBackupStatus();
            try
            {
                BackupManager.CreateAsync(store, BackupFolder(), DateTime.Now).ContinueWith(done =>
                {
                    bool succeeded = done.Status == TaskStatus.RanToCompletion;
                    var observed = done.Exception;
                    if (!Dispatcher.HasShutdownStarted) Dispatcher.BeginInvoke(new Action(() => FinishBackup(succeeded, notify)));
                });
            }
            catch (Exception)
            {
                FinishBackup(false, notify);
            }
        }

        private void FinishBackup(bool succeeded, bool notify)
        {
            if (backupClosed) return;
            try
            {
                if (succeeded) store.SetSetting("backup-last-utc", DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture));
                else backupError = "Не удалось сохранить копию. Проверьте выбранную папку и свободное место.";
                if (notify) Notice(succeeded ? "Резервная копия сохранена" : backupError);
            }
            finally { backupBusy = false; UpdateBackupStatus(); }
        }

        private void UpdateBackupStatus()
        {
            if (backupNow != null) backupNow.IsEnabled = !backupBusy;
            if (backupChooseFolder != null) backupChooseFolder.IsEnabled = !backupBusy;
            if (backupStatus == null) return;
            DateTime last;
            backupStatus.Text = backupBusy ? "Сохраняем…" : backupError ??
                (DateTime.TryParse(store.Setting("backup-last-utc", ""), CultureInfo.InvariantCulture,
                    DateTimeStyles.RoundtripKind, out last) ? "Последняя копия · " + last.ToLocalTime().ToString("dd.MM.yyyy HH:mm") : "Копий пока нет");
        }

        private void ShowBackups()
        {
            var panel = new StackPanel();
            panel.Children.Add(Text("Автоматически каждые 15 минут, пока планер открыт. Сохраняются ежедневные копии и последняя версия.", 14, Muted));
            panel.Children.Add(Gap(10));
            panel.Children.Add(Text(BackupFolder(), 12, Muted));
            backupStatus = Text("", 13, Muted);
            Identify(backupStatus, "backup-status");
            panel.Children.Add(backupStatus);
            panel.Children.Add(Gap(12));
            backupNow = Button("Создать копию сейчас", () => RunBackup(true), "backup-now", "primary");
            panel.Children.Add(backupNow);
            backupChooseFolder = Button("Выбрать папку", () =>
            {
                using (var picker = new System.Windows.Forms.FolderBrowserDialog { Description = "Папка резервных копий планера", SelectedPath = BackupFolder(), ShowNewFolderButton = true })
                {
                    if (picker.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;
                    store.SetSetting("backup-folder", picker.SelectedPath);
                }
                ShowBackups();
                RunBackup(true);
            }, "backup-folder", "outline");
            panel.Children.Add(backupChooseFolder);
            panel.Children.Add(Button("Открыть папку", () =>
            {
                try
                {
                    string folder = BackupFolder();
                    Directory.CreateDirectory(folder);
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(folder) { UseShellExecute = true });
                }
                catch { Notice("Папка недоступна"); }
            }, "backup-open", "outline"));
            panel.Children.Add(Gap(12));
            panel.Children.Add(Text("Для защиты от поломки компьютера выберите папку своего облачного диска или внешний накопитель. Ключ доступа храните отдельно.", 13, Muted));
            string recovery = Path.Combine(store.DirectoryPath, "CloudHosting", "Доступ к планеру.txt");
            if (File.Exists(recovery)) panel.Children.Add(Button("Сохранить файл доступа", () => SaveRecoveryFile(recovery), "backup-access", "outline"));
            panel.Children.Add(Button("Сохранить инструкцию восстановления", () =>
            {
                var dialog = new Microsoft.Win32.SaveFileDialog { FileName = "Восстановление планера.txt", Filter = "Текст|*.txt" };
                if (dialog.ShowDialog(this) == true)
                {
                    try { File.WriteAllText(dialog.FileName, BackupManager.Guide, System.Text.Encoding.UTF8); Notice("Инструкция сохранена"); }
                    catch { Notice("Не удалось сохранить инструкцию"); }
                }
            }, "backup-guide", "outline"));
            OpenDrawer("Резервные копии", panel, ShowBackups);
            UpdateBackupStatus();
        }

        private void SaveRecoveryFile(string source)
        {
            var dialog = new Microsoft.Win32.SaveFileDialog { FileName = "Доступ к планеру.txt", Filter = "Текст|*.txt" };
            if (dialog.ShowDialog(this) != true) return;
            try
            {
                if (!String.Equals(Path.GetFullPath(source), Path.GetFullPath(dialog.FileName), StringComparison.OrdinalIgnoreCase)) File.Copy(source, dialog.FileName, true);
                Notice("Файл доступа сохранён");
            }
            catch { Notice("Не удалось сохранить файл доступа"); }
        }
    }
}
