using System;
using System.IO;
using System.Reflection;

namespace Planner
{
    internal static class InstallationPaths
    {
        internal const string AppFile = "Planner.exe";
        internal const string ConfigFile = "Planner.exe.config";
        internal const string MaintenanceFile = "PlannerMaintenance.exe";

        internal static string ProgramFolder
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Programs", "Planner"); }
        }

        internal static bool IsInstalled()
        {
            return String.Equals(Assembly.GetExecutingAssembly().Location, Path.Combine(ProgramFolder, AppFile),
                StringComparison.OrdinalIgnoreCase) && File.Exists(Path.Combine(ProgramFolder, MaintenanceFile));
        }
    }
}
