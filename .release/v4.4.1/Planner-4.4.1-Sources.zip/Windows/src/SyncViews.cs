using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace Planner
{
    internal sealed partial class MainWindow
    {
        private SyncClient synchronization;
        private DispatcherTimer synchronizationTimer;
        private TextBlock synchronizationStatus;
        private CloudflarePublisher phonePublisher;
        private void InitializeSynchronization()
        {
            synchronization = new SyncClient(store);
            synchronization.Changed = () => {
                if (synchronizationStatus != null) synchronizationStatus.Text = synchronization.Status;
            };
            synchronization.Applied = () => {
                planner.Reload(); finance.Reload();
                bool restyle = currentStyle.Key != store.Setting("palette", "emerald");
                if (restyle)
                {
                    double vertical = scroller.VerticalOffset;
                    double horizontal = boardScroller == null ? 0 : boardScroller.HorizontalOffset;
                    ((Panel)noticeHost.Parent).Children.Remove(noticeHost);
                    SetColors(); BuildShell(); Refresh(false);
                    scroller.ScrollToVerticalOffset(vertical);
                    if (boardScroller != null) boardScroller.ScrollToHorizontalOffset(horizontal);
                    if (noticeBox != null) noticeBox.Background = accentWash;
                }
                else Refresh();
            };
            if (testing) return;
            synchronizationTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(15) };
            synchronizationTimer.Tick += async (sender, e) => {
                if (drawer.Visibility != Visibility.Visible) await synchronization.SynchronizeAsync(null);
            };
            synchronizationTimer.Start();
            Loaded += async (sender, e) => { await synchronization.SynchronizeAsync(null); };
        }
        private void ShowSynchronization()
        {
            var panel = new StackPanel();
            synchronizationStatus = Text(synchronization.Status, 13, Muted);
            panel.Children.Add(synchronizationStatus);
            panel.Children.Add(Gap(12));
            panel.Children.Add(Button("Настроить приложение для iPhone", () => {
                string cloudFolder = System.IO.Path.Combine(store.DirectoryPath, "CloudHosting");
                if (synchronization.Configured && System.IO.File.Exists(System.IO.Path.Combine(cloudFolder, "owner.dat")))
                {
                    using (var publisher = new CloudflarePublisher(cloudFolder))
                    {
                        publisher.Origin = synchronization.ServerAddress;
                        publisher.RecoveryFile = System.IO.Path.Combine(cloudFolder, "Доступ к планеру.txt");
                        ShowPhoneReady(publisher);
                    }
                }
                else ShowPhoneSetup();
            }, "setup-iphone", "primary"));
            panel.Children.Add(Gap(14));
            var address = Input("sync-address", synchronization.ServerAddress ?? "");
            Head(panel, "Адрес планера"); panel.Children.Add(address);
            panel.Children.Add(Gap(8));
            var code = Input("sync-code", "");
            Head(panel, "Код подключения"); panel.Children.Add(code);
            panel.Children.Add(Gap(12));
            var connect = Button("Подключить", () => { }, "sync-connect", "primary");
            connect.Click += async (sender, e) => {
                connect.IsEnabled = false;
                try { await synchronization.ConnectAsync(address.Text, code.Text); code.Clear(); }
                catch (Exception error) { synchronizationStatus.Text = error.Message; }
                finally { connect.IsEnabled = true; }
            };
            panel.Children.Add(connect);
            panel.Children.Add(Button("Синхронизировать сейчас", async () => { await synchronization.SynchronizeAsync(null); ShowSynchronization(); }, "sync-now", "outline"));
            if (synchronization.Conflicted)
            {
                panel.Children.Add(Gap(12));
                panel.Children.Add(Text("Одни записи изменены на двух устройствах. Выберите версию этих записей.", 13, Muted));
                panel.Children.Add(Button("Оставить изменения компьютера", async () => { await synchronization.SynchronizeAsync(true); ShowSynchronization(); }, "sync-keep-local", "outline"));
                panel.Children.Add(Button("Принять изменения с телефона", async () => { await synchronization.SynchronizeAsync(false); ShowSynchronization(); }, "sync-keep-remote", "outline"));
            }
            OpenDrawer("Синхронизация", panel, ShowSynchronization);
        }

        private void ShowPhoneSetup()
        {
            if (phonePublisher != null) { Notice("Настройка уже запущена"); return; }
            var panel = new StackPanel();
            panel.Children.Add(Text("Планер разместится в вашем аккаунте Cloudflare. Данные Windows сохранятся и появятся на телефоне.", 14, Muted));
            panel.Children.Add(Gap(18));
            var status = Text("Подключите бесплатный аккаунт Cloudflare", 14, TextInk, true); panel.Children.Add(status);
            var start = Button("Подключить Cloudflare", () => { }, "phone-setup-start", "primary");
            start.Margin = new Thickness(0, 18, 0, 0); panel.Children.Add(start);
            var cancel = Button("Отмена", () => { if (phonePublisher != null) phonePublisher.Cancel(); }, "phone-setup-cancel", "outline");
            cancel.Visibility = Visibility.Collapsed; panel.Children.Add(cancel);
            start.Click += async (sender, e) => {
                start.IsEnabled = false; cancel.Visibility = Visibility.Visible;
                var publisher = new CloudflarePublisher(System.IO.Path.Combine(store.DirectoryPath, "CloudHosting"));
                phonePublisher = publisher;
                publisher.Progress = message => status.Text = message;
                publisher.ChooseAccount = accounts => {
                    var completion = new System.Threading.Tasks.TaskCompletionSource<string>();
                    status.Text = "Выберите аккаунт Cloudflare";
                    foreach (var account in accounts)
                    {
                        string id = SyncDocument.Text(account, "id");
                        var choice = Button(SyncDocument.Text(account, "name") ?? id, () => completion.TrySetResult(id), "cloudflare-account-" + id, "outline");
                        panel.Children.Add(choice);
                    }
                    return completion.Task;
                };
                try
                {
                    await publisher.AuthorizeAsync();
                    string code = await publisher.PublishAsync();
                    status.Text = "Перенос записей Windows";
                    await synchronization.ConnectAsync(publisher.Origin, code);
                    if (!synchronization.Status.StartsWith("Синхронизировано", StringComparison.Ordinal)) throw new InvalidOperationException(synchronization.Status);
                    ShowPhoneReady(publisher);
                }
                catch (OperationCanceledException) { status.Text = "Настройка отменена"; }
                catch (Exception error) { status.Text = error.Message; }
                finally { publisher.Dispose(); phonePublisher = null; start.IsEnabled = true; cancel.Visibility = Visibility.Collapsed; }
            };
            OpenDrawer("Планер на iPhone", panel, ShowPhoneSetup);
        }
        private void ShowPhoneReady(CloudflarePublisher publisher)
        {
            string origin = publisher.Origin, key = publisher.ReadRecoveryKey(), recovery = publisher.RecoveryFile;
            var panel = new StackPanel();
            panel.Children.Add(Text("Планер опубликован · записи перенесены", 17, TextInk, true));
            panel.Children.Add(Gap(12));
            panel.Children.Add(Text(origin, 13, Muted));
            panel.Children.Add(Gap(8));
            panel.Children.Add(Text("На iPhone откройте этот адрес в Safari и добавьте его на экран «Домой». Откройте появившийся значок и войдите ключом доступа.", 14, Muted));
            panel.Children.Add(Button("Скопировать адрес", () => Clipboard.SetText(origin), "copy-phone-address", "outline"));
            panel.Children.Add(Button("Скопировать ключ доступа", () => Clipboard.SetText(key), "copy-phone-key", "outline"));
            panel.Children.Add(Button("Открыть планер", () => System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(origin) { UseShellExecute = true }), "open-phone-app", "primary"));
            panel.Children.Add(Button("Открыть файл восстановления", () => System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(recovery) { UseShellExecute = true }), "phone-recovery-file", "outline"));
            panel.Children.Add(Button("Обновить мобильную версию", ShowPhoneSetup, "phone-redeploy", "outline"));
            OpenDrawer("Готово", panel, () => ShowPhoneReady(publisher));
        }
    }
}
