using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace Planner
{
    internal sealed partial class MainWindow
    {
        private void ShowOverdue()
        {
            var tasks = planner.OverdueTasks().ToList();
            var panel = new StackPanel();
            if (tasks.Count == 0)
            {
                Empty(panel, "Просроченных задач нет");
                OpenDrawer("Просрочено", panel);
                return;
            }

            var selected = new HashSet<string>();
            var actions = new WrapPanel { Margin = new Thickness(0, 0, 0, 8) };
            var selectAll = Button("Выбрать все", () => { }, "overdue-all", "plain");
            var today = Button("На сегодня", () => ApplyOverdue(selected, planner.Today), "overdue-today", "outline");
            var tomorrow = Button("На завтра", () => ApplyOverdue(selected, planner.Today.AddDays(1)), "overdue-tomorrow", "outline");
            var other = Button("Другая дата", () => PickOverdueDestination(selected), "overdue-other", "outline");
            foreach (Button button in new[] { selectAll, today, tomorrow, other })
            {
                button.Margin = new Thickness(0, 0, 4, 4);
                actions.Children.Add(button);
            }
            panel.Children.Add(actions);

            var body = new StackPanel();
            panel.Children.Add(body);
            Action render = null;
            render = () =>
            {
                selectAll.Content = selected.Count == tasks.Count ? "Снять выбор" : "Выбрать все";
                Identify(selectAll, null, (string)selectAll.Content);
                today.IsEnabled = tomorrow.IsEnabled = other.IsEnabled = selected.Count > 0;
                body.Children.Clear();
                foreach (var group in tasks.GroupBy(task => task.Day.Value))
                {
                    var day = Text(CalendarRules.Label(Period.Day, group.Key), 12, Muted, true);
                    day.Margin = new Thickness(0, 8, 0, 4);
                    body.Children.Add(day);
                    foreach (Entry task in group)
                    {
                        var item = new DockPanel();
                        string id = "overdue-check-" + task.Id;
                        var check = ToggleButton(selected.Contains(task.Id), task.Title, () =>
                        {
                            if (!selected.Add(task.Id)) selected.Remove(task.Id);
                            render();
                            var replacement = FindControl(body, id) as Button;
                            if (replacement != null) replacement.Focus();
                        }, id);
                        DockPanel.SetDock(check, Dock.Left);
                        item.Children.Add(check);
                        var name = new StackPanel { Margin = new Thickness(5, 1, 0, 1) };
                        name.Children.Add(Text(task.Title, 14, TextInk, true));
                        string meta = ColumnName(task.BoardColumn);
                        if (task.Time.HasValue) meta += " · " + task.Time.Value.ToString(@"hh\:mm");
                        if (task.DurationMinutes.HasValue) meta += " · " + FormatLoad(task.DurationMinutes.Value);
                        name.Children.Add(Text(meta, 11, Muted));
                        item.Children.Add(name);
                        var card = Card(item, new Thickness(5, 4, 8, 4));
                        card.Margin = new Thickness(0, 0, 0, 5);
                        body.Children.Add(card);
                    }
                }
            };
            selectAll.Click += (sender, e) =>
            {
                if (selected.Count == tasks.Count) selected.Clear();
                else selected.UnionWith(tasks.Select(task => task.Id));
                render();
            };
            render();
            OpenDrawer("Просрочено · " + tasks.Count, panel);
        }

        private void PickOverdueDestination(IEnumerable<string> selected)
        {
            var ids = selected.ToArray();
            var panel = new StackPanel();
            var date = PickDate(planner.Today, null, "overdue-date");
            FormLabel(panel, "Дата", date);
            var error = Text("", 12, PriorityColors[3], true);
            panel.Children.Add(error);
            Action move = () =>
            {
                try { ApplyOverdue(ids, ReadPickedDate(date, null)); }
                catch (ArgumentException invalid) { error.Text = invalid.Message; }
            };
            var actions = Horizontal();
            actions.Children.Add(Button("Перенести", move, "overdue-move", "primary"));
            actions.Children.Add(Button("Назад", ShowOverdue));
            panel.Children.Add(actions);
            OpenDrawer("Перенести задачи", panel, null, move);
        }

        private void ApplyOverdue(IEnumerable<string> selected, DateTime day)
        {
            int count = planner.MoveOverdue(selected, day);
            CloseDrawer(false);
            Refresh();
            if (count > 0)
            {
                Notice("Перенесено: " + count + " · " + day.ToString("d MMMM", CalendarRules.Russian));
                var notification = noticeBox;
                var timeout = new DispatcherTimer { Interval = TimeSpan.FromSeconds(5) };
                timeout.Tick += (sender, e) =>
                {
                    timeout.Stop();
                    if (noticeBox == notification) noticeHost.Children.Clear();
                };
                timeout.Start();
            }
        }
    }
}
