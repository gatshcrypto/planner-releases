#if PLANNER_TESTS
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Planner
{
    internal static class SyncIntegration
    {
        private static List<string> checks = new List<string>();
        private static void Check(bool value, string message) { if (!value) throw new InvalidOperationException(message); checks.Add("PASS " + message); }
        public static int Run(string folder, string address)
        {
            Directory.CreateDirectory(folder);
            try { RunAsync(folder, address).GetAwaiter().GetResult(); File.WriteAllLines(Path.Combine(folder, "sync-test.txt"), checks); return 0; }
            catch (Exception error) { File.WriteAllText(Path.Combine(folder, "sync-test.txt"), error.ToString()); return 1; }
        }
        private static async Task RunAsync(string folder, string address)
        {
            string token = Environment.GetEnvironmentVariable("PLANNER_TEST_SESSION");
            if (String.IsNullOrEmpty(token)) throw new InvalidOperationException("Test session missing");
            using (var store = new Store(Path.Combine(folder, "planner.sqlite")))
            using (var sync = new SyncClient(store))
            using (var phone = new HttpClient(new HttpClientHandler { AllowAutoRedirect = false }))
            {
                phone.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                sync.TestConnect(address, token);
                var goal = new Entry { Kind = EntryKind.Goal, Title = "Цель Windows", Day = DateTime.Today, Period = Period.Year, TargetDay = DateTime.Today.AddYears(1) };
                var step = new Entry { Kind = EntryKind.Subgoal, Title = "Подцель Windows", ParentId = goal.Id };
                var task = new Entry { Kind = EntryKind.Task, Title = "Задача Windows", ParentId = step.Id, Day = DateTime.Today, Time = new TimeSpan(9, 25, 0) };
                var habit = new Entry { Kind = EntryKind.Habit, Title = "Привычка Windows", Day = DateTime.Today };
                store.Save(goal); store.Save(step); store.Save(task); store.Save(habit); store.SetMark(habit.Id, DateTime.Today, true);
                var account = new FinanceAccount { Name = "Карта", Opening = 100025 };
                var category = new FinanceCategory { Name = "Доход", Kind = FinanceKind.Income };
                var operation = new FinanceOperation { Kind = FinanceKind.Income, AccountId = account.Id, CategoryId = category.Id, Amount = 12345, Day = DateTime.Today };
                store.SaveFinanceAccount(account); store.SaveFinanceCategory(category); store.SaveFinanceOperation(operation);
                string backup = store.BackupBeforeSync();
                using (var preserved = new Store(backup)) Check(preserved.ReadEntries().Any(item => item.Id == task.Id) && preserved.ReadFinanceOperations().Any(item => item.Id == operation.Id),
                    "Резервная копия перед синхронизацией содержит последние записи и финансы");
                await sync.SynchronizeAsync(null);
                var remote = await Read(phone, address); var state = SyncDocument.Map(remote, "state");
                Check(SyncDocument.Items(state, "entries").Any(item => SyncDocument.Text(item, "id") == task.Id), "Windows отправляет записи в общий сервер");
                Check(SyncDocument.Items(state, "operations").Single(item => SyncDocument.Text(item, "id") == operation.Id)["amount"].ToString() == "12345", "Копейки сохраняются без округления");
                Check(SyncDocument.Items(state, "entries").Single(item => SyncDocument.Text(item, "id") == task.Id)["parentId"].ToString() == step.Id, "Идентификаторы и связи Windows сохранены");
                var mobile = SyncDocument.Object("id", "phone-task", "kind", "task", "title", "С телефона", "day", DateTime.Today.AddDays(1).ToString("yyyy-MM-dd"), "time", "13:45", "parentId", step.Id,
                    "reminderAt", DateTime.UtcNow.AddHours(2).ToString("o"), "priority", 3, "checked", false, "notes", "Описание iPhone");
                var items = SyncDocument.Items(state, "entries"); items.Add(mobile); state["entries"] = items;
                await Write(phone, address, remote);
                await sync.SynchronizeAsync(null);
                Check(store.ReadEntries().Single(item => item.Id == "phone-task").Time == new TimeSpan(13, 45, 0), "Телефонная задача появляется в Windows с датой и временем");
                var localTask = store.ReadEntries().Single(item => item.Id == task.Id); localTask.Title = "Изменение Windows"; store.Save(localTask);
                remote = await Read(phone, address); state = SyncDocument.Map(remote, "state");
                SyncDocument.Items(state, "entries").Single(item => SyncDocument.Text(item, "id") == "phone-task")["title"] = "Изменение телефона";
                await Write(phone, address, remote); await sync.SynchronizeAsync(null);
                Check(!sync.Conflicted && store.ReadEntries().Any(item => item.Title == "Изменение телефона"), "Независимые правки устройств объединяются");
                remote = await Read(phone, address); state = SyncDocument.Map(remote, "state");
                Check(SyncDocument.Items(state, "entries").Any(item => SyncDocument.Text(item, "title") == "Изменение Windows"), "Обратная правка Windows видна телефону");
                localTask = store.ReadEntries().Single(item => item.Id == "phone-task"); localTask.Title = "Редакция Windows"; store.Save(localTask);
                await sync.SynchronizeAsync(null); remote = await Read(phone, address); state = SyncDocument.Map(remote, "state");
                Check(SyncDocument.Text(SyncDocument.Items(state, "entries").Single(item => SyncDocument.Text(item, "id") == "phone-task"), "reminderAt") != null,
                    "Windows сохраняет поля напоминаний, которых нет в его интерфейсе");
                localTask = store.ReadEntries().Single(item => item.Id == "phone-task"); localTask.Title = "Моя версия"; store.Save(localTask);
                SyncDocument.Items(state, "entries").Single(item => SyncDocument.Text(item, "id") == "phone-task")["title"] = "Другая версия";
                await Write(phone, address, remote); await sync.SynchronizeAsync(null);
                Check(sync.Conflicted && store.ReadEntries().Single(item => item.Id == "phone-task").Title == "Моя версия", "Конфликт одной записи не уничтожает локальную версию");
                await sync.SynchronizeAsync(true);
                remote = await Read(phone, address); state = SyncDocument.Map(remote, "state");
                Check(!sync.Conflicted && SyncDocument.Text(SyncDocument.Items(state, "entries").Single(item => SyncDocument.Text(item, "id") == "phone-task"), "title") == "Моя версия", "Выбор версии компьютера разрешает конфликт");
                store.Delete("phone-task");
                SyncDocument.Items(state, "entries").Single(item => SyncDocument.Text(item, "id") == "phone-task")["title"] = "Восстановлено с телефона";
                await Write(phone, address, remote); await sync.SynchronizeAsync(null);
                Check(sync.Conflicted, "Удаление и одновременное редактирование определяются как конфликт");
                await sync.SynchronizeAsync(false);
                Check(store.ReadEntries().Single(item => item.Id == "phone-task").Title == "Восстановлено с телефона", "Выбор телефона восстанавливает запись вместе со связью");
                // Simulate an acknowledged remote insertion while a fresh native edit is still pending.
                var before = store.ExportSync(); var shadow = SyncDocument.Clone(before);
                var added = SyncDocument.Object("id", "server-only", "kind", "task", "title", "Новая удалённая", "day", DateTime.Today.ToString("yyyy-MM-dd"));
                var shadowItems = SyncDocument.Items(shadow, "entries"); shadowItems.Add(added); shadow["entries"] = shadowItems;
                var overlay = SyncDocument.Overlay(shadow, before, store.ExportSync());
                Check(SyncDocument.Items(overlay, "entries").Any(item => SyncDocument.Text(item, "id") == "server-only"), "Запись, полученная во время отправки, не теряется");
                Check(store.ReadMarks().Any(mark => mark.Id == habit.Id), "Отметки привычки переживают полную синхронизацию");
                Check(store.ReadFinanceOperations().Single(item => item.Id == operation.Id).Amount == 12345, "Финансовая операция переживает несколько обменов");
                File.WriteAllText(Path.Combine(folder, "synced-state.json"), SyncDocument.Write(store.ExportSync()));
            }
        }
        private static async Task<Dictionary<string, object>> Read(HttpClient http, string origin)
        { return SyncDocument.Parse(await http.GetStringAsync(origin + "/api/state")); }
        private static async Task Write(HttpClient http, string origin, Dictionary<string, object> remote)
        {
            using (var response = await http.PutAsync(origin + "/api/state", new StringContent(SyncDocument.Write(SyncDocument.Object("state", SyncDocument.Map(remote, "state"), "revision", remote["revision"])), Encoding.UTF8, "application/json")))
            { response.EnsureSuccessStatusCode(); }
        }
    }
}
#endif
