using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web.Script.Serialization;

namespace Planner
{
    // The wire document is independent of WPF. Unknown mobile fields are kept in the shadow.
    internal static class SyncDocument
    {
        public static readonly string[] Collections = { "entries", "columns", "accounts", "categories", "operations" };
        public static Dictionary<string, object> Object(params object[] pairs)
        {
            var result = new Dictionary<string, object>();
            for (int i = 0; i < pairs.Length; i += 2) result.Add((string)pairs[i], pairs[i + 1]);
            return result;
        }
        public static JavaScriptSerializer Json() { return new JavaScriptSerializer { MaxJsonLength = 4000000, RecursionLimit = 32 }; }
        public static Dictionary<string, object> Parse(string json) { return (Dictionary<string, object>)Json().DeserializeObject(json); }
        public static string Write(object value) { return Json().Serialize(value); }
        public static object Get(Dictionary<string, object> item, string key) { object value; return item != null && item.TryGetValue(key, out value) ? value : null; }
        public static string Text(Dictionary<string, object> item, string key) { return Get(item, key) as string; }
        public static Dictionary<string, object> Map(Dictionary<string, object> item, string key) { return Get(item, key) as Dictionary<string, object> ?? Object(); }
        public static List<Dictionary<string, object>> Items(Dictionary<string, object> document, string key)
        {
            var sequence = Get(document, key) as IEnumerable;
            return sequence == null ? new List<Dictionary<string, object>>() : sequence.Cast<object>().Select(item => (Dictionary<string, object>)item).ToList();
        }
        public static object Canonical(object value)
        {
            var map = value as Dictionary<string, object>;
            if (map != null) return new SortedDictionary<string, object>(map.ToDictionary(pair => pair.Key, pair => Canonical(pair.Value)), StringComparer.Ordinal);
            var array = value as IEnumerable;
            if (array != null && !(value is string)) return array.Cast<object>().Select(Canonical).ToArray();
            return value;
        }
        public static bool Equal(object a, object b) { return Write(Canonical(a)) == Write(Canonical(b)); }
        public static Dictionary<string, object> Clone(Dictionary<string, object> value) { return Parse(Write(value)); }
        public static Dictionary<string, object> Empty()
        {
            var result = Object("schema", 1, "settings", Object("theme", "emerald"), "deleted", Object());
            foreach (string key in Collections) result[key] = new object[0];
            return result;
        }
        private static Dictionary<string, Dictionary<string, object>> Index(Dictionary<string, object> value, string key)
        { return Items(value, key).ToDictionary(item => Text(item, "id")); }

        // Overlay only changes to native fields; reminders and other mobile-only fields survive.
        public static Dictionary<string, object> Overlay(Dictionary<string, object> shadow, Dictionary<string, object> before, Dictionary<string, object> current)
        {
            var result = Clone(shadow); var deleted = Map(result, "deleted");
            foreach (string key in Collections)
            {
                var cloud = Index(shadow, key); var old = Index(before, key); var now = Index(current, key);
                var records = cloud.ToDictionary(pair => pair.Key, pair => Clone(pair.Value));
                foreach (var pair in now)
                {
                    Dictionary<string, object> was, remote;
                    old.TryGetValue(pair.Key, out was); cloud.TryGetValue(pair.Key, out remote);
                    var item = remote == null ? Clone(pair.Value) : Clone(remote);
                    foreach (var field in pair.Value)
                        if (was == null || !Equal(Get(was, field.Key), field.Value)) item[field.Key] = field.Value;
                    records[pair.Key] = item; deleted.Remove(pair.Key);
                }
                foreach (string removed in old.Keys.Except(now.Keys)) { deleted[removed] = DateTime.UtcNow.ToString("o"); records.Remove(removed); }
                result[key] = records.Values.ToArray();
            }
            result["deleted"] = deleted;
            var settings = Map(result, "settings");
            foreach (var setting in Map(current, "settings"))
                if (!Equal(Get(Map(before, "settings"), setting.Key), setting.Value)) settings[setting.Key] = setting.Value;
            result["settings"] = settings;
            return result;
        }
        public static Dictionary<string, object> Merge(Dictionary<string, object> baseline, Dictionary<string, object> local, Dictionary<string, object> remote, List<string> conflicts, bool? preferLocal)
        {
            var result = Clone(remote);
            var deleted = Map(result, "deleted");
            var localDeleted = Map(local, "deleted"); var baseDeleted = Map(baseline, "deleted");
            foreach (string key in localDeleted.Keys.Union(baseDeleted.Keys))
                if (!Equal(Get(localDeleted, key), Get(baseDeleted, key)))
                { if (localDeleted.ContainsKey(key)) deleted[key] = localDeleted[key]; else deleted.Remove(key); }
            foreach (string key in Collections)
            {
                var b = Index(baseline, key); var l = Index(local, key); var r = Index(remote, key);
                var records = new List<object>();
                foreach (string id in b.Keys.Union(l.Keys).Union(r.Keys))
                {
                    Dictionary<string, object> bv, lv, rv;
                    b.TryGetValue(id, out bv); l.TryGetValue(id, out lv); r.TryGetValue(id, out rv);
                    bool lc = !Equal(lv, bv), rc = !Equal(rv, bv);
                    bool conflict = lc && rc && !Equal(lv, rv);
                    if (conflict) conflicts.Add(key + ":" + id);
                    var chosen = conflict && preferLocal.HasValue ? (preferLocal.Value ? lv : rv) : (lc ? lv : rv);
                    if (conflict && preferLocal.HasValue) { if (chosen == null) deleted[id] = DateTime.UtcNow.ToString("o"); else deleted.Remove(id); }
                    if (chosen != null && !deleted.ContainsKey(id)) records.Add(chosen);
                }
                result[key] = records;
            }
            var settings = Map(result, "settings");
            foreach (var setting in Map(local, "settings"))
            {
                if (Equal(setting.Value, Get(Map(baseline, "settings"), setting.Key))) continue;
                var theirs = Get(Map(remote, "settings"), setting.Key);
                bool conflict = !Equal(theirs, Get(Map(baseline, "settings"), setting.Key)) && !Equal(theirs, setting.Value);
                if (conflict) conflicts.Add("settings:" + setting.Key);
                if (!conflict || preferLocal != false) settings[setting.Key] = setting.Value;
            }
            result["settings"] = settings; result["deleted"] = deleted;
            return result;
        }
    }
}
