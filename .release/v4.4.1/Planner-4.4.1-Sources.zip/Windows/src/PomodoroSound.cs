using System;
using System.IO;
using System.Linq;
using System.Media;
using System.Windows.Media;

namespace Planner
{
    internal sealed class PomodoroPreset
    {
        internal static readonly PomodoroPreset[] All =
        {
            new PomodoroPreset("step", "Шаг вперёд", .31, 7.2, .52,
                new[] { 67, 71, 74, 79, 0, 76, 79, 81, 0, 0, 74, 76, 79, 83, 0, 81, 79, 0, 86 },
                new[] { 43, 47, 50, 57 }, new[] { 48, 52, 55, 59 }, new[] { 43, 50, 55, 57 }),
            new PomodoroPreset("rhythm", "В ритм", .31, 6.4, .82,
                new[] { 57, 0, 57, 62, 66, 0, 69, 66, 0, 0, 59, 0, 62, 66, 69, 0, 74 },
                new[] { 50, 54, 57 }, new[] { 47, 54, 57 }, new[] { 50, 57, 62 }),
            new PomodoroPreset("light", "Мягкий подъём", .39, 5.4, .28,
                new[] { 60, 64, 67, 0, 74, 0, 0, 65, 69, 72, 79 },
                new[] { 48, 55, 62 }, new[] { 53, 60, 67 })
        };

        internal readonly string Key, Title;
        internal readonly double Beat, Length, Strike;
        internal readonly int[] Melody;
        internal readonly int[][] Harmony;

        private PomodoroPreset(string key, string title, double beat, double length, double strike,
            int[] melody, params int[][] harmony)
        {
            Key = key;
            Title = title;
            Beat = beat;
            Length = length;
            Strike = strike;
            Melody = melody;
            Harmony = harmony;
        }

        internal static PomodoroPreset Resolve(string key, PomodoroPhase phase)
        {
            return All.FirstOrDefault(preset => preset.Key == key) ?? All[phase == PomodoroPhase.Focus ? 0 : 1];
        }
    }

    internal sealed class PomodoroSound : IDisposable
    {
        private const int SampleRate = 22050;
        private MediaPlayer player;
        private string waveFile;

        public void Play(PomodoroPreset preset, string customPath, double volume, Action unreadable)
        {
            Stop();
            if (volume == 0) return;
            bool custom = !String.IsNullOrEmpty(customPath);
            try
            {
                string path = customPath;
                if (!custom)
                {
                    waveFile = Path.Combine(Path.GetTempPath(), "Planner-" + Guid.NewGuid().ToString("N") + ".wav");
                    using (var wave = CreateWave(preset))
                    using (var file = File.Create(waveFile)) wave.CopyTo(file);
                    path = waveFile;
                }
                var active = new MediaPlayer { Volume = volume };
                player = active;
                active.MediaFailed += (sender, e) =>
                {
                    if (!ReferenceEquals(player, active)) return;
                    Recover(preset, custom, active.Volume, unreadable);
                };
                active.MediaEnded += (sender, e) => { if (ReferenceEquals(player, active)) Stop(); };
                active.Open(new Uri(path, UriKind.Absolute));
                active.Play();
            }
            catch (IOException) { Recover(preset, custom, volume, unreadable); }
            catch (UnauthorizedAccessException) { Recover(preset, custom, volume, unreadable); }
            catch (InvalidOperationException) { Recover(preset, custom, volume, unreadable); }
        }

        public void ChangeVolume(double volume)
        {
            if (player != null) player.Volume = volume;
        }

        private void Recover(PomodoroPreset preset, bool custom, double volume, Action unreadable)
        {
            if (custom)
            {
                Play(preset, null, volume, null);
                if (unreadable != null) unreadable();
            }
            else FallBack();
        }

        private void FallBack()
        {
            Stop();
            SystemSounds.Asterisk.Play();
        }

        public void Stop()
        {
            var active = player;
            player = null;
            if (active != null) active.Close();
            if (waveFile == null) return;
            try { File.Delete(waveFile); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
            waveFile = null;
        }

        public void Dispose() { Stop(); }

        internal static MemoryStream CreateWave(PomodoroPreset preset)
        {
            int frames = (int)Math.Round(preset.Length * SampleRate);
            var samples = new double[frames];

            for (int beat = 0; beat < preset.Melody.Length; beat++)
            {
                int note = preset.Melody[beat];
                if (note == 0) continue;
                bool final = beat == preset.Melody.Length - 1;
                RenderNote(samples, beat * preset.Beat, note, final ? 1.42 : .68,
                    beat == 0 || final ? .94 : .68, preset.Strike);
            }
            for (int chord = 0; chord < preset.Harmony.Length; chord++)
            {
                bool final = chord == preset.Harmony.Length - 1;
                int beat = final ? preset.Melody.Length - 1 : chord * 8;
                for (int voice = 0; voice < preset.Harmony[chord].Length; voice++)
                    RenderNote(samples, beat * preset.Beat + .038 * voice,
                        preset.Harmony[chord][voice], 1.65, voice == 0 ? .26 : .16, preset.Strike * .22);
            }

            // Two quiet reflections add space without blurring the start of either phrase.
            int firstEcho = (int)(SampleRate * .108), secondEcho = (int)(SampleRate * .197);
            for (int frame = frames - 1; frame >= firstEcho; frame--)
            {
                samples[frame] += samples[frame - firstEcho] * .12;
                if (frame >= secondEcho) samples[frame] += samples[frame - secondEcho] * .07;
            }

            double peak = .01;
            foreach (double sample in samples) peak = Math.Max(peak, Math.Abs(sample));
            int bytes = frames * sizeof(short);
            var stream = new MemoryStream(44 + bytes);
            using (var writer = new BinaryWriter(stream, System.Text.Encoding.ASCII, true))
            {
                writer.Write(0x46464952); // RIFF
                writer.Write(36 + bytes);
                writer.Write(0x45564157); // WAVE
                writer.Write(0x20746d66); // fmt
                writer.Write(16);
                writer.Write((short)1); // PCM
                writer.Write((short)1); // Mono
                writer.Write(SampleRate);
                writer.Write(SampleRate * sizeof(short));
                writer.Write((short)sizeof(short));
                writer.Write((short)16);
                writer.Write(0x61746164); // data
                writer.Write(bytes);
                for (int frame = 0; frame < frames; frame++)
                {
                    double fade = Math.Min(1, (frames - 1 - frame) / (SampleRate * .17));
                    writer.Write((short)(samples[frame] / peak * short.MaxValue * .84 * fade));
                }
            }
            stream.Position = 0;
            return stream;
        }

        private static void RenderNote(double[] buffer, double timeStart, int note, double length,
            double volume, double strike)
        {
            int start = (int)(timeStart * SampleRate);
            double frequency = 440 * Math.Pow(2, (note - 69) / 12.0);
            int frames = Math.Min(buffer.Length - start, (int)(SampleRate * length));
            for (int i = 0; i < frames; i++)
            {
                double time = (double)i / SampleRate;
                double envelope = Math.Min(1, time / (.021 - strike * .015)) *
                    Math.Min(1, (length - time) / .12) * Math.Exp(-time * (2.75 + strike));
                double angle = 2 * Math.PI * frequency * time;
                double tone = Math.Sin(angle) + .21 * Math.Sin(angle * 2.003) * Math.Exp(-time * 4)
                    + (.07 + strike * .24) * Math.Sin(angle * 3.99) * Math.Exp(-time * 14)
                    + .045 * Math.Sin(angle * 6.02) * Math.Exp(-time * 24);
                buffer[start + i] += tone * envelope * volume;
            }
        }
    }
}
