#if PLANNER_TESTS
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace Planner
{
    internal static class CloudflarePublisherTest
    {
        private static List<string> checks = new List<string>();
        private static void Check(bool value, string message) { if (!value) throw new InvalidOperationException(message); checks.Add("PASS " + message); }
        public static int Run(string folder)
        {
            Directory.CreateDirectory(folder);
            try { RunAsync(folder).GetAwaiter().GetResult(); File.WriteAllLines(Path.Combine(folder, "publisher-test.txt"), checks); return 0; }
            catch (Exception error) { File.WriteAllText(Path.Combine(folder, "publisher-test.txt"), error.ToString()); return 1; }
        }
        private static async Task RunAsync(string folder)
        {
            Check(CloudflarePublisher.Challenge("dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk") == "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM", "PKCE соответствует независимому вектору RFC 7636");
            var transport = new FakeCloud();
            Func<byte[], byte[]> cipher = bytes => bytes.Select(value => (byte)(value ^ 0x59)).ToArray();
            string secret, owner;
            using (var publisher = new CloudflarePublisher(folder, transport, cipher, cipher))
            {
                Task browser = null;
                publisher.OpenAuthorizationPage = url => {
                    var parameters = HttpUtility.ParseQueryString(new Uri(url).Query);
                    transport.ExpectedChallenge = parameters["code_challenge"];
                    browser = Task.Run(async () => {
                        using (var client = new HttpClient(new HttpClientHandler { AllowAutoRedirect = false }))
                        {
                            var invalid = await client.GetAsync("http://localhost:8976/oauth/callback?state=wrong&code=test");
                            Check(invalid.StatusCode == HttpStatusCode.BadRequest, "Неправильный OAuth state отвергается локальным обработчиком");
                            var valid = await client.GetAsync("http://localhost:8976/oauth/callback?state=" + parameters["state"] + "&code=authorization-test");
                            Check(valid.IsSuccessStatusCode, "Подтверждение браузера принимается локальным обработчиком");
                        }
                    });
                };
                await publisher.AuthorizeAsync(); await browser;
                string code = await publisher.PublishAsync(); secret = publisher.ReadRecoveryKey(); owner = transport.Owner;
                Check(code.Length == 43 && publisher.Origin.StartsWith("https://mikhail-planner."), "Публикация возвращает адрес и код автоматического подключения Windows");
                Check(transport.SchemaCount == 2, "Обе версии схемы базы применены без удаления данных");
                Check(transport.CreatedSubdomain, "Новый аккаунт с ошибкой 10007 получает адрес автоматически");
                Check(transport.MetadataMain && transport.ModuleCount == 7, "Пакет содержит независимый сервер и все его модули");
                Check(!transport.Upload.Contains(secret) && transport.StoredHash == CloudflarePublisher.Challenge(secret), "В публичных файлах нет ключа доступа; в сервер передан только хеш");
                Check(transport.Cron == "* * * * *", "Планировщик уведомлений публикуется с минутным расписанием");
                Check(File.Exists(publisher.RecoveryFile) && File.ReadAllText(publisher.RecoveryFile).Contains(secret), "Файл восстановления сохранён на компьютере владельца");
                Check(!File.ReadAllText(Path.Combine(folder, "owner.dat")).Contains(secret), "Локальная конфигурация проходит через защиту секретов");
            }
            using (var retry = new CloudflarePublisher(folder, transport, cipher, cipher))
            {
                retry.OpenAuthorizationPage = url => { throw new InvalidOperationException("Повторный вход не требуется"); };
                await retry.AuthorizeAsync(); await retry.PublishAsync();
                Check(transport.RefreshCount == 1, "Повторная публикация обновляет защищённый сеанс без нового входа в браузере");
                Check(transport.Owner == owner && retry.ReadRecoveryKey() == secret, "Повторная публикация сохраняет владельца и ключ");
                Check(transport.DatabaseCreates == 1 && transport.SubdomainCreates == 1, "Повторный запуск использует существующий сервер и базу");
            }
            Check(!Directory.GetFiles(folder).Any(file => File.ReadAllText(file).Contains("fake-cloudflare-credential")), "Краткоживущий токен Cloudflare не сохраняется на диске");
            // Transport records only stubbed requests; no external network is used by this test.
            Check(transport.StateWrites == 0, "Развёртывание не очищает и не заменяет документ с записями");
        }
        private sealed class FakeCloud : HttpMessageHandler
        {
            public string Owner, Upload, StoredHash, Cron;
            public string ExpectedChallenge;
            public int RefreshCount;
            public int SchemaCount, ModuleCount, DatabaseCreates, SubdomainCreates, StateWrites;
            public bool CreatedSubdomain, MetadataMain, published;
            protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellation)
            {
                string path = request.RequestUri.AbsolutePath, method = request.Method.Method;
                string body = request.Content == null ? "" : await request.Content.ReadAsStringAsync();
                object result = SyncDocument.Object();
                if (request.RequestUri.Host == "dash.cloudflare.com" && path == "/oauth2/token")
                {
                    var parameters = HttpUtility.ParseQueryString(body);
                    Check(request.Headers.Authorization == null, "OAuth использует публичный клиент без сохранённого секрета");
                    if (parameters["grant_type"] == "authorization_code")
                        Check(parameters["code"] == "authorization-test" && CloudflarePublisher.Challenge(parameters["code_verifier"]) == ExpectedChallenge, "Код браузера обменивается с тем же PKCE verifier");
                    else { Check(parameters["grant_type"] == "refresh_token" && parameters["refresh_token"] == "fake-refresh-credential", "Обновление сеанса использует защищённый refresh token"); RefreshCount++; }
                    return Reply(SyncDocument.Object("access_token", "fake-cloudflare-credential", "refresh_token", "fake-refresh-credential"));
                }
                if (request.RequestUri.Host == "api.cloudflare.com")
                {
                    Check(request.Headers.Authorization != null && request.Headers.Authorization.Parameter == "fake-cloudflare-credential", "Служебный запрос авторизован только на Cloudflare API");
                    if (path.EndsWith("/accounts")) result = new[] { SyncDocument.Object("id", "account123456", "name", "Тест") };
                    else if (path.EndsWith("/workers/scripts") && method == "GET") result = published ? new[] { SyncDocument.Object("id", "mikhail-planner") } : new object[0];
                    else if (path.EndsWith("/settings")) result = SyncDocument.Object("bindings", new[] { SyncDocument.Object("name", "OWNER_ID", "text", Owner) });
                    else if (path.EndsWith("/d1/database") && method == "GET") result = DatabaseCreates > 0 ? new[] { SyncDocument.Object("name", "planner-data", "uuid", "database123") } : new object[0];
                    else if (path.EndsWith("/d1/database") && method == "POST") { DatabaseCreates++; result = SyncDocument.Object("uuid", "database123"); }
                    else if (path.EndsWith("/query"))
                    {
                        SchemaCount++; Check(body.Contains("IF NOT EXISTS") && !body.Contains("DROP TABLE"), "Миграция повторяемая и не удаляет таблицы");
                        result = new[] { SyncDocument.Object("success", true) };
                    }
                    else if (path.EndsWith("/workers/subdomain") && method == "GET")
                    {
                        if (!CreatedSubdomain) return Reply(SyncDocument.Object("success", false, "errors", new[] { SyncDocument.Object("code", 10007, "message", "No subdomain") }), 404);
                        result = SyncDocument.Object("subdomain", "mikhail-planner-account");
                    }
                    else if (path.EndsWith("/workers/subdomain") && method == "PUT") { CreatedSubdomain = true; SubdomainCreates++; }
                    else if (path.EndsWith("/scripts/mikhail-planner") && method == "PUT")
                    {
                        Upload = body; published = true;
                        Owner = Regex.Match(body, "\\\"name\\\":\\\"OWNER_ID\\\",\\\"text\\\":\\\"([^\\\"]+)\\\"").Groups[1].Value;
                        MetadataMain = body.Contains("\"main_module\":\"independent.js\"");
                        ModuleCount = Regex.Matches(body, "filename=\"?[a-z]+\\.js\"?").Count;
                    }
                    else if (path.EndsWith("/secrets")) StoredHash = SyncDocument.Text(SyncDocument.Parse(body), "text");
                    else if (path.EndsWith("/schedules")) Cron = SyncDocument.Text(((object[])SyncDocument.Json().DeserializeObject(body)).Select(item => (Dictionary<string, object>)item).First(), "cron");
                    return Reply(SyncDocument.Object("success", true, "result", result));
                }
                Check(request.Headers.Authorization == null, "Секрет Cloudflare не отправляется в опубликованный планер");
                if (path == "/api/auth/login") return Reply(SyncDocument.Object("user", Owner));
                if (path == "/api/auth/pair") return Reply(SyncDocument.Object("code", new String('p', 43)));
                if (path == "/api/state" && method != "GET") StateWrites++;
                throw new InvalidOperationException("Unexpected test request " + path);
            }
            private static HttpResponseMessage Reply(object value, int status = 200)
            { return new HttpResponseMessage((HttpStatusCode)status) { Content = new StringContent(SyncDocument.Write(value), Encoding.UTF8, "application/json") }; }
            protected override void Dispose(bool disposing) { /* The same in-memory cloud is used for retry checks. */ }
        }
    }
}
#endif
