using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;

namespace Planner
{
    internal sealed partial class MainWindow
    {
        private Popup financeCalculator;
        private static string FinanceKindName(FinanceKind kind)
        {
            return kind == FinanceKind.Income ? "Доход" : kind == FinanceKind.Expense ? "Расход" : "Перевод";
        }

        private static string FinanceChoice(ComboBox picker)
        {
            var selected = picker.SelectedItem as ComboBoxItem;
            return selected == null ? null : selected.Tag as string;
        }

        private ComboBox FinancePicker(string id, IEnumerable<KeyValuePair<string, string>> options, string selected)
        {
            var picker = SelectList(id);
            foreach (var option in options)
            {
                var item = new ComboBoxItem { Content = option.Value, Tag = option.Key };
                Identify(item, id + "-" + option.Key);
                picker.Items.Add(item);
                if (option.Key == selected) picker.SelectedItem = item;
            }
            return picker;
        }

        private void FinancePickerLabel(StackPanel panel, string caption, ComboBox picker, Action create, string id)
        {
            var row = new DockPanel { Margin = new Thickness(0, 0, 0, 5) };
            var add = Link("+ Создать", create, id);
            DockPanel.SetDock(add, Dock.Right);
            row.Children.Add(add);
            row.Children.Add(Text(caption, 12, Muted, true));
            panel.Children.Add(row);
            picker.Margin = new Thickness(0, 0, 0, 13);
            panel.Children.Add(picker);
        }

        private void FinanceButtons(StackPanel panel, Action save, Action cancel, Action remove = null)
        {
            var row = new WrapPanel { Margin = new Thickness(0, 13, 0, 0) };
            row.Children.Add(Button("Сохранить", save, "finance-save", "primary"));
            var back = Button("Отмена", cancel, "finance-cancel");
            back.Margin = new Thickness(7, 0, 0, 0);
            row.Children.Add(back);
            if (remove != null)
            {
                var delete = Button("Удалить", remove, "finance-delete");
                delete.Foreground = FinanceExpense;
                delete.Margin = new Thickness(7, 0, 0, 0);
                row.Children.Add(delete);
            }
            panel.Children.Add(row);
        }

        private Action FinanceValidatedSave(StackPanel panel, Action save)
        {
            var error = Text("", 12, FinanceExpense);
            error.Visibility = Visibility.Collapsed;
            Identify(error, "finance-error");
            panel.Children.Add(error);
            return () =>
            {
                try { save(); }
                catch (ArgumentException failure)
                {
                    error.Text = failure.Message;
                    error.Visibility = Visibility.Visible;
                    var scroll = FindControl(drawer, "drawer-scroll") as ScrollViewer;
                    if (scroll != null) scroll.ScrollToBottom();
                }
            };
        }

        private void ShowFinanceOperation(FinanceOperation operation, string amountText = null, string dateText = null)
        {
            var draft = operation.Copy();
            bool editing = finance.Operations.Any(item => item.Id == draft.Id);
            var body = new StackPanel();
            var date = PickDate(draft.Day, null, "finance-date");
            if (dateText != null) date.Input.Text = dateText;
            var amount = Input("finance-amount", amountText ?? (draft.Amount == 0 ? "" : Money.Input(draft.Amount)));
            var notes = Input("finance-notes", draft.Notes, true);
            var category = FinancePicker("finance-category", finance.Categories.Where(item => item.Kind == draft.Kind &&
                (!item.Archived || editing && item.Id == operation.CategoryId)).Select(item =>
                    new KeyValuePair<string, string>(item.Id, item.Name)), draft.CategoryId);
            var account = FinancePicker("finance-account", finance.Accounts.Where(item => !item.Archived ||
                editing && item.Id == operation.AccountId).Select(item => new KeyValuePair<string, string>(item.Id, item.Name)), draft.AccountId);
            var destination = FinancePicker("finance-destination", finance.Accounts.Where(item => !item.Archived ||
                editing && item.Id == operation.DestinationId).Select(item => new KeyValuePair<string, string>(item.Id, item.Name)), draft.DestinationId);
            Action capture = () =>
            {
                if (date.Value.HasValue) draft.Day = date.Value.Value;
                long parsed;
                try { parsed = Money.Parse(amount.Text, false); draft.Amount = parsed; }
                catch (ArgumentException) { }
                draft.AccountId = FinanceChoice(account);
                draft.DestinationId = FinanceChoice(destination);
                draft.CategoryId = FinanceChoice(category);
                draft.Notes = notes.Text;
            };
            var kinds = new Grid { Margin = new Thickness(0, 0, 0, 15) };
            foreach (FinanceKind kind in Enum.GetValues(typeof(FinanceKind)))
            {
                FinanceKind choice = kind;
                kinds.ColumnDefinitions.Add(new ColumnDefinition());
                var button = Button(FinanceKindName(kind), () =>
                {
                    capture();
                    draft.Kind = choice;
                    draft.CategoryId = null;
                    ShowFinanceOperation(draft, amount.Text, date.Input.Text);
                }, "finance-kind-" + kind, draft.Kind == kind ? "selected" : "plain");
                Grid.SetColumn(button, (int)kind);
                kinds.Children.Add(button);
            }
            body.Children.Add(kinds);
            FormLabel(body, "Дата", date);
            var amountRow = new DockPanel { LastChildFill = true };
            var calculate = IconButton("\uE8EF", "Калькулятор", () => OpenMoneyCalculator(amount), "finance-calculator");
            calculate.Margin = new Thickness(6, 0, 0, 0);
            DockPanel.SetDock(calculate, Dock.Right);
            amountRow.Children.Add(calculate);
            amountRow.Children.Add(amount);
            body.Children.Add(Text("Сумма, ₽", 12, Muted, true));
            amountRow.Margin = new Thickness(0, 5, 0, 13);
            body.Children.Add(amountRow);
            // Keyboard entry remains available while the calculator is opened by pointer.
            amount.PreviewMouseLeftButtonUp += (sender, e) =>
            {
                if (!amount.IsKeyboardFocusWithin || amount.SelectionLength == 0) OpenMoneyCalculator(amount);
            };
            if (draft.Kind != FinanceKind.Transfer)
                FinancePickerLabel(body, "Категория", category, () =>
                {
                    capture();
                    ShowFinanceCategory(new FinanceCategory { Kind = draft.Kind }, saved =>
                    {
                        if (saved != null) draft.CategoryId = saved.Id;
                        ShowFinanceOperation(draft, amount.Text, date.Input.Text);
                    });
                }, "finance-new-category");
            FinancePickerLabel(body, draft.Kind == FinanceKind.Transfer ? "Со счёта" : "Счёт", account, () =>
            {
                capture();
                ShowFinanceAccount(new FinanceAccount(), saved =>
                {
                    if (saved != null) draft.AccountId = saved.Id;
                    ShowFinanceOperation(draft, amount.Text, date.Input.Text);
                });
            }, "finance-new-account");
            if (draft.Kind == FinanceKind.Transfer)
                FinancePickerLabel(body, "На счёт", destination, () =>
                {
                    capture();
                    ShowFinanceAccount(new FinanceAccount(), saved =>
                    {
                        if (saved != null) draft.DestinationId = saved.Id;
                        ShowFinanceOperation(draft, amount.Text, date.Input.Text);
                    });
                }, "finance-new-destination");
            FormLabel(body, "Заметки", notes);
            Action save = () =>
            {
                capture();
                if (!date.Value.HasValue) throw new ArgumentException("Укажите дату операции.");
                draft.Amount = Money.Parse(amount.Text, false);
                finance.Save(draft);
                CloseDrawer(false);
                Refresh();
            };
            Action remove = () =>
            {
                Action undo = finance.DeleteOperation(draft.Id);
                CloseDrawer(false);
                Refresh();
                Notice("Операция удалена", "Отменить", () => { undo(); Refresh(); noticeHost.Children.Clear(); });
            };
            save = FinanceValidatedSave(body, save);
            FinanceButtons(body, save, () => CloseDrawer(), editing ? remove : (Action)null);
            OpenDrawer(editing ? "Операция" : "Новая операция", body, null, save);
            Dispatcher.BeginInvoke(new Action(() => amount.Focus()));
        }

        private void OpenMoneyCalculator(TextBox target)
        {
            if (financeCalculator != null) financeCalculator.IsOpen = false;
            var popup = new Popup { PlacementTarget = target, Placement = PlacementMode.Bottom,
                StaysOpen = false, AllowsTransparency = true, VerticalOffset = 5 };
            financeCalculator = popup;
            popup.Closed += (sender, e) => { if (financeCalculator == popup) financeCalculator = null; };
            var panel = new StackPanel();
            var expression = Input("finance-calc-expression", target.Text.Replace("\u00a0", ""));
            expression.MaxLength = 220;
            expression.FontSize = 22;
            expression.HorizontalContentAlignment = HorizontalAlignment.Right;
            panel.Children.Add(expression);
            var error = Text("", 12, FinanceExpense);
            error.Visibility = Visibility.Collapsed;
            panel.Children.Add(error);
            Action evaluate = () =>
            {
                try { expression.Text = MoneyCalculator.Evaluate(expression.Text); error.Visibility = Visibility.Collapsed; }
                catch (ArgumentException failure) { error.Text = failure.Message; error.Visibility = Visibility.Visible; }
            };
            Action apply = () =>
            {
                try
                {
                    string result = MoneyCalculator.Evaluate(expression.Text);
                    target.Text = result;
                    popup.IsOpen = false;
                    target.Focus();
                    target.CaretIndex = target.Text.Length;
                }
                catch (ArgumentException failure) { error.Text = failure.Message; error.Visibility = Visibility.Visible; }
            };
            string[] keys = { "+", "−", "×", "÷", "7", "8", "9", "⌫", "4", "5", "6", "C", "1", "2", "3", "=", "0", ",", "Закрыть", "Готово" };
            var keypad = new UniformGrid { Columns = 4, Margin = new Thickness(0, 8, 0, 0) };
            foreach (string label in keys)
            {
                string key = label;
                var button = Button(label, () =>
                {
                    switch (key)
                    {
                        case "Готово": apply(); return;
                        case "Закрыть": popup.IsOpen = false; return;
                        case "=": evaluate(); break;
                        case "C": expression.Clear(); break;
                        case "⌫":
                            if (expression.SelectionLength > 0) expression.SelectedText = "";
                            else if (expression.CaretIndex > 0)
                            {
                                int position = expression.CaretIndex;
                                expression.Text = expression.Text.Remove(position - 1, 1);
                                expression.CaretIndex = position - 1;
                            }
                            break;
                        default:
                            int caret = expression.SelectionStart;
                            string inserted = key == "−" ? "-" : key;
                            expression.SelectedText = inserted;
                            expression.CaretIndex = caret + inserted.Length;
                            break;
                    }
                    expression.Focus();
                }, "finance-calc-" + label, label == "Готово" ? "primary" : "plain");
                button.MinHeight = 43;
                button.Padding = new Thickness(2);
                button.FontSize = label.Length > 2 ? 11 : 18;
                keypad.Children.Add(button);
            }
            panel.Children.Add(keypad);
            var frame = DashboardCard(panel);
            frame.Width = 330;
            frame.BorderBrush = Line;
            popup.Child = frame;
            expression.PreviewKeyDown += (sender, e) =>
            {
                if (e.Key == Key.Enter) { apply(); e.Handled = true; }
                if (e.Key == Key.Escape) { popup.IsOpen = false; e.Handled = true; }
            };
            popup.IsOpen = true;
            expression.Focus();
            expression.CaretIndex = expression.Text.Length;
        }

        private void ShowFinanceAccount(FinanceAccount account, Action<FinanceAccount> finished = null)
        {
            var draft = account.Copy();
            var panel = new StackPanel();
            var name = Input("finance-account-name", draft.Name);
            var opening = Input("finance-account-opening", Money.Input(draft.Opening));
            FormLabel(panel, "Название", name);
            FormLabel(panel, "Начальный остаток, ₽", opening);
            opening.ToolTip = "Задолженность укажите со знаком минус";
            Action cancel = () => { if (finished != null) finished(null); else ShowFinanceAccounts(); };
            Action save = () =>
            {
                draft.Name = name.Text;
                draft.Opening = Money.Parse(opening.Text, true);
                finance.Save(draft);
                Refresh();
                if (finished != null) finished(draft); else ShowFinanceAccounts();
            };
            save = FinanceValidatedSave(panel, save);
            FinanceButtons(panel, save, cancel);
            OpenDrawer(finance.Accounts.Any(item => item.Id == draft.Id) ? "Счёт" : "Новый счёт", panel, null, save);
            name.Focus();
        }

        private void ShowFinanceCategory(FinanceCategory category, Action<FinanceCategory> finished = null)
        {
            var draft = category.Copy();
            var panel = new StackPanel();
            var name = Input("finance-category-name", draft.Name);
            var type = SelectList("finance-category-kind");
            foreach (FinanceKind kind in new[] { FinanceKind.Income, FinanceKind.Expense })
                type.Items.Add(new ComboBoxItem { Content = FinanceKindName(kind), Tag = kind, IsSelected = draft.Kind == kind });
            type.IsEnabled = finished == null && !finance.CategoryUsed(draft.Id);
            FormLabel(panel, "Название", name);
            FormLabel(panel, "Тип", type);
            Action cancel = () => { if (finished != null) finished(null); else ShowFinanceCategories(); };
            Action save = () =>
            {
                draft.Name = name.Text;
                draft.Kind = (FinanceKind)((ComboBoxItem)type.SelectedItem).Tag;
                finance.Save(draft);
                Refresh();
                if (finished != null) finished(draft); else ShowFinanceCategories();
            };
            save = FinanceValidatedSave(panel, save);
            FinanceButtons(panel, save, cancel);
            OpenDrawer(finance.Categories.Any(item => item.Id == draft.Id) ? "Категория" : "Новая категория", panel, null, save);
            name.Focus();
        }

        private void ShowFinanceAccounts()
        {
            var body = new StackPanel();
            body.Children.Add(Button("+ Создать счёт", () => ShowFinanceAccount(new FinanceAccount()), "finance-add-account", "primary"));
            body.Children.Add(Gap(12));
            foreach (var account in finance.Accounts)
            {
                var current = account;
                var row = new StackPanel { Margin = new Thickness(0, 5, 0, 12) };
                row.Children.Add(Text(account.Name + (account.Archived ? " · архив" : ""), 15, TextInk, true));
                row.Children.Add(Text(Money.Format(finance.Balance(account)), 14, Muted));
                var actions = new WrapPanel();
                actions.Children.Add(Link("Изменить", () => ShowFinanceAccount(current.Copy()), "finance-edit-account-" + account.Id));
                if (account.Archived)
                    actions.Children.Add(Link("Вернуть", () =>
                    {
                        var restored = current.Copy(); restored.Archived = false; finance.Save(restored); Refresh(); ShowFinanceAccounts();
                    }, "finance-restore-account-" + account.Id));
                else
                    actions.Children.Add(Link(finance.AccountUsed(account.Id) ? "В архив" : "Удалить", () =>
                    {
                        Action undo = finance.RemoveAccount(current.Id);
                        Refresh(); ShowFinanceAccounts();
                        Notice("Счёт убран", "Отменить", () => { undo(); Refresh(); ShowFinanceAccounts(); noticeHost.Children.Clear(); });
                    }, "finance-remove-account-" + account.Id));
                row.Children.Add(actions);
                body.Children.Add(row);
            }
            OpenDrawer("Счета", body);
        }

        private void ShowFinanceCategories()
        {
            var body = new StackPanel();
            body.Children.Add(Button("+ Создать категорию", () => ShowFinanceCategory(new FinanceCategory()), "finance-add-category", "primary"));
            body.Children.Add(Gap(12));
            foreach (FinanceKind kind in new[] { FinanceKind.Income, FinanceKind.Expense })
            {
                body.Children.Add(Text(kind == FinanceKind.Income ? "Доходы" : "Расходы", 14, Muted, true));
                foreach (var category in finance.Categories.Where(item => item.Kind == kind))
                {
                    var current = category;
                    var row = new StackPanel { Margin = new Thickness(0, 8, 0, 12) };
                    row.Children.Add(Text(category.Name + (category.Archived ? " · архив" : ""), 15, TextInk, true));
                    var actions = new WrapPanel();
                    actions.Children.Add(Link("Изменить", () => ShowFinanceCategory(current.Copy()), "finance-edit-category-" + category.Id));
                    if (category.Archived)
                        actions.Children.Add(Link("Вернуть", () =>
                        {
                            var restored = current.Copy(); restored.Archived = false; finance.Save(restored); Refresh(); ShowFinanceCategories();
                        }, "finance-restore-category-" + category.Id));
                    else
                        actions.Children.Add(Link(finance.CategoryUsed(category.Id) ? "В архив" : "Удалить", () =>
                        {
                            Action undo = finance.RemoveCategory(current.Id);
                            Refresh(); ShowFinanceCategories();
                            Notice("Категория убрана", "Отменить", () => { undo(); Refresh(); ShowFinanceCategories(); noticeHost.Children.Clear(); });
                        }, "finance-remove-category-" + category.Id));
                    row.Children.Add(actions);
                    body.Children.Add(row);
                }
                body.Children.Add(Gap(9));
            }
            OpenDrawer("Категории", body);
        }
    }
}
