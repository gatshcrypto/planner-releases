using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace Planner
{
    internal sealed class LaunchQuote
    {
        public readonly string Id, Author, Location, Words;

        public LaunchQuote(string id, string author, string location, string words)
        {
            Id = id;
            Author = author;
            Location = location;
            Words = words;
        }

        public static List<LaunchQuote> ReadAll()
        {
            using (var stream = typeof(LaunchQuote).Assembly.GetManifestResourceStream("Planner.Quotes"))
            using (var reader = new StreamReader(stream))
            {
                var entries = new List<LaunchQuote>();
                string author = "", work = "", group = "";
                for (string line = reader.ReadLine(); line != null; line = reader.ReadLine())
                {
                    if (String.IsNullOrWhiteSpace(line)) continue;
                    var fields = line.Split(new[] { '|' }, 3);
                    if (fields.Length != 3) continue;
                    if (fields[0].StartsWith("@", StringComparison.Ordinal))
                    {
                        group = fields[0].Substring(1);
                        author = fields[1];
                        work = fields[2];
                    }
                    else if (group.Length > 0)
                    {
                        entries.Add(new LaunchQuote(group + "-" + fields[0], author,
                            work + (fields[1].Length == 0 ? "" : " · " + fields[1]), fields[2]));
                    }
                }
                return entries;
            }
        }

        public static LaunchQuote Draw(IList<LaunchQuote> quotes, Store store, Random random)
        {
            if (quotes.Count == 0) return null;
            var seen = new HashSet<string>(store.Setting("launch-quotes-used", "").Split(','));
            string last = store.Setting("launch-quote-last", "");
            var choices = quotes.Where(quote => !seen.Contains(quote.Id)).ToList();
            if (choices.Count == 0)
            {
                seen.Clear();
                choices = quotes.Where(quote => quote.Id != last || quotes.Count == 1).ToList();
            }
            var prior = quotes.FirstOrDefault(quote => quote.Id == last);
            if (prior != null)
            {
                var variety = choices.Where(quote => quote.Author != prior.Author).ToList();
                if (variety.Count > 0) choices = variety;
            }
            LaunchQuote next = choices[random.Next(choices.Count)];
            seen.Remove("");
            seen.Add(next.Id);
            store.Atomic(() =>
            {
                store.SetSetting("launch-quotes-used", String.Join(",", seen));
                store.SetSetting("launch-quote-last", next.Id);
            });
            return next;
        }
    }

    internal sealed partial class MainWindow
    {
        private DispatcherTimer quoteTimer;
        private const int QuoteDelayMilliseconds = 3000;

        internal void ShowLaunchQuote()
        {
            LaunchQuote quote = LaunchQuote.Draw(LaunchQuote.ReadAll(), store, new Random());
            if (quote == null) return;
            var screen = new Grid { Background = Paper };
            Identify(screen, "launch-quote");
            var composition = new StackPanel
            {
                MaxWidth = 830, Margin = new Thickness(42, 24, 42, 72),
                HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center
            };
            var words = Display("«" + quote.Words + "»", 40);
            words.TextAlignment = TextAlignment.Center;
            words.FontSize = quote.Words.Length > 160 ? 34 : 40;
            words.LineHeight = words.FontSize * 1.27;
            words.LineStackingStrategy = LineStackingStrategy.BlockLineHeight;
            Identify(words, "launch-quote-text");
            composition.Children.Add(words);
            var author = Text(quote.Author, 17, accent, true);
            author.TextAlignment = TextAlignment.Center;
            author.Margin = new Thickness(0, 23, 0, 0);
            author.ToolTip = quote.Location;
            Identify(author, "launch-quote-author");
            composition.Children.Add(author);
            screen.Children.Add(composition);

            var proceed = Button("Продолжить   →", () =>
            {
                StopQuoteIntro();
                Content = shell;
                Refresh(false);
                var day = FindControl(shell, "nav-Day") as Button;
                if (day != null) day.Focus();
            }, "launch-continue", "primary");
            proceed.Visibility = Visibility.Collapsed;
            proceed.HorizontalAlignment = HorizontalAlignment.Right;
            proceed.VerticalAlignment = VerticalAlignment.Bottom;
            proceed.Margin = new Thickness(24, 18, 31, 28);
            proceed.MinWidth = 200;
            proceed.MinHeight = 53;
            proceed.FontSize = 16;
            screen.Children.Add(proceed);

            quoteTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(QuoteDelayMilliseconds) };
            quoteTimer.Tick += (sender, args) =>
            {
                StopQuoteIntro();
                proceed.Visibility = Visibility.Visible;
                if (SystemParameters.ClientAreaAnimation) FadeQuote(proceed, 300, 7);
                proceed.Focus();
            };
            screen.Loaded += (sender, args) =>
            {
                if (quoteTimer == null || !ReferenceEquals(Content, screen)) return;
                if (SystemParameters.ClientAreaAnimation) FadeQuote(composition, 620, 10);
                quoteTimer.Start();
            };
            Content = screen;
        }

        private void StopQuoteIntro()
        {
            if (quoteTimer == null) return;
            quoteTimer.Stop();
            quoteTimer = null;
        }

        private void FadeQuote(UIElement element, int millis, double distance)
        {
            var offset = new TranslateTransform();
            element.RenderTransform = offset;
            var easing = new CubicEase { EasingMode = EasingMode.EaseOut };
            offset.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(distance, 0, TimeSpan.FromMilliseconds(millis))
                { EasingFunction = easing });
            element.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(millis))
                { EasingFunction = easing });
        }
    }
}
