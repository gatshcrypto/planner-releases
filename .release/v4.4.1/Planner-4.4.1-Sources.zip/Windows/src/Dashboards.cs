﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Planner
{
    internal sealed partial class MainWindow
    {
        private Brush SoftWhite { get { return Blend("#FFFFFF", currentStyle.Light, .48); } }
        private static readonly Brush HeroTrack = Ink("#35FFFFFF");
        private Brush HeroAccent { get { return Ink(currentStyle.Light); } }

        private Border DayDashboard(IList<Entry> tasks, DateTime progressDate)
        {
            Progress result = planner.Count(planner.Tasks(CalendarRules.Range(Period.Day, progressDate)));
            var main = new StackPanel { Margin = new Thickness(10, 4, 0, 4), HorizontalAlignment = HorizontalAlignment.Left,
                VerticalAlignment = VerticalAlignment.Center };
            var caption = Display(progressDate == planner.Today ? "Задачи на сегодня" : "Задачи на " + progressDate.ToString("dd.MM"), 24);
            caption.Foreground = White;
            caption.Margin = new Thickness(0, 0, 0, 8);
            main.Children.Add(caption);
            var ring = Ring(result, 124, true, "day-progress");
            ring.HorizontalAlignment = HorizontalAlignment.Left;
            main.Children.Add(ring);

            var today = new StackPanel();
            var pending = tasks.Where(task => !task.Checked).ToList();
            var next = Order(pending.Where(task => task.Day.HasValue &&
                (task.Day > planner.Today || task.Day == planner.Today &&
                (!task.Time.HasValue || task.Time >= planner.Now.TimeOfDay)))).FirstOrDefault()
                ?? Order(pending).FirstOrDefault();
            Head(today, "Ближайшее дело");
            if (next != null)
            {
                if (next.Time.HasValue)
                {
                    var time = Display(next.Time.Value.ToString(@"hh\:mm"), 32);
                    time.Foreground = accent;
                    today.Children.Add(time);
                }
                var link = Link(next.Title, () => ShowDetails(next.Id), "next-timed-task");
                link.FontSize = 15;
                link.Padding = new Thickness(0, 2, 5, 2);
                link.ToolTip = next.Title;
                today.Children.Add(link);
            }
            else today.Children.Add(Text("—", 24, Muted));
            today.Children.Add(Rule());
            int work = pending.Sum(task => task.DurationMinutes ?? 0);
            bool hasKnown = pending.Any(task => task.DurationMinutes.HasValue);
            var load = Text(hasKnown ? FormatLoad(work) : pending.Count == 0 ? FormatLoad(0) : "—", 17, accent, true);
            Identify(load, "remaining-work");
            today.Children.Add(Text("Осталось по оценке", 12, Muted));
            today.Children.Add(load);
            return Pair(IllustratedDay(main), DashboardCard(today), 2.3);
        }

        private string FormatLoad(int minutes)
        {
            if (minutes < 60) return minutes + " мин";
            return (minutes / 60) + " ч" + (minutes % 60 == 0 ? "" : " " + (minutes % 60) + " мин");
        }

        private Border WeekDashboard(DateRange week, IList<Entry> tasks)
        {
            var main = new StackPanel();
            main.Children.Add(ChartHeading("Выполнение по дням", planner.Count(tasks), "period-task-progress"));
            var days = Enumerable.Range(0, 7).Select(offset => week.Start.AddDays(offset)).ToArray();
            main.Children.Add(PercentBars(days.Select(date =>
            {
                string label = CalendarRules.Capital(date.ToString("ddd", CalendarRules.Russian)).TrimEnd('.');
                var dayTasks = tasks.Where(task => task.Day == date).ToList();
                string amount = dayTasks.Any(task => task.DurationMinutes.HasValue) ?
                    FormatLoad(dayTasks.Sum(task => task.DurationMinutes ?? 0)) : null;
                return new ChartDatum(label, planner.Count(dayTasks), () => OpenDay(date), auxiliary: amount);
            }).ToList(), 78, false));

            var right = new StackPanel();
            Head(right, "Цели недели");
            var goals = planner.Goals(Period.Week, week.Start).ToList();
            right.Children.Add(DarkMetric(planner.Count(goals), "week-goal-progress"));
            var unfinished = Order(goals).FirstOrDefault(goal => !planner.Measure(goal).Complete);
            if (unfinished != null)
            {
                var link = Link(unfinished.Title, () => ShowDetails(unfinished.Id), "week-focused-goal");
                link.Foreground = accent;
                right.Children.Add(link);
            }
            return Pair(DashboardCard(main), DashboardCard(right), 2.2);
        }

        private Border MonthDashboard(DateRange range, IList<Entry> tasks, IList<Entry> goals, IList<Entry> steps)
        {
            var main = new StackPanel();
            main.Children.Add(ChartHeading("Динамика месяца", planner.Count(tasks), "period-task-progress"));
            main.Children.Add(ActivityTrend(MonthWeeks(range, tasks), false));
            var right = new StackPanel();
            Head(right, "Цели и подцели");
            AddProgressRow(right, "Цели месяца", planner.Count(goals), "period-goal-progress");
            AddProgressRow(right, "Подцели по сроку", planner.Count(steps), "month-subgoal-progress");
            return Pair(DashboardCard(main), DashboardCard(right), 1.8);
        }

        private IList<ChartDatum> MonthWeeks(DateRange range, IList<Entry> tasks)
        {
            var week = CalendarRules.Range(Period.Week, range.Start).Start;
            var points = new List<ChartDatum>();
            while (week < range.End)
            {
                DateTime from = week < range.Start ? range.Start : week;
                DateTime until = week.AddDays(7) > range.End ? range.End : week.AddDays(7);
                var period = new DateRange(from, until);
                points.Add(new ChartDatum(from.ToString("dd.MM"), planner.Count(tasks.Where(task => period.Contains(task.Day.Value))),
                    () => { anchor = from; Navigate(Section.Week); }));
                week = week.AddDays(7);
            }
            return points;
        }

        private Border YearDashboard(IList<Entry> goals)
        {
            var left = new StackPanel();
            left.Children.Add(ChartHeading("Годовые цели по сроку", planner.Count(goals), "year-progress", true));
            string[] labels = { "I квартал", "II квартал", "III квартал", "IV квартал" };
            var grid = new Grid { Margin = new Thickness(0, 12, 0, 2) };
            for (int i = 0; i < 4; i++)
            {
                int quarter = i;
                Progress progress = planner.Count(goals.Where(goal => ((goal.TargetDay ?? goal.Day.Value).Month - 1) / 3 == quarter));
                grid.ColumnDefinitions.Add(new ColumnDefinition());
                var segment = new StackPanel { Margin = new Thickness(0, 0, 9, 0) };
                segment.Children.Add(MetricValue(progress, null, 17, HeroAccent));
                segment.Children.Add(Gap(6));
                segment.Children.Add(ProgressLine(progress, true));
                var caption = Text(labels[i], 10, SoftWhite);
                caption.Margin = new Thickness(0, 6, 0, 0);
                segment.Children.Add(caption);
                Grid.SetColumn(segment, i);
                grid.Children.Add(segment);
            }
            left.Children.Add(grid);

            var right = new StackPanel();
            Head(right, "Статус года");
            AddProgressRow(right, "Цели в работе", new Progress(goals.Count(goal => !planner.Measure(goal).Complete), goals.Count), null);
            AddProgressRow(right, "Завершено подцелей", planner.Count(goals.SelectMany(planner.Children)), "year-step-progress");
            return Pair(Hero(left), DashboardCard(right), 1.75);
        }

        private void RenderHabits()
        {
            var all = planner.Entries.Where(item => item.Kind == EntryKind.Habit).ToList();
            var current = Order(all.Where(item => !item.Mastered.HasValue)).ToList();
            var finished = Order(all.Where(item => item.Mastered.HasValue)).ToList();
            DateRange today = CalendarRules.Range(Period.Day, planner.Today);
            var main = DashboardGrid(131);
            main.Children.Add(Ring(HabitRate(all, today), 106, true, "habit-progress"));
            var copy = ValueBlock("Привычки", "Отмечено сегодня", true);
            copy.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(copy, 1);
            main.Children.Add(copy);

            var right = new StackPanel();
            var period = new DateRange(planner.Today.AddDays(-6), today.End);
            right.Children.Add(ChartHeading("Последние 7 дней", HabitRate(all, period), "habit-rate"));
            var streak = Enumerable.Range(0, 7).Select(index =>
            {
                DateTime date = period.Start.AddDays(index);
                return new ChartDatum(date.ToString("dd.MM"), HabitRate(all, CalendarRules.Range(Period.Day, date)), null);
            }).ToList();
            right.Children.Add(PercentBars(streak, 46, false, false));
            content.Children.Add(Pair(Hero(main), DashboardCard(right), 1.13));
            content.Children.Add(Gap(19));
            if (current.Count == 0 && finished.Count == 0)
            {
                Head(content, "Привычек нет");
                return;
            }
            if (current.Any())
            {
                Head(content, "Активные");
                content.Children.Add(HabitCards(current));
            }
            if (finished.Any())
            {
                content.Children.Add(Gap(13));
                Head(content, "Освоенные");
                content.Children.Add(HabitCards(finished));
            }
        }

        private Grid HabitCards(IList<Entry> entries)
        {
            var panel = new Grid();
            panel.ColumnDefinitions.Add(new ColumnDefinition());
            panel.ColumnDefinitions.Add(new ColumnDefinition());
            var cards = entries.Select(HabitCard).ToList();
            foreach (Border card in cards) panel.Children.Add(card);
            Action place = () =>
            {
                bool two = panel.ActualWidth > 735 && cards.Count > 1;
                int perRow = two ? 2 : 1;
                int rows = (cards.Count + perRow - 1) / perRow;
                if (panel.RowDefinitions.Count != rows)
                {
                    panel.RowDefinitions.Clear();
                    for (int row = 0; row < rows; row++) panel.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                }
                bool featured = cards.Count == 1 && panel.ActualWidth > 600;
                panel.ColumnDefinitions[0].Width = featured ? new GridLength(530) : new GridLength(1, GridUnitType.Star);
                panel.ColumnDefinitions[1].Width = two || featured ? new GridLength(1, GridUnitType.Star) : new GridLength(0);
                for (int i = 0; i < cards.Count; i++)
                {
                    Grid.SetColumn(cards[i], i % perRow);
                    Grid.SetRow(cards[i], i / perRow);
                    cards[i].Margin = new Thickness(0, 0, two && i % 2 == 0 ? 10 : 0, 10);
                }
            };
            panel.SizeChanged += (sender, e) => { if (e.WidthChanged) place(); };
            place();
            return panel;
        }

        private Border HabitCard(Entry item)
        {
            var body = new StackPanel();
            var heading = new DockPanel { LastChildFill = true, MinHeight = 31 };
            bool marked = planner.Marks(item).Contains(planner.Today);
            if (!item.Mastered.HasValue && (!item.Day.HasValue || item.Day <= planner.Today))
            {
                var check = ToggleButton(marked, item.Title, () => CheckHabit(item, !marked), "check-" + item.Id);
                check.Margin = new Thickness(4, 0, 0, 0);
                DockPanel.SetDock(check, Dock.Right);
                heading.Children.Add(check);
            }
            var name = Button(item.Title, () => ShowDetails(item.Id), "open-" + item.Id);
            var title = Text(item.Title, 16, TextInk, true);
            title.TextTrimming = TextTrimming.CharacterEllipsis;
            title.TextWrapping = TextWrapping.NoWrap;
            name.Content = title;
            name.HorizontalContentAlignment = HorizontalAlignment.Left;
            name.ToolTip = item.Title;
            name.Padding = new Thickness(0, 0, 4, 0);
            heading.Children.Add(name);
            body.Children.Add(heading);

            var progress = new Progress(Math.Min(63, planner.Streak(item)), 63);
            var caption = new DockPanel { LastChildFill = true, Margin = new Thickness(0, 2, 0, 6) };
            var percent = Text(CountText(progress), 14, accent, true);
            Identify(percent, "streak-" + item.Id);
            DockPanel.SetDock(percent, Dock.Left);
            percent.Margin = new Thickness(0, 0, 8, 0);
            caption.Children.Add(percent);
            caption.Children.Add(Text("Серия " + planner.Streak(item) + " дн. · Рекорд " + planner.RecordStreak(item) + " дн.", 12, Muted));
            body.Children.Add(caption);
            body.Children.Add(HabitTrack(item));
            var card = DashboardCard(body);
            return card;
        }

        private FrameworkElement HabitTrack(Entry item)
        {
            int streak = planner.Streak(item);
            DateTime last = item.Mastered ?? planner.Today;
            var marks = new HashSet<DateTime>(planner.Marks(item));
            int past = Math.Min(63, streak);
            DateTime start = past == 0 ? (item.Day > last ? item.Day.Value : last) :
                (marks.Contains(last) ? last : last.AddDays(-1)).AddDays(1 - past);
            var group = new StackPanel { Margin = new Thickness(0, 2, 0, 1), FlowDirection = FlowDirection.LeftToRight };
            for (int row = 0; row < 3; row++)
            {
                var line = Horizontal();
                for (int col = 0; col < 21; col++)
                {
                    int index = row * 21 + col;
                    bool finished = index < past;
                    DateTime date = start.AddDays(index);
                    var tile = new Border
                    {
                        Width = 12, Height = 12, CornerRadius = new CornerRadius(3),
                        Margin = new Thickness(0, 0, col % 7 == 6 ? 5 : 3, 3),
                        Background = finished ? accent : accentWash, BorderBrush = date == planner.Today ? accent : Clear,
                        BorderThickness = new Thickness(1),
                        ToolTip = "День " + (index + 1) + " · " + date.ToString("dd.MM")
                    };
                    Identify(tile, "habit-" + item.Id + "-step-" + (index + 1), finished ? "Отмечено" : "Не отмечено");
                    line.Children.Add(tile);
                }
                group.Children.Add(line);
            }
            return group;
        }

        private Progress HabitRate(IEnumerable<Entry> habits, DateRange range)
        {
            int eligible = 0, marked = 0;
            foreach (Entry habit in habits)
            {
                if (!habit.Day.HasValue) continue;
                DateTime from = habit.Day.Value > range.Start ? habit.Day.Value : range.Start;
                DateTime end = range.End < planner.Today.AddDays(1) ? range.End : planner.Today.AddDays(1);
                if (habit.Mastered.HasValue && habit.Mastered.Value.AddDays(1) < end) end = habit.Mastered.Value.AddDays(1);
                if (end <= from) continue;
                eligible += (end - from).Days;
                marked += planner.Marks(habit).Count(day => day >= from && day < end);
            }
            return new Progress(marked, eligible);
        }

        private Grid DashboardGrid(double first)
        {
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(first) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            return grid;
        }

        private Border Pair(UIElement left, UIElement right, double weight = 1)
        {
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(weight, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.Children.Add(left);
            Grid.SetColumn(right, 2);
            grid.Children.Add(right);
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.SizeChanged += (sender, e) =>
            {
                if (!e.WidthChanged) return;
                bool narrow = grid.ActualWidth < 575;
                grid.ColumnDefinitions[1].Width = new GridLength(narrow ? 0 : 11);
                grid.ColumnDefinitions[2].Width = narrow ? new GridLength(0) : new GridLength(1, GridUnitType.Star);
                Grid.SetRow(right, narrow ? 1 : 0);
                Grid.SetColumn(right, narrow ? 0 : 2);
                (right as FrameworkElement).Margin = narrow ? new Thickness(0, 8, 0, 0) : new Thickness(0);
            };
            return new Border { Child = grid };
        }

        private Border DashboardCard(UIElement child)
        {
            var card = Card(child, new Thickness(17, 14, 17, 14));
            card.CornerRadius = new CornerRadius(17);
            return card;
        }

        private Border Hero(UIElement child, bool illustrated = true)
        {
            if (illustrated)
            {
                var layers = new Grid();
                layers.ColumnDefinitions.Add(new ColumnDefinition());
                layers.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(150) });
                var art = new Border { Background = LandscapeBrush(currentStyle),
                    CornerRadius = new CornerRadius(0, 17, 17, 0), IsHitTestVisible = false };
                art.OpacityMask = LandscapeFade();
                Identify(art, "dashboard-landscape-" + section + "-" + currentStyle.Key);
                Grid.SetColumn(art, 1);
                layers.Children.Add(art);
                var data = new Border { Child = child, Padding = new Thickness(20, 17, 5, 17),
                    VerticalAlignment = VerticalAlignment.Center };
                layers.Children.Add(data);
                layers.SizeChanged += (sender, e) =>
                {
                    if (e.WidthChanged)
                        layers.ColumnDefinitions[1].Width = new GridLength(layers.ActualWidth >= 700 ?
                            Math.Min(460, layers.ActualWidth * .48) : Math.Max(100, layers.ActualWidth * .34));
                };
                return new Border { Child = layers, Background = Ink(currentStyle.Dark),
                    CornerRadius = new CornerRadius(17), MinHeight = 175 };
            }
            var gradient = new LinearGradientBrush();
            gradient.StartPoint = new Point(0, 0);
            gradient.EndPoint = new Point(1, 1);
            gradient.GradientStops.Add(new GradientStop(ColorOf(currentStyle.Dark), 0));
            gradient.GradientStops.Add(new GradientStop(ColorOf(currentStyle.DarkEnd), 1));
            return new Border
            {
                CornerRadius = new CornerRadius(17), Padding = new Thickness(16, 14, 16, 14),
                Background = gradient, Child = child
            };
        }

        private Border IllustratedDay(FrameworkElement data)
        {
            var layers = new Grid();
            layers.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            layers.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(2.7, GridUnitType.Star) });
            var picture = new Border
            {
                Background = LandscapeBrush(currentStyle, AlignmentY.Top), CornerRadius = new CornerRadius(0, 17, 17, 0),
                IsHitTestVisible = false
            };
            picture.OpacityMask = LandscapeFade();
            Identify(picture, "day-landscape-" + currentStyle.Key);
            Grid.SetColumn(picture, 1);
            layers.Children.Add(picture);

            Color deep = ColorOf(currentStyle.Dark);
            var vignette = new LinearGradientBrush { StartPoint = new Point(0, .5), EndPoint = new Point(1, .5) };
            vignette.GradientStops.Add(new GradientStop(deep, .27));
            vignette.GradientStops.Add(new GradientStop(Color.FromArgb(185, deep.R, deep.G, deep.B), .35));
            vignette.GradientStops.Add(new GradientStop(Color.FromArgb(0, deep.R, deep.G, deep.B), .70));
            var shade = new Border { Background = vignette, CornerRadius = new CornerRadius(17), IsHitTestVisible = false };
            Grid.SetColumnSpan(shade, 2);
            layers.Children.Add(shade);

            var copy = new Border { Child = data, Padding = new Thickness(15, 12, 15, 12) };
            Grid.SetColumnSpan(copy, 2);
            layers.Children.Add(copy);
            return new Border
            {
                Child = layers, Background = Ink(currentStyle.Dark), CornerRadius = new CornerRadius(17),
                MinHeight = 197
            };
        }

        private static Brush LandscapeFade()
        {
            var fade = new LinearGradientBrush { StartPoint = new Point(0, .5), EndPoint = new Point(1, .5) };
            fade.GradientStops.Add(new GradientStop(Colors.Transparent, 0));
            fade.GradientStops.Add(new GradientStop(Color.FromArgb(32, 0, 0, 0), .18));
            fade.GradientStops.Add(new GradientStop(Colors.Black, .72));
            return fade;
        }

        private static Color ColorOf(string hex) { return (Color)ColorConverter.ConvertFromString(hex); }

        private StackPanel ValueBlock(string name, string subtitle, bool dark)
        {
            var stack = new StackPanel();
            stack.Children.Add(Text(name, 12, dark ? SoftWhite : Muted, true));
            var title = Text(subtitle, 25, dark ? White : TextInk, true);
            title.Margin = new Thickness(0, 4, 0, 0);
            stack.Children.Add(title);
            return stack;
        }

        private FrameworkElement Ring(Progress progress, double size, bool dark, string id, bool trackOnlyLabel = false)
        {
            var grid = new Grid
            {
                Width = size, Height = size, HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
            double stroke = size > 100 ? 9 : 6;
            double radius = (size - stroke) / 2 - 4;
            double mid = size / 2;
            Brush track = dark ? HeroTrack : Line;
            Brush fill = dark ? HeroAccent : accent;
            grid.Children.Add(new Ellipse { Stroke = track, StrokeThickness = stroke, Margin = new Thickness(4) });
            if (progress.Percent >= 100)
                grid.Children.Add(new Ellipse { Stroke = fill, StrokeThickness = stroke, Margin = new Thickness(4) });
            else if (progress.Percent > 0)
            {
                double angle = progress.Percent * Math.PI / 50;
                var segment = new ArcSegment(new Point(mid + radius * Math.Sin(angle), mid - radius * Math.Cos(angle)),
                    new Size(radius, radius), 0, progress.Percent > 50, SweepDirection.Clockwise, true);
                var figure = new PathFigure { StartPoint = new Point(mid, mid - radius) };
                figure.Segments.Add(segment);
                var geometry = new PathGeometry();
                geometry.Figures.Add(figure);
                grid.Children.Add(new Path { Data = geometry, Stroke = fill, StrokeThickness = stroke,
                    StrokeStartLineCap = PenLineCap.Round, StrokeEndLineCap = PenLineCap.Round });
            }
            if (!trackOnlyLabel)
            {
                var number = MetricValue(progress, id, size > 100 ? 31 : size >= 80 ? 21 : 13, dark ? White : accent);
                number.HorizontalAlignment = HorizontalAlignment.Center;
                grid.Children.Add(number);
            }
            return grid;
        }

        private TextBlock MetricValue(Progress value, string id, double size, Brush color)
        {
            var score = Text(CountText(value), size, color, true);
            score.FontFamily = new FontFamily("Segoe UI Variable Display");
            score.TextWrapping = TextWrapping.NoWrap;
            Identify(score, id);
            return score;
        }

        private TextBlock DarkMetric(Progress value, string id) { return MetricValue(value, id, 32, accent); }

        private UIElement ChartHeading(string title, Progress result, string id, bool dark = false)
        {
            var bar = new DockPanel { LastChildFill = true };
            var score = MetricValue(result, id, 26, dark ? HeroAccent : accent);
            score.Margin = new Thickness(8, 0, 0, 0);
            DockPanel.SetDock(score, Dock.Right);
            bar.Children.Add(score);
            bar.Children.Add(Text(title, 16, dark ? White : TextInk, true));
            return bar;
        }

        private Border ProgressLine(Progress value, bool dark = false)
        {
            var segments = new Grid();
            if (value.Done > 0)
            {
                segments.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(value.Done, GridUnitType.Star) });
                segments.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(Math.Max(0, value.Total - value.Done), GridUnitType.Star) });
                segments.Children.Add(new Border { Background = dark ? HeroAccent : accent, CornerRadius = new CornerRadius(4) });
            }
            return new Border { Background = dark ? HeroTrack : accentWash, Height = 7, CornerRadius = new CornerRadius(4), Child = segments };
        }

        private void AddProgressRow(StackPanel panel, string label, Progress value, string id, bool dense = false)
        {
            var line = new DockPanel { LastChildFill = true, Margin = new Thickness(0, 1, 0, 3) };
            var number = MetricValue(value, id, 13, accent);
            DockPanel.SetDock(number, Dock.Right);
            number.Margin = new Thickness(7, 0, 0, 0);
            line.Children.Add(number);
            var title = Text(label, 12, TextInk, true);
            title.TextWrapping = TextWrapping.NoWrap;
            title.TextTrimming = TextTrimming.CharacterEllipsis;
            title.ToolTip = label;
            line.Children.Add(title);
            panel.Children.Add(line);
            panel.Children.Add(ProgressLine(value));
            if (!dense) panel.Children.Add(Gap(8));
        }

        private UIElement PercentBars(IList<ChartDatum> points, double height, bool dark, bool showLabels = true)
        {
            var grid = new Grid { Margin = new Thickness(0, 7, 0, 0) };
            bool hasAuxiliary = points.Any(point => point.Auxiliary != null);
            for (int i = 0; i < points.Count; i++)
            {
                ChartDatum point = points[i];
                grid.ColumnDefinitions.Add(new ColumnDefinition());
                var body = new StackPanel();
                if (showLabels)
                {
                    var percent = MetricValue(point.Progress, null, 11, dark ? SoftWhite : Muted);
                    percent.HorizontalAlignment = HorizontalAlignment.Center;
                    body.Children.Add(percent);
                    body.Children.Add(Gap(3));
                }
                var bar = new Grid { Width = 15, Height = height / (showLabels ? 1.45 : 1.6),
                    HorizontalAlignment = HorizontalAlignment.Center, ClipToBounds = true };
                bar.Children.Add(new Border { Background = dark ? HeroTrack : accentWash, CornerRadius = new CornerRadius(6),
                    Opacity = point.Progress.Total == 0 ? .47 : 1 });
                if (point.Progress.Done > 0)
                    bar.Children.Add(new Border
                    {
                        Height = bar.Height * point.Progress.Done / point.Progress.Total,
                        VerticalAlignment = VerticalAlignment.Bottom, CornerRadius = new CornerRadius(6),
                        Background = point.Color ?? (dark ? HeroAccent : accent)
                    });
                body.Children.Add(bar);
                var label = Text(point.Caption, 10, dark ? SoftWhite : Muted);
                label.Margin = new Thickness(0, 4, 0, 0);
                label.HorizontalAlignment = HorizontalAlignment.Center;
                body.Children.Add(label);
                if (hasAuxiliary)
                {
                    var load = Text(point.Auxiliary ?? " ", 10, accent, true);
                    load.HorizontalAlignment = HorizontalAlignment.Center;
                    body.Children.Add(load);
                }
                FrameworkElement item = body;
                if (point.Select != null)
                {
                    var button = Button(point.Caption, point.Select, "weekly-chart-" + i, point.Selected ? "selected" : "plain");
                    button.Content = body;
                    button.Padding = new Thickness(1, 0, 1, 0);
                    item = button;
                }
                item.ToolTip = point.Caption + " · " + CountText(point.Progress) +
                    (point.Auxiliary == null ? "" : " · " + point.Auxiliary + " по плану");
                Grid.SetColumn(item, i);
                grid.Children.Add(item);
            }
            return grid;
        }

        private UIElement ActivityTrend(IList<ChartDatum> points, bool dark)
        {
            const double chartHeight = 81;
            var panel = DashboardGrid(35);
            var axis = new Canvas { Height = chartHeight, Margin = new Thickness(0, 8, 0, 0),
                VerticalAlignment = VerticalAlignment.Top };
            for (int i = 0; i <= 2; i++)
            {
                var label = Text((100 - i * 50) + "%", 10, dark ? SoftWhite : Muted);
                Canvas.SetTop(label, 4 + i * 32);
                axis.Children.Add(label);
            }
            panel.Children.Add(axis);
            var right = new StackPanel();
            var canvas = new Canvas { Height = chartHeight, Margin = new Thickness(0, 8, 0, 0) };
            var ticks = new Grid();
            for (int i = 0; i < points.Count; i++)
            {
                ChartDatum point = points[i];
                ticks.ColumnDefinitions.Add(new ColumnDefinition());
                var caption = Text(point.Caption, 10, dark ? SoftWhite : Muted);
                caption.HorizontalAlignment = HorizontalAlignment.Center;
                FrameworkElement item = caption;
                if (point.Select != null)
                {
                    var button = Button("", point.Select, "trend-range-" + i);
                    button.Content = caption;
                    button.MinHeight = 24;
                    button.Padding = new Thickness(0, 1, 0, 1);
                    item = button;
                }
                item.ToolTip = CountText(point.Progress);
                Grid.SetColumn(item, i);
                ticks.Children.Add(item);
            }
            canvas.SizeChanged += (sender, e) =>
            {
                canvas.Children.Clear();
                double width = canvas.ActualWidth;
                foreach (int y in new[] { 10, 42, 74 })
                    canvas.Children.Add(new Line { X1 = 0, X2 = width, Y1 = y, Y2 = y,
                        Stroke = dark ? HeroTrack : Line, StrokeThickness = 1 });
                Point? previous = null;
                Brush stroke = dark ? HeroAccent : accent;
                for (int i = 0; i < points.Count; i++)
                {
                    Progress value = points[i].Progress;
                    if (value.Total == 0) { previous = null; continue; }
                    var location = new Point((i + .5) * width / points.Count, 74 - value.Percent * .64);
                    if (previous.HasValue)
                    {
                        var last = previous.Value;
                        var area = new Polygon
                        {
                            Points = new PointCollection { last, location, new Point(location.X, 74), new Point(last.X, 74) },
                            Fill = stroke, Opacity = .16
                        };
                        canvas.Children.Add(area);
                        canvas.Children.Add(new Line { X1 = last.X, X2 = location.X, Y1 = last.Y, Y2 = location.Y,
                            Stroke = stroke, StrokeThickness = 2.1 });
                    }
                    var dot = new Ellipse { Width = 7, Height = 7, Fill = stroke, ToolTip = points[i].Caption + " · " + CountText(value) };
                    Canvas.SetLeft(dot, location.X - 3.5);
                    Canvas.SetTop(dot, location.Y - 3.5);
                    canvas.Children.Add(dot);
                    previous = location;
                }
            };
            right.Children.Add(canvas);
            right.Children.Add(ticks);
            Grid.SetColumn(right, 1);
            panel.Children.Add(right);
            return panel;
        }

        private sealed class ChartDatum
        {
            public readonly string Caption;
            public readonly Progress Progress;
            public readonly Action Select;
            public readonly Brush Color;
            public readonly string Auxiliary;
            public readonly bool Selected;
            public ChartDatum(string caption, Progress progress, Action select, Brush color = null, string auxiliary = null, bool selected = false)
            {
                Caption = caption;
                Progress = progress;
                Select = select;
                Color = color;
                Auxiliary = auxiliary;
                Selected = selected;
            }
        }
    }
}
