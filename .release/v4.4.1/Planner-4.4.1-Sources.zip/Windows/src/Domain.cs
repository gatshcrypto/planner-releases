using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Planner
{
    internal enum EntryKind { Task, Goal, Subgoal, Habit, Event }
    internal enum Period { Day, Week, Month, Year }
    internal enum Section { Tasks, Subgoals, Goals, Habits, Events, Finance, FinanceSummary, Summary, Day, Week, Month, Year }

    internal sealed class Entry
    {
        public string Id = Guid.NewGuid().ToString("N");
        public EntryKind Kind;
        public string Title = "";
        public int Priority;
        public string ParentId;
        public string BoardColumn;
        public DateTime? TargetDay, CompletedOn, ArchivedOn;
        public DateTime? Day;
        public Period? Period;
        public bool Checked;
        public string Notes = "";
        public long CreationOrder;
        public TimeSpan? Time;
        public int? DurationMinutes;
        public DateTime? Mastered;
        public Entry Copy() { return (Entry)MemberwiseClone(); }
    }

    internal sealed class BoardColumn
    {
        public string Id = Guid.NewGuid().ToString("N");
        public string Title;
        public int Position;
    }

    internal sealed class HabitMark
    {
        public string Id;
        public DateTime Day;
    }

    internal struct Progress
    {
        public int Done, Total;
        public Progress(int done, int total) { Done = done; Total = total; }
        public bool Complete { get { return Total > 0 && Done == Total; } }
        public int Percent { get { return Total == 0 ? 0 : (int)Math.Floor(100.0 * Done / Total); } }
    }

    internal struct DateRange
    {
        public DateTime Start, End;
        public DateRange(DateTime start, DateTime end) { Start = start; End = end; }
        public bool Contains(DateTime date) { return date.Date >= Start && date.Date < End; }
    }

    internal static class CalendarRules
    {
        public static readonly CultureInfo Russian = CultureInfo.GetCultureInfo("ru-RU");

        public static DateRange Range(Period period, DateTime day)
        {
            day = day.Date;
            switch (period)
            {
                case Period.Week:
                    DateTime monday = day.AddDays(-(((int)day.DayOfWeek + 6) % 7));
                    return new DateRange(monday, monday.AddDays(7));
                case Period.Month:
                    DateTime month = new DateTime(day.Year, day.Month, 1);
                    return new DateRange(month, month.AddMonths(1));
                case Period.Year:
                    DateTime year = new DateTime(day.Year, 1, 1);
                    return new DateRange(year, year.AddYears(1));
                default:
                    return new DateRange(day, day.AddDays(1));
            }
        }

        public static DateTime Shift(Period period, DateTime day, int steps)
        {
            switch (period)
            {
                case Period.Week: return day.AddDays(7 * steps);
                case Period.Month: return day.AddMonths(steps);
                case Period.Year: return day.AddYears(steps);
                default: return day.AddDays(steps);
            }
        }

        public static string Capital(string value)
        {
            return Char.ToUpper(value[0], Russian) + value.Substring(1);
        }

        public static string Label(Period period, DateTime day)
        {
            DateRange range = Range(period, day);
            switch (period)
            {
                case Period.Week:
                    return range.Start.ToString("d MMM", Russian) + " — " +
                        range.End.AddDays(-1).ToString("d MMM yyyy", Russian);
                case Period.Month: return Capital(day.ToString("MMMM yyyy", Russian));
                case Period.Year: return day.Year + " год";
                default: return Capital(day.ToString("dddd, d MMMM", Russian));
            }
        }

        public static int Streak(IEnumerable<DateTime> days, DateTime today)
        {
            var marked = new HashSet<DateTime>(days.Select(day => day.Date));
            DateTime cursor = marked.Contains(today.Date) ? today.Date : today.Date.AddDays(-1);
            int count = 0;
            while (marked.Contains(cursor))
            {
                count++;
                cursor = cursor.AddDays(-1);
            }
            return count;
        }
    }

    internal sealed class PlannerService
    {
        private readonly Store store;
        private Dictionary<string, Entry> entries;
        private ILookup<string, Entry> children;
        private ILookup<string, DateTime> marks;
        private DeletedEntries deletion;
        public Func<DateTime> Clock;
        public DateTime Now { get { return Clock(); } }
        public DateTime Today { get { return Now.Date; } }
        public IEnumerable<Entry> Entries { get { return entries.Values; } }
        public bool CanUndo { get { return deletion != null; } }
        public List<BoardColumn> Columns { get; private set; }

        public PlannerService(Store store, Func<DateTime> clock)
        {
            this.store = store;
            Clock = clock;
            store.DateUndatedOpenTasks(Today);
            SyncArchive();
        }

        public void SyncArchive()
        {
            store.ExpireArchive(Today.AddMonths(-1));
            Reload();
        }

        public void ClearPlanning()
        {
            store.ClearPlanning();
            deletion = null;
            Reload();
        }

        public void ClearArchive(string id = null)
        {
            store.Atomic(() => store.ClearArchive(id));
            Reload();
        }

        public IEnumerable<Entry> ArchivedTasks
        {
            get { return Entries.Where(entry => entry.Kind == EntryKind.Task && entry.ArchivedOn.HasValue); }
        }

        public IEnumerable<Entry> ArchivedEntries
        {
            get { return Entries.Where(entry => (entry.Kind == EntryKind.Task || entry.Kind == EntryKind.Subgoal)
                && entry.ArchivedOn.HasValue && entry.Title.Length > 0); }
        }

        public bool IsArchived(Entry entry)
        {
            return entry.Kind == EntryKind.Subgoal && entry.Checked;
        }

        public bool CanAttachTaskTo(Entry subgoal)
        {
            return subgoal != null && subgoal.Kind == EntryKind.Subgoal && !IsArchived(subgoal);
        }

        private void MutatePlanning(Action action)
        {
            var before = Entries.Where(entry => entry.Kind == EntryKind.Goal || entry.Kind == EntryKind.Subgoal)
                .ToDictionary(entry => entry.Id, entry => Measure(entry).Complete);
            try
            {
                store.Atomic(() =>
                {
                    action();
                    Reload();
                    foreach (Entry item in Entries.Where(entry => entry.Kind == EntryKind.Goal || entry.Kind == EntryKind.Subgoal).ToList())
                    {
                        Entry updated = item.Copy();
                        if (item.Kind == EntryKind.Goal && Children(item).Any()) updated.Checked = false;
                        bool complete = Measure(item).Complete, wasComplete;
                        if (!complete)
                        {
                            updated.CompletedOn = null;
                            updated.ArchivedOn = null;
                            if (item.Kind == EntryKind.Subgoal) updated.Checked = false;
                        }
                        else if (!before.TryGetValue(item.Id, out wasComplete) || !wasComplete)
                            updated.CompletedOn = Today;
                        if (updated.Kind == EntryKind.Subgoal && updated.Checked && complete && !updated.ArchivedOn.HasValue)
                            updated.ArchivedOn = Today;
                        if (updated.Checked != item.Checked || updated.CompletedOn != item.CompletedOn || updated.ArchivedOn != item.ArchivedOn)
                            store.Save(updated);
                    }
                });
            }
            finally { Reload(); }
        }

        public void Reload()
        {
            Columns = store.ReadColumns();
            entries = store.ReadEntries().ToDictionary(entry => entry.Id);
            children = entries.Values.Where(entry => entry.ParentId != null).ToLookup(entry => entry.ParentId);
            marks = store.ReadMarks().ToLookup(mark => mark.Id, mark => mark.Day);
        }

        public Entry Find(string id)
        {
            Entry entry;
            return id != null && entries.TryGetValue(id, out entry) ? entry : null;
        }

        public IEnumerable<Entry> Children(Entry entry) { return children[entry.Id]; }
        public IEnumerable<DateTime> Marks(Entry entry) { return marks[entry.Id].OrderByDescending(day => day); }
        public int Streak(Entry entry)
        {
            return CalendarRules.Streak(marks[entry.Id], entry.Mastered ?? Today);
        }

        public Progress Measure(Entry entry)
        {
            List<Entry> items = Children(entry).ToList();
            if (items.Count == 0) return new Progress(entry.Checked ? 1 : 0, 1);
            return new Progress(items.Count(item => Measure(item).Complete), items.Count);
        }

        public Progress Count(IEnumerable<Entry> set)
        {
            var items = set.ToList();
            return new Progress(items.Count(item => Measure(item).Complete), items.Count);
        }

        public static DateTime? ScheduledDate(Entry entry)
        {
            return entry.Kind == EntryKind.Goal || entry.Kind == EntryKind.Subgoal ?
                entry.TargetDay ?? entry.Day : entry.Day;
        }

        public static IOrderedEnumerable<Entry> Chronological(IEnumerable<Entry> entries)
        {
            return entries.OrderBy(entry => ScheduledDate(entry) ?? DateTime.MaxValue)
                .ThenBy(entry => entry.Time ?? TimeSpan.MaxValue)
                .ThenBy(entry => entry.CreationOrder)
                .ThenBy(entry => entry.Id, StringComparer.Ordinal);
        }

        public Entry Save(Entry entry)
        {
            entry = entry.Copy();
            entry.Title = entry.Title.Trim();
            if (entry.BoardColumn != null && !Columns.Any(column => column.Id == entry.BoardColumn))
                throw new ArgumentException("Выберите существующий столбец.");
            entry.Notes = (entry.Notes ?? "").Trim();
            if (entry.DurationMinutes.HasValue && (entry.Kind != EntryKind.Task || entry.DurationMinutes < 1 || entry.DurationMinutes > 1440))
                throw new ArgumentException("Укажи длительность от 1 до 1440 минут.");
            if (entry.Title.Length == 0) throw new ArgumentException("Введите название.");
            if (entry.Day.HasValue) entry.Day = entry.Day.Value.Date;
            if ((entry.Kind == EntryKind.Event || entry.Kind == EntryKind.Goal || entry.Kind == EntryKind.Task)
                && !entry.Day.HasValue)
                throw new ArgumentException("Выберите дату.");

            if (entry.Kind == EntryKind.Goal)
            {
                if (!entry.Period.HasValue || entry.Period == Period.Day)
                    throw new ArgumentException("Выберите период цели.");
                if (entry.Day > new DateTime(9997, 12, 24)) throw new ArgumentException("Выберите более раннюю дату начала.");
                Entry original = Find(entry.Id);
                if (original == null || original.Day != entry.Day || original.Period != entry.Period || !original.TargetDay.HasValue)
                    entry.TargetDay = CalendarRules.Shift(entry.Period.Value, entry.Day.Value, 1);
                else entry.TargetDay = original.TargetDay;
            }
            if (entry.Kind == EntryKind.Subgoal &&
                (entry.Day.HasValue != entry.TargetDay.HasValue || entry.TargetDay < entry.Day))
                throw new ArgumentException("Укажите начало и завершение подцели или выберите «Без срока».");
            if (entry.Kind == EntryKind.Subgoal || (entry.Kind == EntryKind.Task && entry.ParentId != null))
            {
                Entry parent = Find(entry.ParentId);
                EntryKind required = entry.Kind == EntryKind.Subgoal ? EntryKind.Goal : EntryKind.Subgoal;
                if (parent == null || parent.Kind != required)
                    throw new ArgumentException(entry.Kind == EntryKind.Subgoal ?
                        "Выберите родительскую цель." : "Выберите существующую подцель.");
                if (entry.Kind == EntryKind.Task && !CanAttachTaskTo(parent))
                {
                    Entry original = Find(entry.Id);
                    if (original == null || original.ParentId != parent.Id)
                        throw new ArgumentException("Подцель выполнена. Снимите отметку выполнения, чтобы добавить задачу.");
                }
                entry.BoardColumn = ColumnFor(parent);
            }
            else
            {
                entry.ParentId = null;
            }
            MutatePlanning(() =>
            {
                store.Save(entry);
                if (entry.Kind == EntryKind.Goal || entry.Kind == EntryKind.Subgoal)
                {
                    var existing = Find(entry.Id);
                    if (existing != null)
                    {
                        foreach (Entry child in Branch(existing).Skip(1))
                        {
                            Entry changed = child.Copy();
                            changed.BoardColumn = entry.BoardColumn;
                            store.Save(changed);
                        }
                    }
                }
            });
            Reload();
            return entries[entry.Id];
        }

        public bool CanCheck(Entry entry)
        {
            return entry.Kind == EntryKind.Task ||
                (entry.Kind == EntryKind.Goal && !Children(entry).Any()) ||
                (entry.Kind == EntryKind.Subgoal && (!Children(entry).Any() || Measure(entry).Complete));
        }

        public void SetChecked(Entry entry, bool done)
        {
            if (!CanCheck(entry) || (entry.Kind == EntryKind.Task && entry.Checked && !entry.ArchivedOn.HasValue)
                || entry.Checked == done) return;
            Entry changed = entry.Copy();
            if (changed.Kind == EntryKind.Task && !changed.Day.HasValue) changed.Day = Today;
            changed.Checked = done;
            changed.CompletedOn = done ? (DateTime?)Today : null;
            if (entry.Kind == EntryKind.Task || entry.Kind == EntryKind.Subgoal)
                changed.ArchivedOn = done ? (DateTime?)Today : null;
            Save(changed);
        }

        public IEnumerable<Entry> OverdueTasks()
        {
            DateTime today = Today;
            return Chronological(Entries.Where(entry => entry.Kind == EntryKind.Task && !entry.Checked && entry.Day < today));
        }

        public int MoveOverdue(IEnumerable<string> ids, DateTime day)
        {
            DateTime destination = day.Date;
            if (destination < Today) throw new ArgumentException("Выбери сегодня или более позднюю дату.");
            var selected = new HashSet<string>(ids);
            var tasks = OverdueTasks().Where(task => selected.Contains(task.Id)).ToList();
            store.Atomic(() =>
            {
                foreach (Entry task in tasks)
                {
                    Entry moved = task.Copy();
                    moved.Day = destination;
                    store.Save(moved);
                }
            });
            Reload();
            return tasks.Count;
        }

        public IEnumerable<Entry> Tasks(DateRange range)
        {
            return Entries.Where(entry => entry.Kind == EntryKind.Task && entry.Day.HasValue && range.Contains(entry.Day.Value));
        }

        public string ColumnFor(Entry entry)
        {
            Entry parent = Find(entry.ParentId);
            return parent == null ? entry.BoardColumn : ColumnFor(parent);
        }

        public static string TermName(Period period)
        {
            return period == Period.Week ? "Неделя" : period == Period.Month ? "Месяц" : "Год";
        }

        public static string Dates(Entry entry)
        {
            if (!entry.Day.HasValue) return entry.Kind == EntryKind.Task ? "Без даты" : "Без срока";
            string start = entry.Day.Value.ToString("dd.MM.yyyy");
            return entry.Kind == EntryKind.Goal || entry.Kind == EntryKind.Subgoal ?
                start + " — " + (entry.TargetDay.HasValue ? entry.TargetDay.Value.ToString("dd.MM.yyyy") : "—") : start;
        }

        public IEnumerable<Entry> Goals(Period period, DateTime anchor)
        {
            DateTime start = CalendarRules.Range(period, anchor).Start;
            return Entries.Where(entry => entry.Kind == EntryKind.Goal && entry.Period == period && entry.Day == start);
        }

        public bool SetHabit(Entry entry, bool done)
        {
            DateTime today = Today;
            if (entry.Kind != EntryKind.Habit || entry.Mastered.HasValue || entry.Day > today) return false;
            if (marks[entry.Id].Contains(today) == done) return false;
            bool mastery = done && Streak(entry) == 62;
            store.Atomic(() =>
            {
                store.SetMark(entry.Id, today, done);
                if (mastery || (done && !entry.Day.HasValue))
                {
                    Entry updated = entry.Copy();
                    if (!updated.Day.HasValue) updated.Day = today;
                    if (mastery) updated.Mastered = today;
                    store.Save(updated);
                }
            });
            Reload();
            return mastery;
        }

        public List<Entry> Branch(Entry entry)
        {
            var branch = new List<Entry> { entry };
            foreach (Entry child in Children(entry)) branch.AddRange(Branch(child));
            return branch;
        }

        public void Delete(Entry entry)
        {
            List<Entry> branch = Branch(entry);
            var deleted = new DeletedEntries
            {
                Entries = branch,
                Marks = branch.SelectMany(item => marks[item.Id].Select(day => new HabitMark
                {
                    Id = item.Id,
                    Day = day
                })).ToList()
            };
            MutatePlanning(() => store.Delete(entry.Id));
            deletion = deleted;
            Reload();
        }

        public void UndoDelete()
        {
            if (deletion == null) return;
            MutatePlanning(() =>
            {
                foreach (Entry entry in deletion.Entries)
                {
                    Entry restored = entry.Copy();
                    if (!Columns.Any(column => column.Id == restored.BoardColumn)) restored.BoardColumn = null;
                    store.Save(restored);
                }
                foreach (HabitMark mark in deletion.Marks) store.SetMark(mark.Id, mark.Day, true);
            });
            deletion = null;
            Reload();
        }

        public BoardColumn SaveColumn(BoardColumn column, string name)
        {
            string title = name.Trim();
            if (String.IsNullOrWhiteSpace(title)) throw new ArgumentException("Введите название столбца.");
            if (Columns.Any(item => item.Id != column.Id &&
                String.Equals(item.Title, title, StringComparison.CurrentCultureIgnoreCase)))
                throw new ArgumentException("Столбец с таким названием уже есть.");
            var updated = new BoardColumn { Id = column.Id, Title = title, Position = column.Position };
            store.SaveColumn(updated);
            Reload();
            return updated;
        }

        public void ShiftColumn(BoardColumn column, int direction)
        {
            int current = Columns.FindIndex(item => item.Id == column.Id);
            int target = current + direction;
            if (current < 0 || target < 0 || target >= Columns.Count) return;
            var reordered = Columns.ToList();
            reordered.RemoveAt(current);
            reordered.Insert(target, column);
            store.Atomic(() =>
            {
                for (int i = 0; i < reordered.Count; i++)
                    store.SaveColumn(new BoardColumn { Id = reordered[i].Id, Title = reordered[i].Title, Position = i });
            });
            Reload();
        }

        public void RemoveColumn(BoardColumn column)
        {
            store.DeleteColumn(column.Id);
            Reload();
        }

        public int RecordStreak(Entry entry)
        {
            int record = 0, current = 0;
            DateTime? previous = null;
            foreach (DateTime day in marks[entry.Id].OrderBy(date => date))
            {
                current = previous.HasValue && (day - previous.Value).Days == 1 ? current + 1 : 1;
                record = Math.Max(record, current);
                previous = day;
            }
            return record;
        }

        private sealed class DeletedEntries
        {
            public List<Entry> Entries;
            public List<HabitMark> Marks;
        }
    }
}


