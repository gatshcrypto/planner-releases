"""Deploy the independent private-data planner to the owner's Cloudflare Free account.

Uses the official Wrangler OAuth public client/device flow. Cloudflare credentials
stay in process memory. The generated recovery key belongs to the planner owner.
"""
import argparse
import base64
import hashlib
import json
import pathlib
import secrets
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

ROOT = pathlib.Path(__file__).resolve().parents[1]
CLIENT = '54d11594-84e4-41aa-b438-e81b8fa78ee7'
SCOPES = 'account:read user:read workers:write workers_scripts:write d1:write offline_access'
BASE = 'https://api.cloudflare.com/client/v4'


def request(url, method='GET', data=None, token=None, content_type=None):
    headers = {'User-Agent': 'PlannerDeployment/1.0'}
    if token:
        headers['Authorization'] = 'Bearer ' + token
    if isinstance(data, dict):
        data = json.dumps(data).encode()
        content_type = 'application/json'
    if content_type:
        headers['Content-Type'] = content_type
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=45) as response:
            return json.load(response)
    except urllib.error.HTTPError as error:
        try:
            body = json.loads(error.read())
        except (ValueError, UnicodeError):
            body = {}
        if 'error' in body:
            return body
        messages = ', '.join(str(item.get('code', 'unknown')) + ': ' + str(item.get('message', ''))[:300] for item in body.get('errors', []))
        raise RuntimeError('Cloudflare HTTP ' + str(error.code) + ' ' + messages) from None


def authenticate():
    encoded = urllib.parse.urlencode({'client_id': CLIENT, 'scope': SCOPES}).encode()
    device = request('https://dash.cloudflare.com/oauth2/device/auth', 'POST', encoded, content_type='application/x-www-form-urlencoded')
    if 'device_code' not in device:
        raise RuntimeError('Device authorization unavailable: ' + str(device.get('error', 'unknown')))
    print(json.dumps({'verification_uri': device['verification_uri'], 'user_code': device['user_code'], 'expires_in': device['expires_in']}), flush=True)
    deadline = time.monotonic() + int(device['expires_in'])
    delay = max(5, int(device.get('interval', 5)))
    while time.monotonic() < deadline:
        time.sleep(delay)
        result = request('https://dash.cloudflare.com/oauth2/token', 'POST', urllib.parse.urlencode({
            'client_id': CLIENT, 'device_code': device['device_code'], 'grant_type': 'urn:ietf:params:oauth:grant-type:device_code'
        }).encode(), content_type='application/x-www-form-urlencoded')
        if result.get('access_token'):
            return result['access_token']
        error = result.get('error')
        if error == 'slow_down':
            delay += 5
        elif error not in ('authorization_pending',):
            raise RuntimeError('Cloudflare authorization: ' + str(error))
    raise RuntimeError('Authorization expired; start again to obtain a new code.')


def api(token, route, method='GET', data=None, content_type=None):
    result = request(BASE + route, method, data, token, content_type)
    if result.get('success') is not True:
        raise RuntimeError('Cloudflare did not confirm the operation.')
    return result.get('result')


def multipart(metadata, directory):
    boundary = 'planner-' + secrets.token_hex(16)
    blocks = []
    def part(name, content, filename=None):
        header = 'Content-Disposition: form-data; name="' + name + '"'
        if filename:
            header += '; filename="' + filename + '"'
        header += '\r\nContent-Type: ' + ('application/javascript+module' if filename else 'application/json')
        blocks.append(('--' + boundary + '\r\n' + header + '\r\n\r\n').encode() + content + b'\r\n')
    part('metadata', json.dumps(metadata).encode())
    for source in sorted(directory.glob('*.js')):
        part(source.name, source.read_bytes(), source.name)
    return b''.join(blocks) + ('--' + boundary + '--\r\n').encode(), 'multipart/form-data; boundary=' + boundary


def deploy(token):
    accounts = api(token, '/accounts')
    if len(accounts) != 1:
        raise RuntimeError('Select one Cloudflare account explicitly before deployment.')
    account_id = accounts[0]['id']
    account = '/accounts/' + account_id
    databases = api(token, account + '/d1/database')
    database = next((item for item in databases if item['name'] == 'planner-data'), None)
    if database is None:
        database = api(token, account + '/d1/database', 'POST', {'name': 'planner-data'})
    database_id = database['uuid']
    query_url = account + '/d1/database/' + database_id + '/query'
    for migration in sorted((ROOT / 'drizzle').glob('*.sql')):
        # Original schema files stay immutable; creation statements are restartable.
        sql = migration.read_text(encoding='utf-8').replace('CREATE TABLE ', 'CREATE TABLE IF NOT EXISTS ').replace('CREATE INDEX ', 'CREATE INDEX IF NOT EXISTS ')
        api(token, query_url, 'POST', {'sql': sql})
    subdomain = api(token, account + '/workers/subdomain').get('subdomain')
    if not subdomain:
        subdomain = 'mikhail-planner-' + account_id[:6]
        api(token, account + '/workers/subdomain', 'PUT', {'subdomain': subdomain})
    script = 'mikhail-planner'
    origin = 'https://' + script + '.' + subdomain + '.workers.dev'
    existing = api(token, account + '/workers/scripts')
    existing_owner = None
    if any(item.get('id') == script for item in existing):
        settings = api(token, account + '/workers/scripts/' + script + '/settings')
        existing_owner = next((item.get('text') for item in settings.get('bindings', []) if item.get('name') == 'OWNER_ID'), None)
    private = ROOT / '.local' / 'independent-owner.json'
    private.parent.mkdir(parents=True, exist_ok=True)
    if private.exists():
        ownership = json.loads(private.read_text(encoding='utf-8'))
        if existing_owner and existing_owner != ownership['owner']:
            raise RuntimeError('This deployment belongs to a different planner. Original data were not changed.')
    else:
        ownership = {'owner': existing_owner or uuid.uuid4().hex, 'key': secrets.token_urlsafe(32)}
        with private.open('x', encoding='utf-8') as output:
            json.dump(ownership, output)
    key_hash = base64.urlsafe_b64encode(hashlib.sha256(ownership['key'].encode()).digest()).decode().rstrip('=')
    metadata = {'main_module': 'independent.js', 'compatibility_date': '2026-11-27',
                'bindings': [{'type': 'd1', 'name': 'DB', 'id': database_id},
                             {'type': 'plain_text', 'name': 'OWNER_ID', 'text': ownership['owner']},
                             {'type': 'plain_text', 'name': 'APP_ORIGIN', 'text': origin}]}
    body, mime = multipart(metadata, ROOT / 'dist' / 'server')
    script_url = account + '/workers/scripts/' + script
    api(token, script_url, 'PUT', body, mime)
    api(token, script_url + '/secrets', 'PUT', {'name': 'OWNER_KEY_HASH', 'type': 'secret_text', 'text': key_hash})
    api(token, script_url + '/subdomain', 'POST', {'enabled': True, 'previews_enabled': False})
    api(token, script_url + '/schedules', 'PUT', [{'cron': '* * * * *'}])
    config = {'name': script, 'main': '../dist/server/independent.js', 'compatibility_date': '2026-11-27',
              'workers_dev': True, 'd1_databases': [{'binding': 'DB', 'database_name': 'planner-data', 'database_id': database_id, 'migrations_dir': '../drizzle'}],
              'vars': {'OWNER_ID': ownership['owner'], 'APP_ORIGIN': origin}, 'triggers': {'crons': ['* * * * *']}}
    (ROOT / 'deploy' / 'wrangler.json').write_text(json.dumps(config, indent=2), encoding='utf-8')
    (ROOT / '.local' / 'deployment.json').write_text(json.dumps({'origin': origin, 'account': account_id, 'database': database_id}), encoding='utf-8')
    recovery = ROOT / '.local' / 'PlannerAccess.txt'
    recovery.write_text('Планер\n\nАдрес: ' + origin + '\nКлюч доступа: ' + ownership['key'] +
                        '\n\nХраните этот файл у себя. Ключ позволяет войти в планер с нового устройства. Не публикуйте его.\n', encoding='utf-8')
    print(json.dumps({'deployed': True, 'origin': origin, 'recovery_file': str(recovery)}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--deploy', action='store_true')
    arguments = parser.parse_args()
    access_token = authenticate()
    print('Cloudflare authorization confirmed.', flush=True)
    if arguments.deploy:
        deploy(access_token)
