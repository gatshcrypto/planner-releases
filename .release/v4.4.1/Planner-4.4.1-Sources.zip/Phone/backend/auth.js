import { hash, encode64 } from './push.js';

const COOKIE = '__Host-planner';
const json = (value, status = 200, headers = {}) => Response.json(value, { status, headers: { 'Cache-Control': 'no-store', ...headers } });
const random = () => encode64(crypto.getRandomValues(new Uint8Array(32)));
const cookie = token => `${COOKIE}=${token}; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=${365 * 86400}`;
function same(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let difference = 0; for (let i = 0; i < a.length; i++) difference |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return difference === 0;
}
function tokenFor(request) {
  const authorization = request.headers.get('Authorization');
  if (authorization) return /^Bearer ([\w-]{43})$/.exec(authorization)?.[1];
  return request.headers.get('Cookie')?.split(';').map(value => value.trim()).find(value => value.startsWith(COOKIE + '='))?.slice(COOKIE.length + 1);
}
export async function authenticate(request, env) {
  const token = tokenFor(request);
  if (!/^[\w-]{43}$/.test(token || '')) return null;
  const session = await env.DB.prepare('SELECT owner FROM planner_sessions WHERE token_hash=? AND expires_at>?').bind(await hash(token), Date.now()).first();
  return session?.owner || null;
}
async function session(env, owner, native) {
  const token = random();
  await env.DB.prepare('DELETE FROM planner_sessions WHERE expires_at<=?').bind(Date.now()).run();
  await env.DB.prepare('INSERT INTO planner_sessions(token_hash,owner,expires_at) VALUES (?,?,?)').bind(await hash(token), owner, Date.now() + 365 * 86400000).run();
  // The normal web login keeps its session in an HttpOnly cookie.
  return json(native ? { token, user: owner } : { user: owner }, 200, { 'Set-Cookie': cookie(token) });
}
export async function authRoute(request, env) {
  const url = new URL(request.url);
  if (request.method !== 'GET' && request.headers.get('Origin') && request.headers.get('Origin') !== url.origin) return json({ error: 'Недопустимый источник запроса.' }, 403);
  if (!env.DB || !env.OWNER_ID || !env.OWNER_KEY_HASH) return json({ error: 'Синхронизация ещё не настроена.' }, 503);
  const owner = await authenticate(request, env);
  if (url.pathname === '/api/auth/session' && request.method === 'GET') return json({ authenticated: !!owner, user: owner });
  if (request.method !== 'POST') return json({ error: 'Действие недоступно.' }, 405);
  if (Number(request.headers.get('Content-Length')) > 2048) return json({ error: 'Слишком большой запрос.' }, 413);
  let body;
  try {
    const reader = request.body?.getReader(); if (!reader) return json({ error: 'Ожидается JSON.' }, 400);
    const chunks = []; let size = 0;
    while (true) { const part = await reader.read(); if (part.done) break; size += part.value.length;
      if (size > 2048) { await reader.cancel(); return json({ error: 'Слишком большой запрос.' }, 413); } chunks.push(part.value); }
    const bytes = new Uint8Array(size); let offset = 0; for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
    if (!request.headers.get('Content-Type')?.includes('application/json')) return json({ error: 'Ожидается JSON.' }, 415);
    body = JSON.parse(new TextDecoder().decode(bytes));
  } catch { return json({ error: 'Проверьте данные.' }, 400); }
  if (url.pathname === '/api/auth/login') {
    if (!/^[\w-]{43}$/.test(body.key || '') || !same(await hash(body.key), env.OWNER_KEY_HASH)) return json({ error: 'Неверный ключ доступа.' }, 401);
    return session(env, env.OWNER_ID, false);
  }
  if (!owner && url.pathname !== '/api/auth/exchange') return json({ error: 'Войдите в планер.' }, 401);
  if (url.pathname === '/api/auth/pair') {
    const code = random();
    await env.DB.prepare('DELETE FROM planner_pairings WHERE expires_at<=?').bind(Date.now()).run();
    await env.DB.prepare('INSERT INTO planner_pairings(code_hash,owner,expires_at) VALUES (?,?,?)').bind(await hash(code), owner, Date.now() + 600000).run();
    return json({ code, expiresIn: 600 });
  }
  if (url.pathname === '/api/auth/exchange') {
    if (!/^[\w-]{43}$/.test(body.code || '')) return json({ error: 'Неверный код подключения.' }, 401);
    // DELETE RETURNING makes the code single-use even with simultaneous requests.
    const pairing = await env.DB.prepare('DELETE FROM planner_pairings WHERE code_hash=? AND expires_at>? RETURNING owner').bind(await hash(body.code), Date.now()).first();
    if (!pairing) return json({ error: 'Код использован или истёк. Создайте новый.' }, 401);
    return session(env, pairing.owner, !!body.native);
  }
  if (url.pathname === '/api/auth/logout') {
    await env.DB.prepare('DELETE FROM planner_sessions WHERE token_hash=?').bind(await hash(tokenFor(request))).run();
    return json({ signedOut: true }, 200, { 'Set-Cookie': `${COOKIE}=; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=0` });
  }
  return json({ error: 'Действие недоступно.' }, 404);
}
