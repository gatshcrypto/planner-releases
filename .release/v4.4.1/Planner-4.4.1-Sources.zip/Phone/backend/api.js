import { emptyState, validateState } from './domain.js';
import { generateKeys, sendPush, hash, validSubscription } from './push.js';

const json = (body, status = 200) => Response.json(body, { status, headers: { 'Cache-Control': 'no-store' } });
async function readBody(request, maximum = 2000000) {
  if (!request.headers.get('Content-Type')?.includes('application/json')) throw new Error('Ожидается JSON.');
  const reader = request.body?.getReader(); if (!reader) throw new Error('Отсутствуют данные.');
  const chunks = []; let size = 0;
  while (true) {
    const { done, value } = await reader.read(); if (done) break;
    size += value.length;
    if (size > maximum) { await reader.cancel(); throw new Error('Слишком большой объём данных.'); }
    chunks.push(value);
  }
  const merged = new Uint8Array(size); let position = 0;
  for (const chunk of chunks) { merged.set(chunk, position); position += chunk.length; }
  return JSON.parse(new TextDecoder().decode(merged));
}
async function keysFor(db) {
  let row = await db.prepare('SELECT body FROM planner_keys WHERE name=?').bind('vapid').first();
  if (!row) {
    const keys = await generateKeys();
    await db.prepare('INSERT OR IGNORE INTO planner_keys(name,body) VALUES (?,?)').bind('vapid', JSON.stringify(keys)).run();
    row = await db.prepare('SELECT body FROM planner_keys WHERE name=?').bind('vapid').first();
  }
  return JSON.parse(row.body);
}
async function documentFor(db, owner) {
  const row = await db.prepare('SELECT revision,body FROM planner_documents WHERE owner=?').bind(owner).first();
  return { user: owner, revision: row?.revision || 0, state: row ? JSON.parse(row.body) : emptyState() };
}
async function pushToOwner(db, owner, payload, origin) {
  const { results } = await db.prepare('SELECT id,body FROM planner_subscriptions WHERE owner=?').bind(owner).all();
  if (!results.length) return 0;
  const keys = await keysFor(db); let delivered = 0;
  for (const subscription of results) {
    const response = await sendPush(JSON.parse(subscription.body), payload, keys, origin);
    if ([404, 410].includes(response.status)) await db.prepare('DELETE FROM planner_subscriptions WHERE id=?').bind(subscription.id).run();
    else if (response.ok) delivered++;
  }
  return delivered;
}
export async function dispatchReminders(env, origin) {
  const db = env.DB;
  if (!db) throw new Error('Хранилище недоступно.');
  const now = Date.now();
  const { results } = await db.prepare('SELECT owner,body FROM planner_documents').all();
  let delivered = 0;
  for (const document of results) {
    const state = JSON.parse(document.body);
    const reminders = state.entries.filter(entry => ['task', 'event'].includes(entry.kind) && !entry.checked && entry.reminderAt &&
      Date.parse(entry.reminderAt) <= now && Date.parse(entry.reminderAt) > now - 24 * 3600000);
    const timer = state.settings.pomodoro;
    if (timer?.endsAt && timer.endsAt <= now && timer.endsAt > now - 3600000 && !timer.notified) reminders.push({
      id: 'pomodoro', title: timer.mode === 'focus' ? 'Фокус завершён' : 'Перерыв завершён', reminderAt: new Date(timer.endsAt).toISOString()
    });
    for (const reminder of reminders) {
      if (delivered >= 20) break;
      const deliveryId = await hash(`${document.owner}:${reminder.id}:${reminder.reminderAt}`);
      const claim = await db.prepare(`INSERT INTO planner_deliveries(id,state,lease_until,updated_at) VALUES (?,'sending',?,?)
        ON CONFLICT(id) DO UPDATE SET state='sending',lease_until=excluded.lease_until,updated_at=excluded.updated_at
        WHERE planner_deliveries.state<>'sent' AND planner_deliveries.lease_until<?`).bind(deliveryId, now + 90000, new Date(now).toISOString(), now).run();
      if (!claim.meta.changes) continue;
      try {
        const count = await pushToOwner(db, document.owner, { title: reminder.title.slice(0, 220), body: reminder.id === 'pomodoro' ? 'Помодоро' : 'Напоминание планера', tag: deliveryId, entryId: reminder.id }, origin);
        await db.prepare('UPDATE planner_deliveries SET state=?,lease_until=?,updated_at=? WHERE id=?')
          .bind(count ? 'sent' : 'waiting', count ? 0 : now + 60000, new Date().toISOString(), deliveryId).run();
        if (count) delivered++;
      } catch {
        await db.prepare("UPDATE planner_deliveries SET state='waiting',lease_until=? WHERE id=?").bind(now + 60000, deliveryId).run();
      }
    }
  }
  await db.prepare('INSERT INTO planner_keys(name,body) VALUES (?,?) ON CONFLICT(name) DO UPDATE SET body=excluded.body')
    .bind('last-dispatch', JSON.stringify({ at: new Date().toISOString(), delivered })).run();
  return { delivered };
}
export async function api(request, env) {
  const url = new URL(request.url), owner = request.headers.get('oai-authenticated-user-id');
  if (request.method !== 'GET' && request.headers.get('Origin') && request.headers.get('Origin') !== url.origin) return json({ error: 'Недопустимый источник запроса.' }, 403);
  if (!env.DB) return json({ error: 'Хранилище временно недоступно.' }, 503);
  if (url.pathname === '/api/health' && request.method === 'GET') {
    const last = await env.DB.prepare('SELECT body FROM planner_keys WHERE name=?').bind('last-dispatch').first();
    return json({ database: true, lastDispatch: last ? JSON.parse(last.body) : null });
  }
  if (url.pathname === '/api/dispatch' && request.method === 'POST') return json(await dispatchReminders(env, url.origin));
  if (!owner) return json({ error: 'Войдите в планер.' }, 401);
  try {
    if (url.pathname === '/api/state' && request.method === 'GET') return json(await documentFor(env.DB, owner));
    if (url.pathname === '/api/state' && request.method === 'PUT') {
      const body = await readBody(request);
      if (!Number.isSafeInteger(body.revision) || body.revision < 0) return json({ error: 'Некорректная версия данных.' }, 400);
      validateState(body.state);
      const current = await documentFor(env.DB, owner);
      if (current.revision !== body.revision) return json(current, 409);
      const result = await env.DB.prepare(`INSERT INTO planner_documents(owner,revision,body,updated_at) VALUES (?,1,?,?)
        ON CONFLICT(owner) DO UPDATE SET revision=planner_documents.revision+1,body=excluded.body,updated_at=excluded.updated_at
        WHERE planner_documents.revision=?`).bind(owner, JSON.stringify(body.state), new Date().toISOString(), body.revision).run();
      if (!result.meta.changes) return json(await documentFor(env.DB, owner), 409);
      return json({ revision: body.revision + 1 });
    }
    if (url.pathname === '/api/push/key' && request.method === 'GET') return json({ publicKey: (await keysFor(env.DB)).publicKey });
    if (url.pathname === '/api/push/subscribe' && request.method === 'POST') {
      const subscription = await readBody(request, 10000);
      if (!validSubscription(subscription)) return json({ error: 'Проверьте подписку.' }, 400);
      const subscriptionId = await hash(subscription.endpoint);
      await env.DB.prepare(`INSERT INTO planner_subscriptions(id,owner,body,created_at) VALUES (?,?,?,?)
        ON CONFLICT(id) DO UPDATE SET owner=excluded.owner,body=excluded.body`).bind(subscriptionId, owner, JSON.stringify(subscription), new Date().toISOString()).run();
      return json({ subscribed: true });
    }
    if (url.pathname === '/api/push/test' && request.method === 'POST') {
      const count = await pushToOwner(env.DB, owner, { title: 'Планер', body: 'Уведомления подключены', tag: 'planner-test' }, url.origin);
      return count ? json({ sent: count }) : json({ error: 'Сначала включите уведомления на этом устройстве.' }, 400);
    }
    if (url.pathname === '/api/push/status' && request.method === 'GET') {
      const row = await env.DB.prepare('SELECT body FROM planner_keys WHERE name=?').bind('last-dispatch').first();
      return json({ lastDispatch: row ? JSON.parse(row.body) : null });
    }
    return json({ error: 'Раздел не найден.' }, 404);
  } catch (error) {
    if (error instanceof SyntaxError || /Укажите|Проверьте|Некоррект|сумм|формат|идентификатор|категори|счёт|Отсутствуют|Ожидается|данных|подцели|записи|напоминание|название|дата|дату|история/i.test(error.message)) return json({ error: error.message }, 400);
    console.error('Planner API failed', error.name);
    return json({ error: 'Не удалось сохранить данные. Повторите позже.' }, 500);
  }
}
