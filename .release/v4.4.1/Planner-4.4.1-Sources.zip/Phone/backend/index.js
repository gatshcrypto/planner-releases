import { api } from './api.js';
import { assets } from './assets.js';

const headers = {
  'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()'
};
const decoded = new Map();
function bytesFor(path, item) {
  if (!decoded.has(path)) {
    let bytes;
    if (typeof Uint8Array.fromBase64 === 'function') bytes = Uint8Array.fromBase64(item.body);
    else { const raw = atob(item.body); bytes = new Uint8Array(raw.length); for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i); }
    decoded.set(path, bytes);
  }
  return decoded.get(path);
}
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith('/api/')) return api(request, env);
    if (!['GET', 'HEAD'].includes(request.method)) return new Response('Method not allowed', { status: 405 });
    const item = assets[url.pathname === '/' ? '/index.html' : url.pathname];
    if (!item) return new Response('Not found', { status: 404, headers });
    const body = bytesFor(url.pathname, item);
    return new Response(request.method === 'HEAD' ? null : body, { headers: { ...headers,
      'Content-Type': item.type, 'Cache-Control': url.pathname === '/sw.js' || url.pathname === '/' || url.pathname.endsWith('.html') ? 'no-cache' : 'public,max-age=0,must-revalidate',
      'Service-Worker-Allowed': '/'
    } });
  }
};
