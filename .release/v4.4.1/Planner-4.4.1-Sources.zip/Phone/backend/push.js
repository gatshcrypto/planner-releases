const encoder = new TextEncoder();
export function encode64(bytes) { return btoa(String.fromCharCode(...new Uint8Array(bytes))).replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/, ''); }
export function decode64(value) { return Uint8Array.from(atob(value.replaceAll('-', '+').replaceAll('_', '/')), char => char.charCodeAt(0)); }
function concat(...arrays) {
  const result = new Uint8Array(arrays.reduce((sum, array) => sum + array.byteLength, 0));
  let offset = 0; for (const array of arrays) { result.set(new Uint8Array(array), offset); offset += array.byteLength; }
  return result;
}
async function hkdf(input, salt, info, length) {
  const key = await crypto.subtle.importKey('raw', input, 'HKDF', false, ['deriveBits']);
  return new Uint8Array(await crypto.subtle.deriveBits({ name: 'HKDF', hash: 'SHA-256', salt, info }, key, length * 8));
}
export async function generateKeys() {
  const pair = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
  return { publicKey: encode64(await crypto.subtle.exportKey('raw', pair.publicKey)), privateKey: await crypto.subtle.exportKey('jwk', pair.privateKey) };
}
export async function encryptedPayload(subscription, payload) {
  const receiver = decode64(subscription.keys.p256dh), authentication = decode64(subscription.keys.auth);
  const pair = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
  const sender = new Uint8Array(await crypto.subtle.exportKey('raw', pair.publicKey));
  const receiverKey = await crypto.subtle.importKey('raw', receiver, { name: 'ECDH', namedCurve: 'P-256' }, false, []);
  const shared = await crypto.subtle.deriveBits({ name: 'ECDH', public: receiverKey }, pair.privateKey, 256);
  const input = await hkdf(shared, authentication, concat(encoder.encode('WebPush: info\0'), receiver, sender), 32);
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const keyBytes = await hkdf(input, salt, encoder.encode('Content-Encoding: aes128gcm\0'), 16);
  const nonce = await hkdf(input, salt, encoder.encode('Content-Encoding: nonce\0'), 12);
  const key = await crypto.subtle.importKey('raw', keyBytes, 'AES-GCM', false, ['encrypt']);
  const plain = concat(encoder.encode(JSON.stringify(payload)), new Uint8Array([2]));
  if (plain.length > 3900) throw new Error('Уведомление слишком длинное.');
  const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: nonce }, key, plain);
  const header = new Uint8Array(5); new DataView(header.buffer).setUint32(0, 4096); header[4] = sender.length;
  return concat(salt, header, sender, encrypted);
}
export function validSubscription(subscription) {
  if (!subscription?.endpoint || typeof subscription.endpoint !== 'string' || subscription.endpoint.length > 3000) return false;
  const url = new URL(subscription.endpoint);
  const allowed = ['push.apple.com', 'push.services.mozilla.com', 'fcm.googleapis.com', 'notify.windows.com'];
  return url.protocol === 'https:' && !url.username && !url.password && (!url.port || url.port === '443') &&
    allowed.some(domain => url.hostname === domain || url.hostname.endsWith('.' + domain)) &&
    typeof subscription.keys?.p256dh === 'string' && /^[A-Za-z0-9_-]+={0,2}$/.test(subscription.keys.p256dh) &&
    decode64(subscription.keys.p256dh).length === 65 && typeof subscription.keys?.auth === 'string' &&
    /^[A-Za-z0-9_-]+={0,2}$/.test(subscription.keys.auth) && decode64(subscription.keys.auth).length === 16;
}
export async function sendPush(subscription, payload, keys, origin, sender = fetch) {
  if (!validSubscription(subscription)) throw new Error('Некорректная подписка.');
  const audience = new URL(subscription.endpoint).origin;
  const header = encode64(encoder.encode(JSON.stringify({ typ: 'JWT', alg: 'ES256' })));
  const claims = encode64(encoder.encode(JSON.stringify({ aud: audience, exp: Math.floor(Date.now() / 1000) + 21600, sub: origin })));
  const unsigned = `${header}.${claims}`;
  const key = await crypto.subtle.importKey('jwk', keys.privateKey, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
  const signature = await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, key, encoder.encode(unsigned));
  const token = `${unsigned}.${encode64(signature)}`;
  const body = await encryptedPayload(subscription, payload);
  return sender(subscription.endpoint, { method: 'POST', redirect: 'error', headers: {
    Authorization: `vapid t=${token}, k=${keys.publicKey}`, TTL: '3600', Urgency: 'normal',
    'Content-Encoding': 'aes128gcm', 'Content-Type': 'application/octet-stream'
  }, body, signal: AbortSignal.timeout(15000) });
}
export async function hash(value) { return encode64(await crypto.subtle.digest('SHA-256', encoder.encode(value))); }
