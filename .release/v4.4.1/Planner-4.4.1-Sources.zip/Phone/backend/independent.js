import siteWorker from './index.js';
import { authRoute, authenticate } from './auth.js';
import { dispatchReminders } from './api.js';

export default {
  async fetch(request, env, context) {
    const url = new URL(request.url);
    if (url.pathname.startsWith('/api/auth/')) return authRoute(request, env);
    if (url.pathname.startsWith('/api/')) {
      // Dispatch is a scheduled server action, never an anonymous public endpoint.
      if (url.pathname === '/api/dispatch' || url.pathname === '/api/health') return new Response('Not found', { status: 404 });
      const owner = await authenticate(request, env);
      if (!owner) return Response.json({ error: 'Войдите в планер.', code: 'sign_in_required' }, { status: 401, headers: { 'Cache-Control': 'no-store' } });
      const authenticated = new Request(request); authenticated.headers.set('oai-authenticated-user-id', owner);
      return siteWorker.fetch(authenticated, env, context);
    }
    return siteWorker.fetch(request, env, context);
  },
  async scheduled(controller, env, context) {
    context.waitUntil(dispatchReminders(env, env.APP_ORIGIN));
  }
};
