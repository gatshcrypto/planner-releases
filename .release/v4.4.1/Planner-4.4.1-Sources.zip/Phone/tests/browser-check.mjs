import { createRequire } from 'node:module';
import fs from 'node:fs/promises';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLANNER_PLAYWRIGHT_MODULE || 'playwright');
const browser = await chromium.launch({ headless: true, executablePath: process.env.PLANNER_BROWSER || undefined });
await fs.mkdir('.local/screens', { recursive: true });
const context = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 1, reducedMotion: 'reduce' });
const page = await context.newPage();
const errors = [];
page.on('pageerror', error => errors.push(error.message));
page.on('console', message => { if (message.type() === 'error') console.log('Browser', message.text()); });
try {
  await page.goto('http://127.0.0.1:4317/?test=1');
  await page.waitForFunction(() => window.plannerApp?.ready);
  await page.screenshot({ path: '.local/screens/tasks-empty.png', fullPage: true });
  console.log('Ready', await page.locator('h1').textContent());
  await page.locator('#add-button').click();
  await page.getByLabel('Название', { exact: true }).fill('Проверить мобильный планер');
  await page.getByRole('button', { name: 'Сохранить', exact: true }).click();
  await page.waitForSelector('.task-row');
  console.log('Task saved');
  await page.screenshot({ path: '.local/screens/tasks.png', fullPage: true });
  console.log('Errors', JSON.stringify(errors));
  console.log('Overflow', await page.evaluate(() => document.documentElement.scrollWidth > innerWidth));
} finally { await browser.close(); }
