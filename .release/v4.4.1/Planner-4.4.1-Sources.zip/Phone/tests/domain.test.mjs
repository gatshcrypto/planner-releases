import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { emptyState, saveEntry, toggleEntry, children, progress, canComplete, addPeriod, shiftDate, habitStreak, markHabit,
  parseMoney, money, totals, balance, saveOperation, mergeStates, removeEntry, validateState } from '../web/domain.js';
import { calculate } from '../web/calculator.js';

function planningFixture() {
  const state = emptyState();
  const goal = saveEntry(state, { kind: 'goal', title: 'Цель', day: '2026-11-27', period: 'month' });
  const step = saveEntry(state, { kind: 'subgoal', title: 'Подцель', parentId: goal.id });
  const task = saveEntry(state, { kind: 'task', title: 'Задача', day: '2026-11-27', parentId: step.id });
  return { state, goal, step, task };
}
test('Сроки от даты старта и календарные границы', () => {
  assert.equal(addPeriod('2026-11-27', 'week'), '2026-12-04');
  assert.equal(addPeriod('2026-01-31', 'month'), '2026-02-28');
  assert.equal(addPeriod('2028-02-29', 'year'), '2029-02-28');
  assert.equal(shiftDate('2026-12-31', 1), '2027-01-01');
});
test('Задачи, подцели и цели пересчитываются после снятия отметки', () => {
  const { state, goal, step, task } = planningFixture();
  assert.equal(canComplete(state, step), false);
  toggleEntry(state, task.id);
  assert.equal(progress(state, goal).percent, 100);
  assert.equal(canComplete(state, step), true);
  assert.equal(state.entries.find(item => item.id === step.id).checked, undefined);
  toggleEntry(state, step.id);
  assert.equal(state.entries.find(item => item.id === step.id).checked, true);
  toggleEntry(state, task.id);
  assert.equal(state.entries.find(item => item.id === step.id).checked, false);
  assert.equal(progress(state, goal).percent, 0);
});
test('Новая задача не привязывается к подтверждённой подцели', () => {
  const { state, step, task } = planningFixture();
  toggleEntry(state, task.id); toggleEntry(state, step.id);
  assert.throws(() => saveEntry(state, { kind: 'task', title: 'Новая', day: '2026-11-28', parentId: step.id }));
  assert.doesNotThrow(() => saveEntry(state, { ...state.entries.find(item => item.id === task.id), title: 'Правка старой' }));
});
test('Перенос задачи сохраняет связь и выполнение', () => {
  const { state, step, task } = planningFixture(); toggleEntry(state, task.id);
  const updated = saveEntry(state, { ...state.entries.find(item => item.id === task.id), day: '2026-12-01' });
  assert.equal(updated.parentId, step.id); assert.equal(updated.checked, true);
});
test('Обязательная дата задачи и родитель подцели', () => {
  assert.throws(() => saveEntry(emptyState(), { kind: 'task', title: 'Без даты' }));
  assert.throws(() => saveEntry(emptyState(), { kind: 'subgoal', title: 'Без цели' }));
});
test('Удаление цели затрагивает её связи, остальные записи остаются', () => {
  const { state, goal } = planningFixture();
  const free = saveEntry(state, { kind: 'task', title: 'Самостоятельная', day: '2026-11-27' });
  removeEntry(state, goal.id); assert.deepEqual(state.entries.map(item => item.id), [free.id]);
});
test('Серия привычки 62 и 63 дня, пропуск и сегодняшняя незавершённость', () => {
  const habit = { id: 'habit1', marks: Array.from({ length: 62 }, (_, index) => shiftDate('2026-09-26', index)) };
  assert.equal(habitStreak(habit, '2026-11-26'), 62);
  assert.equal(markHabit(habit, '2026-11-27'), true);
  assert.equal(habit.mastered, '2026-11-27');
  assert.equal(markHabit(habit, '2026-11-27'), false);
  assert.equal(habitStreak({ marks: ['2026-11-25'] }, '2026-11-26'), 1);
  assert.equal(habitStreak({ marks: ['2026-11-25'] }, '2026-11-27'), 0);
  const restarted = { marks: ['2026-11-25'] }; markHabit(restarted, '2026-11-27'); assert.equal(habitStreak(restarted, '2026-11-27'), 1);
});
test('Рубли и копейки сохраняются без ошибок с плавающей точкой', () => {
  assert.equal(parseMoney('10000,25'), '1000025'); assert.equal(parseMoney('−1'.replace('−', '-'), true), '-100');
  assert.equal(parseMoney('0,01'), '1'); assert.equal(parseMoney('500'), '50000');
  assert.equal(money(1000025).replaceAll('\u00a0', ' ').replaceAll('\u202f', ' '), '10 000,25 ₽');
  assert.throws(() => parseMoney('10.255')); assert.throws(() => parseMoney('-1'));
});
test('Перевод на кредитку уменьшает остаток и долг без дохода или расхода', () => {
  const state = emptyState();
  state.accounts = [{ id: 'card', name: 'Карта', opening: '500000' }, { id: 'credit', name: 'Кредитка', opening: '-2000000' }];
  state.categories = [{ id: 'salary', name: 'Работа', kind: 'income' }, { id: 'food', name: 'Еда', kind: 'expense' }];
  saveOperation(state, { kind: 'income', accountId: 'card', categoryId: 'salary', day: '2026-11-27', amount: '1000025' });
  saveOperation(state, { kind: 'expense', accountId: 'card', categoryId: 'food', day: '2026-11-27', amount: '120075' });
  saveOperation(state, { kind: 'transfer', accountId: 'card', destinationId: 'credit', day: '2026-11-27', amount: '500000' });
  assert.equal(balance(state, state.accounts[0], '2026-11-27'), 879950n);
  assert.equal(balance(state, state.accounts[1], '2026-11-27'), -1500000n);
  assert.deepEqual(totals(state.operations), { income: 1000025n, expense: 120075n, net: 879950n });
  assert.throws(() => saveOperation(state, { kind: 'transfer', accountId: 'card', destinationId: 'card', day: '2026-11-27', amount: '100' }));
});
test('Архивная категория сохраняется у прежней операции и скрыта для новых', () => {
  const state = emptyState(); state.accounts = [{ id: 'card', name: 'Карта', opening: '0' }];
  state.categories = [{ id: 'food', name: 'Еда', kind: 'expense' }];
  const original = saveOperation(state, { kind: 'expense', accountId: 'card', categoryId: 'food', day: '2026-11-27', amount: '100' });
  state.categories[0].archived = true;
  assert.throws(() => saveOperation(state, { kind: 'expense', accountId: 'card', categoryId: 'food', day: '2026-11-27', amount: '100' }));
  assert.doesNotThrow(() => saveOperation(state, { ...original, notes: 'Правка' }));
});
test('Калькулятор точно считает приоритет операций и округляет до копеек', () => {
  assert.equal(calculate('1000+250,50×2'), '1501,00');
  assert.equal(calculate('(100+50)/3'), '50,00');
  assert.equal(calculate('0.1+0.2'), '0,30');
  assert.equal(calculate('1/8'), '0,13');
  assert.equal(calculate('-1/8'), '-0,13');
  assert.throws(() => calculate('1/0')); assert.throws(() => calculate('1+'));
});
test('Одновременные изменения разных записей объединяются', () => {
  const base = emptyState(), local = emptyState(), remote = emptyState();
  saveEntry(local, { kind: 'task', title: 'Телефон', day: '2026-11-27' });
  saveEntry(remote, { kind: 'task', title: 'Компьютер', day: '2026-11-27' });
  const result = mergeStates(base, local, remote);
  assert.equal(result.state.entries.length, 2); assert.equal(result.conflicts.length, 0);
});
test('Конфликт одной записи определяется, отмена удаления возвращает запись', () => {
  const { state: base, task } = planningFixture();
  const local = structuredClone(base), remote = structuredClone(base);
  local.entries.find(item => item.id === task.id).title = 'Телефон';
  remote.entries.find(item => item.id === task.id).title = 'Компьютер';
  assert.equal(mergeStates(base, local, remote).conflicts.length, 1);
  const deleted = structuredClone(base); removeEntry(deleted, task.id);
  const restored = mergeStates(deleted, base, deleted);
  assert.equal(restored.state.entries.some(item => item.id === task.id), true);
  assert.equal(restored.state.deleted[task.id], undefined);
});
test('Повторяющиеся ID и циклические связи отвергаются', () => {
  const { state, goal, task } = planningFixture();
  const duplicate = structuredClone(state); duplicate.entries.push(duplicate.entries[0]); assert.throws(() => validateState(duplicate));
  state.entries.find(item => item.id === goal.id).parentId = task.id; assert.throws(() => validateState(state));
});
test('Удалённая запись при конфликте не стирает локальную правку до выбора пользователя', () => {
  const { state: base, task } = planningFixture();
  const local = structuredClone(base), remote = structuredClone(base);
  local.entries.find(item => item.id === task.id).title = 'Сохранить мою правку';
  removeEntry(remote, task.id);
  const merged = mergeStates(base, local, remote);
  assert.equal(merged.conflicts.length, 1);
  assert.equal(merged.state.entries.find(item => item.id === task.id).title, 'Сохранить мою правку');
  assert.equal(merged.state.deleted[task.id], undefined);
});
test('Реальный экспорт Windows читается с сохранением связей и копеек', () => {
  if (!fs.existsSync('.local/windows-export.json')) return;
  const { state } = JSON.parse(fs.readFileSync('.local/windows-export.json', 'utf8'));
  validateState(state); assert.equal(state.operations.length, 3); assert.equal(state.accounts.length, 2);
  assert.ok(state.entries.some(item => item.kind === 'subgoal' && item.parentId));
});
