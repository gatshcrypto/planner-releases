import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { DatabaseSync } from 'node:sqlite';
import { api, dispatchReminders } from '../dist/server/api.js';
import { emptyState } from '../web/domain.js';
import { encryptedPayload, decode64, encode64, generateKeys, sendPush } from '../dist/server/push.js';
import { createECDH, hkdfSync, createDecipheriv, createPublicKey, verify } from 'node:crypto';

function database() {
  const database = new DatabaseSync(':memory:'); database.exec(fs.readFileSync('drizzle/0000_phone.sql', 'utf8'));
  const DB = { prepare(sql) {
    let parameters = [];
    const statement = { bind(...values) { parameters = values; return statement; }, async first() { return database.prepare(sql).get(...parameters); },
      async all() { return { results: database.prepare(sql).all(...parameters) }; }, async run() { return { meta: { changes: Number(database.prepare(sql).run(...parameters).changes) } }; } };
    return statement;
  } };
  return { DB, database };
}
function request(path, method = 'GET', body = null, owner = 'owner') {
  return new Request('https://planner.test' + path, { method, headers: { ...(owner ? { 'oai-authenticated-user-id': owner } : {}),
    ...(body ? { 'Content-Type': 'application/json' } : {}) }, ...(body ? { body: JSON.stringify(body) } : {}) });
}
test('Сервер требует вход и разделяет данные пользователей', async () => {
  const env = database();
  assert.equal((await api(request('/api/state', 'GET', null, null), env)).status, 401);
  const state = emptyState(); state.settings.theme = 'ocean';
  assert.equal((await api(request('/api/state', 'PUT', { revision: 0, state }), env)).status, 200);
  const own = await (await api(request('/api/state'), env)).json();
  const other = await (await api(request('/api/state', 'GET', null, 'another'), env)).json();
  assert.equal(own.state.settings.theme, 'ocean'); assert.equal(other.state.settings.theme, 'emerald');
  assert.equal(other.revision, 0); env.database.close();
});
test('Старая версия не перезаписывает новые данные', async () => {
  const env = database(), state = emptyState();
  await api(request('/api/state', 'PUT', { revision: 0, state }), env);
  state.settings.theme = 'winter'; await api(request('/api/state', 'PUT', { revision: 1, state }), env);
  const stale = emptyState(); stale.settings.theme = 'summer';
  const response = await api(request('/api/state', 'PUT', { revision: 1, state: stale }), env);
  assert.equal(response.status, 409); assert.equal((await response.json()).state.settings.theme, 'winter'); env.database.close();
});
test('Чужой Origin и повреждённые данные отклоняются', async () => {
  const env = database(), state = emptyState();
  const cross = request('/api/state', 'PUT', { revision: 0, state }); cross.headers.set('Origin', 'https://another.test');
  assert.equal((await api(cross, env)).status, 403);
  const response = await api(request('/api/state', 'PUT', { revision: 0, state: { schema: 99 } }), env);
  assert.equal(response.status, 400); assert.equal((await (await api(request('/api/state'), env)).json()).revision, 0); env.database.close();
});
test('Ключ уведомлений сохраняется, приватный ключ не отдаётся браузеру', async () => {
  const env = database();
  const first = await (await api(request('/api/push/key'), env)).json();
  const second = await (await api(request('/api/push/key'), env)).json();
  assert.equal(first.publicKey, second.publicKey); assert.deepEqual(Object.keys(first), ['publicKey']); env.database.close();
});
test('Подписки на произвольные адреса не принимаются', async () => {
  const env = database();
  const response = await api(request('/api/push/subscribe', 'POST', { endpoint: 'https://localhost/private', keys: { p256dh: 'x', auth: 'x' } }), env);
  assert.equal(response.status, 400); env.database.close();
});
test('Web Push расшифровывается независимой реализацией Node crypto', async () => {
  const receiver = createECDH('prime256v1'); receiver.generateKeys();
  const auth = crypto.getRandomValues(new Uint8Array(16));
  const subscription = { endpoint: 'https://web.push.apple.com/example', keys: { p256dh: encode64(receiver.getPublicKey()), auth: encode64(auth) } };
  const payload = { title: 'Проверка', body: 'Событие', entryId: 'example' };
  const encrypted = Buffer.from(await encryptedPayload(subscription, payload));
  const salt = encrypted.subarray(0, 16), sender = encrypted.subarray(21, 21 + encrypted[20]);
  const shared = receiver.computeSecret(sender);
  const information = Buffer.concat([Buffer.from('WebPush: info\0'), receiver.getPublicKey(), sender]);
  const ikm = hkdfSync('sha256', shared, auth, information, 32);
  const key = hkdfSync('sha256', ikm, salt, Buffer.from('Content-Encoding: aes128gcm\0'), 16);
  const nonce = hkdfSync('sha256', ikm, salt, Buffer.from('Content-Encoding: nonce\0'), 12);
  const cipher = encrypted.subarray(21 + encrypted[20]);
  const decipher = createDecipheriv('aes-128-gcm', key, nonce); decipher.setAuthTag(cipher.subarray(-16));
  const plain = Buffer.concat([decipher.update(cipher.subarray(0, -16)), decipher.final()]);
  assert.equal(plain.at(-1), 2); assert.deepEqual(JSON.parse(plain.subarray(0, -1)), payload);
});
test('Подпись VAPID проверяется независимо и запрос не следует перенаправлению', async () => {
  const receiver = createECDH('prime256v1'); receiver.generateKeys(); const keys = await generateKeys();
  const subscription = { endpoint: 'https://web.push.apple.com/example', keys: { p256dh: encode64(receiver.getPublicKey()), auth: encode64(crypto.getRandomValues(new Uint8Array(16))) } };
  await sendPush(subscription, { title: 'Проверка' }, keys, 'https://planner.test', async (url, options) => {
    assert.equal(options.redirect, 'error');
    const jwt = options.headers.Authorization.match(/t=([^,]+)/)[1];
    const [header, body, signature] = jwt.split('.');
    const jwk = { ...keys.privateKey }; delete jwk.d;
    assert.equal(verify('sha256', Buffer.from(`${header}.${body}`), { key: createPublicKey({ key: jwk, format: 'jwk' }), dsaEncoding: 'ieee-p1363' }, decode64(signature)), true);
    assert.equal(JSON.parse(Buffer.from(decode64(body))).aud, 'https://web.push.apple.com');
    return new Response(null, { status: 201 });
  });
});
test('Проверка напоминаний без подписок сохраняет состояние очереди', async () => {
  const env = database(), state = emptyState();
  state.entries.push({ id: 'task1', kind: 'task', title: 'Напоминание', day: '2026-11-27', reminderAt: new Date(Date.now() - 60000).toISOString() });
  await api(request('/api/state', 'PUT', { revision: 0, state }), env);
  const result = await dispatchReminders(env, 'https://planner.test');
  assert.equal(result.delivered, 0);
  assert.equal(env.database.prepare('SELECT state FROM planner_deliveries').get().state, 'waiting');
  assert.ok(env.database.prepare("SELECT body FROM planner_keys WHERE name='last-dispatch'").get()); env.database.close();
});
