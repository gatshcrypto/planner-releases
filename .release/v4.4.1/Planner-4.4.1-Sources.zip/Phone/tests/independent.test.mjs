import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { DatabaseSync } from 'node:sqlite';
import worker from '../dist/server/independent.js';
import { hash } from '../dist/server/push.js';
import { emptyState, saveEntry } from '../web/domain.js';

const recovery = 'a'.repeat(43);
async function fixture() {
  const database = new DatabaseSync(':memory:');
  for (const file of ['0000_phone.sql', '0001_independent_auth.sql']) database.exec(fs.readFileSync('drizzle/' + file, 'utf8'));
  const DB = { prepare(sql) {
    let parameters = [];
    const statement = { bind(...values) { parameters = values; return statement; }, async first() { return database.prepare(sql).get(...parameters); },
      async all() { return { results: database.prepare(sql).all(...parameters) }; }, async run() { return { meta: { changes: Number(database.prepare(sql).run(...parameters).changes) } }; } }; return statement;
  } };
  const env = { DB, OWNER_ID: 'private-owner', OWNER_KEY_HASH: await hash(recovery) };
  const send = (path, method = 'GET', body = null, headers = {}) => worker.fetch(new Request('https://planner.test' + path,
    { method, headers: { ...headers, ...(body ? { 'Content-Type': 'application/json' } : {}) }, ...(body ? { body: JSON.stringify(body) } : {}) }), env);
  return { env, database, send };
}
async function login(f) {
  const response = await f.send('/api/auth/login', 'POST', { key: recovery });
  assert.equal(response.status, 200);
  return response.headers.get('set-cookie').split(';')[0];
}
test('Публичная оболочка не открывает данные, подделанный заголовок ChatGPT отвергается', async () => {
  const f = await fixture();
  assert.equal((await f.send('/')).status, 200);
  assert.equal((await f.send('/api/state', 'GET', null, { 'oai-authenticated-user-id': 'private-owner' })).status, 401);
  assert.equal((await f.send('/api/dispatch', 'POST')).status, 404);
  assert.equal((await f.send('/api/health')).status, 404); f.database.close();
});
test('Независимый вход сохраняет HttpOnly-сессию, выход её отзывает', async () => {
  const f = await fixture();
  assert.equal((await f.send('/api/auth/login', 'POST', { key: 'wrong' })).status, 401);
  const response = await f.send('/api/auth/login', 'POST', { key: recovery });
  const cookie = response.headers.get('set-cookie');
  assert.match(cookie, /Secure; HttpOnly; SameSite=Strict/); assert.equal((await response.json()).token, undefined);
  const headers = { Cookie: cookie.split(';')[0] };
  assert.equal((await f.send('/api/state', 'GET', null, headers)).status, 200);
  assert.equal((await f.send('/api/auth/logout', 'POST', {}, headers)).status, 200);
  assert.equal((await f.send('/api/state', 'GET', null, headers)).status, 401); f.database.close();
});
test('Код устройства одноразовый, телефон и Windows читают один документ', async () => {
  const f = await fixture(), browser = { Cookie: await login(f) };
  const { code } = await (await f.send('/api/auth/pair', 'POST', {}, browser)).json();
  const nativeLogin = await f.send('/api/auth/exchange', 'POST', { code, native: true });
  const { token } = await nativeLogin.json(); assert.equal(token.length, 43);
  assert.equal((await f.send('/api/auth/exchange', 'POST', { code })).status, 401);
  const native = { Authorization: 'Bearer ' + token };
  const state = emptyState(); const task = saveEntry(state, { kind: 'task', title: 'С телефона', day: '2026-11-27' });
  assert.equal((await f.send('/api/state', 'PUT', { state, revision: 0 }, browser)).status, 200);
  const received = await (await f.send('/api/state', 'GET', null, native)).json();
  assert.equal(received.state.entries[0].id, task.id);
  received.state.entries[0].checked = true;
  await f.send('/api/state', 'PUT', { state: received.state, revision: received.revision }, native);
  assert.equal((await (await f.send('/api/state', 'GET', null, browser)).json()).state.entries[0].checked, true);
  // Stored credentials are SHA-256 digests, not usable session secrets.
  assert.notEqual(f.database.prepare('SELECT token_hash FROM planner_sessions LIMIT 1').get().token_hash, token);
  f.database.close();
});
test('Истёкшие коды, чужой Origin и просроченная сессия отклоняются', async () => {
  const f = await fixture(), browser = { Cookie: await login(f) };
  assert.equal((await f.send('/api/auth/pair', 'POST', {}, { ...browser, Origin: 'https://foreign.test' })).status, 403);
  const { code } = await (await f.send('/api/auth/pair', 'POST', {}, browser)).json();
  f.database.prepare('UPDATE planner_pairings SET expires_at=0').run();
  assert.equal((await f.send('/api/auth/exchange', 'POST', { code })).status, 401);
  f.database.prepare('UPDATE planner_sessions SET expires_at=0').run();
  assert.equal((await f.send('/api/state', 'GET', null, browser)).status, 401); f.database.close();
});
