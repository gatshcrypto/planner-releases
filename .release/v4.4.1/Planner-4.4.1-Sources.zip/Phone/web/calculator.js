function fraction(numerator, denominator = 1n) {
  if (!denominator) throw new Error('На ноль делить нельзя.');
  if (denominator < 0n) { numerator = -numerator; denominator = -denominator; }
  let a = numerator < 0n ? -numerator : numerator, b = denominator;
  while (b) [a, b] = [b, a % b];
  const divisor = a || 1n;
  return [numerator / divisor, denominator / divisor];
}
export function calculate(text) {
  const source = String(text).replaceAll('−', '-').replaceAll('×', '*').replaceAll('÷', '/').replaceAll(',', '.').replaceAll(' ', '');
  if (!source || source.length > 120 || /[^\d.()+*/-]/.test(source)) throw new Error('Проверьте выражение.');
  let position = 0;
  function number() {
    if (source[position] === '-') { position++; const [a, b] = number(); return [-a, b]; }
    if (source[position] === '+') { position++; return number(); }
    if (source[position] === '(') {
      position++; const value = sum();
      if (source[position++] !== ')') throw new Error('Проверьте скобки.');
      return value;
    }
    const match = source.slice(position).match(/^\d+(?:\.\d+)?/);
    if (!match) throw new Error('Проверьте выражение.');
    position += match[0].length;
    const [whole, decimals = ''] = match[0].split('.');
    return fraction(BigInt(whole + decimals), 10n ** BigInt(decimals.length));
  }
  function product() {
    let [a, b] = number();
    while (source[position] === '*' || source[position] === '/') {
      const operation = source[position++], [c, d] = number();
      [a, b] = operation === '*' ? fraction(a * c, b * d) : fraction(a * d, b * c);
    }
    return [a, b];
  }
  function sum() {
    let [a, b] = product();
    while (source[position] === '+' || source[position] === '-') {
      const operation = source[position++], [c, d] = product();
      [a, b] = fraction(a * d + (operation === '+' ? c : -c) * b, b * d);
    }
    return [a, b];
  }
  const [numerator, denominator] = sum();
  if (position !== source.length) throw new Error('Проверьте выражение.');
  const negative = numerator < 0n, absolute = negative ? -numerator : numerator;
  const kopecks = (absolute * 100n * 2n + denominator) / (denominator * 2n);
  if (kopecks > 99999999999999n) throw new Error('Слишком большая сумма.');
  return `${negative && kopecks ? '-' : ''}${kopecks / 100n},${String(kopecks % 100n).padStart(2, '0')}`;
}
