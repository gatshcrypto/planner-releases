import { escapeHtml as esc, button, field, formFooter } from './ui.js';

export function showSignIn(app) {
  app.sheet('Вход в планер', `<form data-form="sign-in">${field('Ключ доступа или код подключения', '<input name="key" type="password" required autocomplete="off" autocapitalize="none" spellcheck="false">')}<p class="small muted">Код другого устройства можно получить в настройках планера.</p><p class="form-error" role="alert"></p><div class="form-actions"><button class="primary-button" type="submit">Войти</button>${button('Позже', 'close')}</div></form>`);
}
export async function signIn(app, key) {
  const clean = key.trim();
  let response = await fetch('/api/auth/exchange', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: clean }), signal: AbortSignal.timeout(12000) });
  if (response.status === 401) response = await fetch('/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key: clean }), signal: AbortSignal.timeout(12000) });
  if (!response.ok) throw new Error((await response.json()).error || 'Не удалось войти.');
  app.close(); location.reload();
}
export async function showPairing(app) {
  const response = await fetch('/api/auth/pair', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}', signal: AbortSignal.timeout(12000) });
  if (response.status === 401) return showSignIn(app);
  if (!response.ok) throw new Error('Не удалось получить код.');
  const { code } = await response.json();
  app.pairingCode = code;
  app.sheet('Подключить устройство', `<p class="small">В Windows откройте «Настройки → Синхронизация». Введите адрес планера и этот код. Код действует 10 минут и используется один раз.</p>${field('Адрес планера', `<input readonly value="${esc(location.origin)}">`)}${field('Код подключения', `<textarea readonly rows="2" aria-label="Код подключения">${esc(code)}</textarea>`)}${button('Скопировать код', 'copy-pairing', '', 'primary-button')}`);
}
