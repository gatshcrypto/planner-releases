import { today, id, themes, emptyState, shiftDate, parseDate, addPeriod, dateLabel, saveEntry, toggleEntry, removeEntry, markHabit, expireArchive, progress, parseMoney, saveOperation, validateState, children, mergeStates } from './domain.js';
import { PlannerStorage } from './storage.js';
import { renderNavigation, renderSection, sections } from './views.js';
import { escapeHtml as esc, button, empty, field, input, formFooter } from './ui.js';
import * as forms from './forms.js';
import { calculate } from './calculator.js';
import { showSignIn, signIn, showPairing } from './access.js';

const modal = document.querySelector('#sheet');
const main = document.querySelector('#main');
const app = {
  state: emptyState(), section: 'tasks', date: today(), eventDate: today(), financeDate: today(),
  financeYear: false, goalPage: 0, overdue: false, syncStatus: 'Открываем данные',
  theme() {
    const theme = themes[this.state.settings.theme] || themes.emerald;
    for (const key of ['paper', 'ink', 'accent', 'dark', 'light']) document.documentElement.style.setProperty(`--${key}`, theme[key]);
    document.documentElement.style.setProperty('--tile-x', `${(theme.tile % 3) * 50}%`);
    document.documentElement.style.setProperty('--tile-y', theme.tile > 2 ? '100%' : '0%');
    document.querySelector('meta[name="theme-color"]').content = theme.paper;
  },
  render(reset = false) {
    const scroll = reset ? 0 : window.scrollY;
    const horizontal = main.querySelector('.columns')?.scrollLeft || 0;
    this.theme(); renderNavigation(this); main.innerHTML = renderSection(this);
    if (main.querySelector('.columns')) main.querySelector('.columns').scrollLeft = horizontal;
    requestAnimationFrame(() => window.scrollTo({ top: scroll, behavior: 'instant' }));
  },
  navigate(section) {
    this.close(); this.section = section; this.goalPage = 0; this.render(true);
    history.replaceState({ section }, '', `/#${section}`);
  },
  sheet(title, html, draft = null) {
    this.draft = draft;
    document.querySelector('#sheet-title').textContent = title;
    document.querySelector('#sheet-content').innerHTML = html;
    if (!modal.open) modal.showModal();
    modal.scrollTop = 0;
  },
  close() { modal.close(); this.draft = null; document.querySelector('#sheet-content').innerHTML = ''; },
  toast(message, undo = null) {
    clearTimeout(this.toastTimer);
    const toast = document.querySelector('#toast');
    toast.innerHTML = `<span>${esc(message)}</span>${undo ? button('Отменить', 'undo', '', '') : ''}`;
    this.undoAction = undo; toast.hidden = false;
    this.toastTimer = setTimeout(() => { toast.hidden = true; this.undoAction = null; }, undo ? 12000 : 6000);
  },
  commit(change, undoMessage = '') {
    const mutation = (this.pendingMutations || Promise.resolve()).catch(() => {}).then(async () => {
      const previous = structuredClone(this.state), changed = structuredClone(this.state);
      change(changed);
      await this.storage.save(changed); this.state = this.storage.state; this.render();
      if (undoMessage) this.toast(undoMessage, async () => this.commit(state => {
        const restored = mergeStates(changed, previous, state);
        if (restored.conflicts.length) throw new Error('Связанные записи уже изменены. Проверьте их перед восстановлением.');
        validateState(restored.state); Object.assign(state, restored.state);
      }));
    });
    this.pendingMutations = mutation;
    return mutation;
  },
  add(kind = null, parentId = null, columnId = null) {
    if (!kind && ['finance', 'finance-summary'].includes(this.section)) return forms.showOperationForm(this, { kind: 'income', day: this.financeDate });
    kind ||= { tasks: 'task', subgoals: 'subgoal', goals: 'goal', habits: 'habit', events: 'event' }[this.section] || 'task';
    if (kind === 'subgoal' && !this.state.entries.some(item => item.kind === 'goal')) {
      this.sheet('Новая подцель', empty('Сначала создайте цель', 'new-goal', 'Создать цель')); return;
    }
    forms.showEntryForm(this, { kind, title: '', day: kind === 'subgoal' ? null : kind === 'event' ? this.eventDate : kind === 'task' ? this.date : today(),
      parentId, columnId, priority: 0, period: kind === 'goal' ? 'month' : null });
  },
  async enablePush() {
    if (!('Notification' in window) || !('PushManager' in window)) throw new Error('Откройте планер с главного экрана iPhone и включите уведомления в настройках.');
    const permission = await Notification.requestPermission();
    if (permission !== 'granted') throw new Error('Разрешите уведомления в настройках iPhone.');
    const registration = await navigator.serviceWorker.ready;
    const response = await fetch('/api/push/key', { cache: 'no-store' });
    if (!response.ok) throw new Error('Не удалось подключить сервер уведомлений.');
    const { publicKey } = await response.json();
    const raw = Uint8Array.from(atob(publicKey.replaceAll('-', '+').replaceAll('_', '/')), value => value.charCodeAt(0));
    const subscription = await registration.pushManager.getSubscription() || await registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: raw });
    const saved = await fetch('/api/push/subscribe', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(subscription) });
    if (!saved.ok) throw new Error('Не удалось сохранить подписку.');
    this.toast('Уведомления подключены'); forms.showSettings(this);
  }
};
app.storage = new PlannerStorage((status, error = false) => {
  app.syncStatus = status;
  if (app.storage.state && app.state !== app.storage.state) { app.state = app.storage.state; if (app.ready) app.render(); }
  const indicator = document.querySelector('#sync-status');
  if (indicator) { indicator.textContent = status; indicator.classList.toggle('error', error); }
});

async function action(name, value) {
  const entry = app.state.entries.find(item => item.id === value);
  switch (name) {
    case 'sign-in': showSignIn(app); break;
    case 'pair-device': await showPairing(app); break;
    case 'copy-pairing': await navigator.clipboard.writeText(app.pairingCode); app.toast('Код скопирован'); break;
    case 'reload': location.reload(); break;
    case 'navigate': app.navigate(value); break;
    case 'close': app.close(); break;
    case 'add': app.add(); break;
    case 'new-goal': app.add('goal'); break;
    case 'details': forms.showDetails(app, value); break;
    case 'entry-edit': forms.showEntryForm(app, entry); break;
    case 'add-child': app.add(entry.kind === 'goal' ? 'subgoal' : 'task', entry.id); break;
    case 'toggle':
    case 'detail-toggle': {
      const detailId = app.draft?.detailId;
      await app.commit(state => toggleEntry(state, value));
      if (detailId) forms.showDetails(app, detailId);
      break;
    }
    case 'day-shift': app.date = shiftDate(app.date, Number(value)); app.chartStart = null; app.overdue = false; app.render(); break;
    case 'day-now': app.date = today(); app.chartStart = null; app.overdue = false; app.render(); break;
    case 'select-day': app.date = value; app.overdue = false; app.render(); break;
    case 'chart-shift': app.chartStart = shiftDate(app.chartStart || shiftDate(app.date, -3), Number(value)); app.render(); break;
    case 'task-filter': app.overdue = value === 'overdue'; app.render(); break;
    case 'task-menu':
      app.sheet('Перенести задачу', `${button('На сегодня', 'move-task', 'today', 'settings-button')}${button('На завтра', 'move-task', 'tomorrow', 'settings-button')}<form data-form="move-task">${field('Дата', input('day', entry.day, 'date', 'required'))}${formFooter()}</form>`, entry); break;
    case 'move-task': {
      const current = app.draft; await app.commit(state => saveEntry(state, { ...current, day: value === 'today' ? today() : shiftDate(today(), 1) })); app.close(); break;
    }
    case 'habit-filter': app.mastered = value === 'mastered'; app.render(); break;
    case 'habit-mark': {
      let mastered = false; await app.commit(state => { mastered = markHabit(state.entries.find(item => item.id === value)); });
      if (mastered) app.toast(`Привычка освоена — ${entry.title}`);
      break;
    }
    case 'event-month': app.eventDate = addPeriod(app.eventDate, 'month', Number(value)); app.render(); break;
    case 'event-now': app.eventDate = today(); app.render(); break;
    case 'event-day': app.eventDate = value; app.render(); break;
    case 'finance-mode': app.financeYear = value === 'year'; app.render(); break;
    case 'finance-shift': app.financeDate = addPeriod(app.financeDate, app.financeYear ? 'year' : 'month', Number(value)); app.render(); break;
    case 'finance-now': app.financeDate = today(); app.render(); break;
    case 'finance-month': app.financeDate = value; app.financeYear = false; app.render(); break;
    case 'operation': forms.showOperationForm(app, app.state.operations.find(item => item.id === value)); break;
    case 'operation-kind': {
      const draft = forms.readOperation(app); draft.kind = value; draft.categoryId = null; forms.showOperationForm(app, draft); break;
    }
    case 'accounts': forms.showAccounts(app); break;
    case 'categories': forms.showCategories(app); break;
    case 'account-new': forms.showAccountForm(app, {}); break;
    case 'account-edit': forms.showAccountForm(app, app.state.accounts.find(item => item.id === value)); break;
    case 'category-new': forms.showCategoryForm(app, {}); break;
    case 'category-edit': forms.showCategoryForm(app, app.state.categories.find(item => item.id === value)); break;
    case 'account-inline': forms.showAccountForm(app, {}, { operation: forms.readOperation(app), destination: value === 'destination' }); break;
    case 'category-inline': {
      const draft = forms.readOperation(app); forms.showCategoryForm(app, { kind: draft.kind }, { operation: draft }); break;
    }
    case 'category-history': forms.showCategoryHistory(app, value); break;
    case 'calculator': forms.showCalculator(app, forms.readOperation(app)); break;
    case 'calc-key': calculatorKey(value); break;
    case 'settings': forms.showSettings(app); break;
    case 'theme': await app.commit(state => { state.settings.theme = value; }); forms.showSettings(app); break;
    case 'undo': if (app.undoAction) { await app.undoAction(); document.querySelector('#toast').hidden = true; app.undoAction = null; } break;
    case 'goal-page': {
      const goals = app.state.entries.filter(item => item.kind === 'goal' && progress(app.state, item).complete === !!app.goalCompleted);
      const index = goals.findIndex(item => item.id === app.goalId);
      app.goalId = goals[(index + Number(value) + goals.length) % goals.length]?.id; app.render(); break;
    }
    case 'goal-filter': app.goalCompleted = value === 'completed'; app.goalId = null; app.render(); break;
    case 'summary-goals': {
      const pages = Math.ceil(app.state.entries.filter(item => item.kind === 'goal' && !progress(app.state, item).complete).length / 6);
      app.goalPage = (app.goalPage + Number(value) + pages) % pages; app.render(); break;
    }
    case 'column-new':
      app.sheet('Новый столбец', `<form data-form="column">${field('Название', input('title', '', 'text', 'required maxlength="100"'))}${formFooter()}</form>`, {}); break;
    case 'column-menu': {
      const column = app.state.columns.find(item => item.id === value);
      app.sheet('Столбец', `<form data-form="column">${field('Название', input('title', column.title, 'text', 'required maxlength="100"'))}${formFooter(true)}</form>`, column); break;
    }
    case 'add-column-entry': app.add(null, null, value); break;
    case 'delete-current': confirmDelete(); break;
    case 'confirm-delete': await deleteCurrent(); break;
    case 'archive': forms.showArchive(app); break;
    case 'restore': await app.commit(state => { const restored = state.entries.find(item => item.id === value); if (restored.kind === 'task' && !restored.day) restored.day = today(); toggleEntry(state, value); }); forms.showArchive(app); break;
    case 'clear-archive':
      app.sheet('Очистить архив?', `<p>Записи будут убраны из архива. Их вклад в прогресс сохранится.</p><div class="form-actions">${button('Очистить', 'confirm-clear-archive', '', 'primary-button')}${button('Отмена', 'archive')}</div>`); break;
    case 'confirm-clear-archive': await app.commit(state => { for (const item of state.entries.filter(item => item.checked && item.archivedOn)) { item.archivedOn = null; item.notes = ''; if (item.kind === 'task') item.title = ''; } }, 'Архив очищен'); app.close(); break;
    case 'export': downloadBackup(); break;
    case 'import': chooseBackup(); break;
    case 'confirm-import': await importBackup(); break;
    case 'windows-import':
      app.sheet('Перенос с Windows', `<p class="small">На компьютере откройте эту страницу и скачайте программу переноса. Запустите её и сохраните файл данных. Передайте файл на iPhone и выберите «Импортировать данные».</p><div class="form-actions"><a class="primary-button" href="/PlannerTransfer.exe" download>Скачать для Windows</a>${button('Импортировать данные', 'import', '', 'outline-button')}</div>`); break;
    case 'sync': await app.storage.sync(); app.state = app.storage.state; app.render(); forms.showSettings(app); break;
    case 'resolve-conflict': app.state = await app.storage.resolveConflicts(value === 'local'); app.render(); forms.showSettings(app); break;
    case 'enable-push': await app.enablePush(); break;
    case 'test-push': {
      const response = await fetch('/api/push/test', { method: 'POST' });
      if (!response.ok) { const error = await response.json(); throw new Error(error.error || 'Сначала включите уведомления.'); }
      app.toast('Проверочное уведомление отправлено'); break;
    }
    case 'update-app': {
      const registrations = await navigator.serviceWorker.getRegistrations();
      for (const registration of registrations) await registration.update();
      if (registrations.some(item => item.waiting)) {
        for (const registration of registrations) registration.waiting?.postMessage({ type: 'SKIP_WAITING' });
        navigator.serviceWorker.addEventListener('controllerchange', () => location.reload(), { once: true });
      } else app.toast('Установлена актуальная версия');
      break;
    }
    case 'pomodoro': showPomodoro(); break;
    case 'timer-start': startTimer(); break;
    case 'timer-pause': await app.commit(state => { const timer = state.settings.pomodoro; timer.remaining = Math.max(0, timer.endsAt - Date.now()); timer.endsAt = null; }); showPomodoro(); break;
    case 'timer-reset': await app.commit(state => { state.settings.pomodoro = { mode: 'focus', remaining: 25 * 60000, endsAt: null }; }); stopSound(); showPomodoro(); break;
    case 'timer-mode': await app.commit(state => { state.settings.pomodoro = { mode: value, remaining: (value === 'focus' ? 25 : 5) * 60000, endsAt: null }; }); stopSound(); showPomodoro(); break;
    case 'timer-sound': chooseSound(); break;
    case 'stop-sound': stopSound(); break;
  }
}

function confirmDelete() {
  const formType = document.querySelector('form[data-form]')?.dataset.form;
  app.deleteDraft = { type: formType, draft: structuredClone(app.draft) };
  const related = formType === 'entry' ? app.state.entries.filter(item => item.parentId === app.draft.id) : [];
  let description = 'Удалить запись?';
  if (formType === 'entry' && related.length) description = `Будут удалены запись и связанные ${app.draft.kind === 'goal' ? 'подцели с задачами' : 'задачи'}.`;
  if (formType === 'column') description = 'Столбец будет удалён. Его записи останутся в разделе.';
  if (['account', 'category'].includes(formType)) description = 'Использованная запись будет перенесена в архив с сохранением истории операций.';
  app.sheet('Подтверждение', `<p>${description}</p><div class="form-actions">${button('Подтвердить', 'confirm-delete', '', 'primary-button')}${button('Отмена', 'close')}</div>`);
}
async function deleteCurrent() {
  const { type, draft } = app.deleteDraft;
  await app.commit(state => {
    if (type === 'entry') removeEntry(state, draft.id);
    else if (type === 'column') {
      state.columns = state.columns.filter(item => item.id !== draft.id);
      state.entries.forEach(item => { if (item.columnId === draft.id) item.columnId = null; });
      state.deleted[draft.id] = new Date().toISOString();
    } else if (type === 'operation') {
      state.operations = state.operations.filter(item => item.id !== draft.id); state.deleted[draft.id] = new Date().toISOString();
    } else {
      const list = type === 'account' ? 'accounts' : 'categories';
      const used = state.operations.some(item => type === 'account' ? item.accountId === draft.id || item.destinationId === draft.id : item.categoryId === draft.id);
      if (used) state[list].find(item => item.id === draft.id).archived = true;
      else { state[list] = state[list].filter(item => item.id !== draft.id); state.deleted[draft.id] = new Date().toISOString(); }
    }
  }, 'Запись убрана');
  app.close();
}
async function submitForm(form) {
  const data = Object.fromEntries(new FormData(form));
  const editorDraft = structuredClone(app.draft);
  switch (form.dataset.form) {
    case 'sign-in': await signIn(app, data.key); break;
    case 'entry': {
      const draft = { ...app.draft, ...data, priority: Number(data.priority || 0), parentId: data.parentId || null, columnId: data.columnId || null };
      if (draft.kind === 'subgoal' && form.elements.undated.checked) { draft.day = null; draft.targetDay = null; }
      if (draft.kind === 'event' && form.elements.allDay.checked) draft.time = null;
      draft.reminderAt = data.reminderAt ? new Date(data.reminderAt).toISOString() : null;
      let saved;
      await app.commit(state => { saved = saveEntry(state, draft); }); app.close();
      if (['goal', 'subgoal'].includes(draft.kind)) forms.showDetails(app, saved.id);
      break;
    }
    case 'operation': await app.commit(state => saveOperation(state, { ...app.draft, ...data, amount: parseMoney(data.amount) })); app.close(); break;
    case 'account':
    case 'category': {
      const category = form.dataset.form === 'category', list = category ? 'categories' : 'accounts';
      const draft = { ...app.draft, ...data, id: app.draft.id || id(), name: data.name.trim(), updatedAt: new Date().toISOString() };
      if (!draft.name || draft.name.length > 100) throw new Error('Введите название до 100 символов.');
      draft.archived = !!form.elements.archived?.checked;
      if (!category) draft.opening = parseMoney(data.opening, true);
      if (app.state[list].some(item => item.id !== draft.id && item.name.toLocaleLowerCase('ru-RU') === draft.name.toLocaleLowerCase('ru-RU') && (!category || item.kind === draft.kind))) throw new Error('Такое название уже есть.');
      const inline = draft._inline; delete draft._inline;
      await app.commit(state => { const index = state[list].findIndex(item => item.id === draft.id); if (index < 0) state[list].push(draft); else state[list][index] = draft; });
      if (inline) {
        inline.operation[category ? 'categoryId' : inline.destination ? 'destinationId' : 'accountId'] = draft.id;
        forms.showOperationForm(app, inline.operation);
      } else if (category) forms.showCategories(app); else forms.showAccounts(app);
      break;
    }
    case 'column': {
      const title = data.title.trim(); if (!title || title.length > 100) throw new Error('Введите название столбца.');
      await app.commit(state => { const existing = state.columns.find(item => item.id === editorDraft.id); if (existing) existing.title = title; else state.columns.push({ id: id(), title, position: state.columns.length }); }); app.close(); break;
    }
    case 'move-task': parseDate(data.day); await app.commit(state => saveEntry(state, { ...editorDraft, day: data.day })); app.close(); break;
    case 'calculator': calculatorKey('Готово'); break;
  }
}
function calculatorKey(key) {
  const expression = document.querySelector('input[name="expression"]');
  if (!expression) return;
  if (key === 'Закрыть') { forms.showOperationForm(app, app.calculatorDraft); return; }
  if (key === 'Готово') { const result = calculate(expression.value); forms.showOperationForm(app, { ...app.calculatorDraft, rawAmount: result }); return; }
  if (key === '=') expression.value = calculate(expression.value);
  else if (key === 'C') expression.value = '';
  else if (key === '⌫') expression.value = expression.value.slice(0, -1);
  else expression.value += key;
}
function downloadBackup() {
  const blob = new Blob([JSON.stringify({ format: 'planner-backup', exportedAt: new Date().toISOString(), state: app.state }, null, 2)], { type: 'application/json' });
  const link = document.createElement('a'); link.href = URL.createObjectURL(blob); link.download = `planner-${today()}.json`; link.click();
  setTimeout(() => URL.revokeObjectURL(link.href), 10000);
}
function chooseBackup() {
  const picker = document.createElement('input'); picker.type = 'file'; picker.accept = '.json,application/json';
  picker.onchange = async () => {
    try {
      const file = picker.files[0]; if (!file) return;
      if (file.size > 10 * 1024 * 1024) throw new Error('Файл слишком большой.');
      const data = JSON.parse(await file.text()), state = validateState(data.state || data);
      app.importedState = state;
      app.sheet('Импорт данных', `<p>В файле записей планера — ${state.entries.length}, счетов — ${state.accounts.length}, финансовых операций — ${state.operations.length}.</p><p class="small muted" style="margin-top:12px">Записи с одинаковыми идентификаторами будут обновлены данными из файла.</p><div class="form-actions">${button('Объединить данные', 'confirm-import', '', 'primary-button')}${button('Отмена', 'close')}</div>`);
    } catch (error) { app.toast(error.message); }
  };
  picker.click();
}
async function importBackup() {
  const incoming = app.importedState;
  await app.commit(state => {
    for (const collection of ['entries', 'columns', 'accounts', 'categories', 'operations']) {
      const items = new Map(state[collection].map(item => [item.id, item]));
      for (const item of incoming[collection]) { items.set(item.id, item); delete state.deleted[item.id]; }
      state[collection] = [...items.values()];
    }
    state.settings = { ...state.settings, ...incoming.settings };
  }, 'Данные импортированы');
  app.importedState = null; app.close();
}

let audioContext, customAudio;
function stopSound() { if (customAudio) { customAudio.pause(); customAudio.currentTime = 0; } }
function playSound() {
  if (customAudio) { customAudio.loop = true; customAudio.play().catch(() => {}); return; }
  if (!audioContext || audioContext.state !== 'running') return;
  [523.25, 659.25, 783.99, 659.25, 523.25].forEach((frequency, index) => {
    const oscillator = audioContext.createOscillator(), gain = audioContext.createGain(), start = audioContext.currentTime + index * .4;
    oscillator.type = 'sine'; oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(0, start); gain.gain.linearRampToValueAtTime(.16, start + .03); gain.gain.exponentialRampToValueAtTime(.001, start + .65);
    oscillator.connect(gain); gain.connect(audioContext.destination); oscillator.start(start); oscillator.stop(start + .7);
  });
}
function showPomodoro() {
  const timer = app.state.settings.pomodoro || { mode: 'focus', remaining: 25 * 60000 };
  app.sheet('Помодоро', `<div class="filters">${button('Фокус', 'timer-mode', 'focus', timer.mode === 'focus' ? 'active' : '')}${button('Перерыв', 'timer-mode', 'break', timer.mode === 'break' ? 'active' : '')}</div><p class="timer-display" id="timer-display"></p><div class="form-actions">${button(timer.endsAt ? 'Пауза' : 'Начать', timer.endsAt ? 'timer-pause' : 'timer-start', '', 'primary-button')}${button('Сбросить', 'timer-reset', '', 'outline-button')}</div>${button('Своя мелодия', 'timer-sound', '', 'settings-button')}${button('Выключить звук', 'stop-sound', '', 'settings-button')}`, { pomodoro: true });
  updateTimerDisplay();
}
function updateTimerDisplay() {
  const label = document.querySelector('#timer-display'); if (!label) return;
  const timer = app.state.settings.pomodoro || { remaining: 25 * 60000 };
  const seconds = Math.ceil(Math.max(0, timer.endsAt ? timer.endsAt - Date.now() : timer.remaining) / 1000);
  label.textContent = `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
}
async function startTimer() {
  audioContext ||= new (window.AudioContext || window.webkitAudioContext)(); await audioContext.resume();
  const transaction = app.storage.database.transaction('documents');
  const request = transaction.objectStore('documents').get('pomodoro-sound');
  request.onsuccess = () => { if (request.result) { customAudio = new Audio(URL.createObjectURL(request.result)); customAudio.play().then(() => { customAudio.pause(); customAudio.currentTime = 0; }).catch(() => {}); } };
  await app.commit(state => { const timer = state.settings.pomodoro || { mode: 'focus', remaining: 25 * 60000 }; timer.endsAt = Date.now() + (timer.remaining || (timer.mode === 'focus' ? 25 : 5) * 60000); timer.notified = false; state.settings.pomodoro = timer; });
  showPomodoro();
}
function chooseSound() {
  const picker = document.createElement('input'); picker.type = 'file'; picker.accept = 'audio/*';
  picker.onchange = () => {
    const file = picker.files[0]; if (!file) return;
    if (file.size > 20 * 1024 * 1024) return app.toast('Выберите мелодию меньше 20 МБ.');
    const transaction = app.storage.database.transaction('documents', 'readwrite'); transaction.objectStore('documents').put(file, 'pomodoro-sound');
    transaction.oncomplete = () => { app.toast('Мелодия сохранена на устройстве'); customAudio = new Audio(URL.createObjectURL(file)); };
  };
  picker.click();
}
document.addEventListener('click', event => {
  const control = event.target.closest('[data-action]'); if (!control) return;
  event.preventDefault();
  Promise.resolve(action(control.dataset.action, control.dataset.id)).catch(error => {
    const label = modal.open ? modal.querySelector('.form-error') : null;
    if (label) { label.textContent = error.message; label.scrollIntoView({ block: 'nearest' }); } else app.toast(error.message);
  });
});
document.addEventListener('submit', event => {
  if (!event.target.matches('form[data-form]')) return;
  event.preventDefault();
  const submit = event.target.querySelector('button[type="submit"]'); if (submit) submit.disabled = true;
  submitForm(event.target).catch(error => { const label = event.target.querySelector('.form-error'); if (label) label.textContent = error.message; else app.toast(error.message); })
    .finally(() => { if (submit) submit.disabled = false; });
});
document.addEventListener('change', event => {
  const form = event.target.closest('form[data-form="entry"]'); if (!form) return;
  if (event.target.name === 'undated') for (const name of ['day', 'targetDay']) { form.elements[name].disabled = event.target.checked; form.elements[name].required = !event.target.checked; if (!event.target.checked && !form.elements[name].value) form.elements[name].value = today(); }
  if (event.target.name === 'allDay') form.elements.time.disabled = event.target.checked;
});
modal.addEventListener('click', event => { const rect = modal.getBoundingClientRect(); if (event.target === modal && (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom)) app.close(); });
modal.addEventListener('cancel', event => { event.preventDefault(); app.close(); });
window.addEventListener('online', () => app.storage.sync());
document.addEventListener('visibilitychange', () => { if (!document.hidden) { app.storage.sync(); app.render(); } });
window.addEventListener('keydown', event => { if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'n') { event.preventDefault(); app.add(); } });
setInterval(() => {
  updateTimerDisplay();
  const timer = app.state.settings.pomodoro;
  if (timer?.endsAt && timer.endsAt <= Date.now() && !timer.notified) {
    timer.notified = true; timer.endsAt = null; timer.remaining = 0;
    app.storage.save(app.state).catch(error => app.toast(error.message));
    playSound(); app.toast(timer.mode === 'focus' ? 'Фокус завершён' : 'Перерыв завершён');
    if (app.draft?.pomodoro) showPomodoro();
  }
}, 1000);
setInterval(() => { if (app.ready && !document.hidden) app.storage.sync(); }, 30000);

async function launchQuote() {
  if (sessionStorage.getItem('planner-intro') && performance.getEntriesByType('navigation')[0]?.type !== 'navigate') return;
  sessionStorage.setItem('planner-intro', '1');
  try {
    const response = await fetch('/quotes.json'); const quotes = await response.json();
    let used = JSON.parse(localStorage.getItem('planner-quotes') || '[]');
    let available = quotes.filter(quote => !used.includes(quote.id));
    if (!available.length) { used = []; available = quotes; }
    const quote = available[Math.floor(Math.random() * available.length)];
    used.push(quote.id); localStorage.setItem('planner-quotes', JSON.stringify(used));
    const overlay = document.createElement('div'); overlay.className = 'quote-screen';
    overlay.innerHTML = `<div class="quote-content"><p class="quote-words">«${esc(quote.words)}»</p><p class="quote-author">${esc(quote.author)}</p></div><button class="primary-button quote-continue" hidden>Продолжить</button>`;
    document.body.append(overlay);
    setTimeout(() => { const proceed = overlay.querySelector('button'); proceed.hidden = false; proceed.onclick = () => overlay.remove(); }, 3000);
  } catch { }
}
try {
  app.state = await app.storage.load(); validateState(app.state); expireArchive(app.state); app.ready = true;
  const hash = location.hash.slice(1); if (sections.some(section => section[0] === hash)) app.section = hash;
  app.render(true);
  if (app.storage.authNeeded && !app.state.entries.length) showSignIn(app);
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => app.toast('Не удалось включить офлайн-доступ.'));
  if (!new URLSearchParams(location.search).has('test')) launchQuote();
  const requested = new URLSearchParams(location.search).get('entry'); if (requested) forms.showDetails(app, requested);
} catch (error) { main.innerHTML = `<section class="card"><p>${esc(error.message)}</p>${button('Попробовать снова', 'reload', '', 'outline-button')}</section>`; }
window.plannerApp = app;
