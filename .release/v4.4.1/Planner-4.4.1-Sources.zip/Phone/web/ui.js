export const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
export function button(label, action, id = '', className = 'plain-button', attributes = '') {
  return `<button type="button" class="${className}" data-action="${action}"${id ? ` data-id="${escapeHtml(id)}"` : ''} ${attributes}>${label}</button>`;
}
export function empty(label, action = '', actionLabel = 'Добавить') {
  return `<div class="empty"><p>${escapeHtml(label)}</p>${action ? button(escapeHtml(actionLabel), action, '', 'outline-button') : ''}</div>`;
}
export function ring(percent, className = '', title = '') {
  return `<div class="ring ${className}" style="--progress:${percent}" role="img" aria-label="${escapeHtml(title || 'Выполнено')} ${percent}%"><strong>${percent}%</strong></div>`;
}
export function options(items, selected, title = 'Выбрать') {
  return `<option value="">${title}</option>${items.map(item => `<option value="${escapeHtml(item.id)}" ${item.id === selected ? 'selected' : ''}>${escapeHtml(item.title || item.name)}</option>`).join('')}`;
}
export function field(label, control) { return `<label class="field"><span>${label}</span>${control}</label>`; }
export function input(name, value = '', type = 'text', attributes = '') {
  return `<input name="${name}" type="${type}" value="${escapeHtml(value)}" ${attributes}>`;
}
export function textarea(name, value = '') { return `<textarea name="${name}" rows="3" maxlength="4000">${escapeHtml(value)}</textarea>`; }
export function select(name, content) { return `<select name="${name}">${content}</select>`; }
export function formFooter(existing = false) {
  return `<p class="form-error" role="alert"></p><div class="form-actions"><button class="primary-button" type="submit">Сохранить</button>${button('Отмена', 'close')}${existing ? button('Удалить', 'delete-current', '', 'plain-button danger') : ''}</div>`;
}
