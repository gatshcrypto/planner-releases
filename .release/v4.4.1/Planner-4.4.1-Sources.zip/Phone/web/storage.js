import { emptyState, mergeStates, validateState } from './domain.js';

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('planner-phone', 1);
    request.onupgradeneeded = () => request.result.createObjectStore('documents');
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(new Error('Не удалось открыть хранилище телефона.'));
  });
}
export class PlannerStorage {
  async response(path, options = {}) {
    const response = await fetch(path, { cache: 'no-store', signal: AbortSignal.timeout(12000), ...options });
    if (response.status === 401) { this.authNeeded = true; throw new Error('sign_in_required'); }
    if (!response.ok && response.status !== 409) throw new Error('server_unavailable');
    this.authNeeded = false;
    return response;
  }
  unavailable() { this.onStatus(this.authNeeded ? 'Войдите для синхронизации' : 'Офлайн · данные на устройстве', !!this.authNeeded); }
  constructor(onStatus) { this.onStatus = onStatus; this.user = localStorage.getItem('planner-user') || 'local'; this.revision = 0; this.base = emptyState(); this.dirty = false; this.running = false; this.conflicts = []; }
  async read(key) {
    return new Promise((resolve, reject) => {
      const request = this.database.transaction('documents').objectStore('documents').get(key);
      request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error);
    });
  }
  async write() {
    const snapshot = { state: this.state, base: this.base, revision: this.revision, dirty: this.dirty, conflicts: this.conflicts, remote: this.remote };
    return new Promise((resolve, reject) => {
      const transaction = this.database.transaction('documents', 'readwrite');
      transaction.objectStore('documents').put(snapshot, this.user);
      transaction.oncomplete = resolve;
      transaction.onerror = () => reject(new Error('Не удалось сохранить данные на устройстве. Экспортируйте резервную копию.'));
    });
  }
  async load() {
    this.database = await openDatabase();
    const cached = await this.read(this.user);
    this.state = cached?.state || emptyState();
    this.base = cached?.base || emptyState(); this.revision = cached?.revision || 0; this.dirty = !!cached?.dirty;
    this.conflicts = cached?.conflicts || []; this.remote = cached?.remote;
    try {
      const response = await this.response('/api/state');
      if (!response.ok) throw new Error('Облако недоступно');
      const remote = await response.json();
      if (this.user !== 'local' && this.user !== remote.user) {
        const own = await this.read(remote.user);
        this.state = own?.state || emptyState(); this.base = own?.base || emptyState();
        this.revision = own?.revision || 0; this.dirty = !!own?.dirty;
        this.conflicts = own?.conflicts || []; this.remote = own?.remote;
      }
      this.user = remote.user; localStorage.setItem('planner-user', this.user);
      this.acceptRemote(remote);
      await this.write();
      this.onStatus(this.conflicts.length ? 'Есть изменения с другого устройства' : this.dirty ? 'Сохранено на устройстве' : 'Сохранено', !!this.conflicts.length);
      if (this.dirty) queueMicrotask(() => this.sync());
    } catch { this.unavailable(); }
    return this.state;
  }
  acceptRemote(remote) {
    if (this.dirty) {
      const merged = mergeStates(this.base, this.state, remote.state);
      this.conflicts = [...new Map([...this.conflicts, ...merged.conflicts].map(item => [`${item.key}:${item.id}`, item])).values()];
      try { validateState(merged.state); this.state = merged.state; }
      catch { this.conflicts = [{ key: 'document', id: 'all' }]; }
      this.remote = remote.state;
    } else this.state = remote.state;
    this.base = structuredClone(remote.state); this.revision = remote.revision;
  }
  async save(state) {
    validateState(state);
    const previous = this.state, wasDirty = this.dirty;
    this.state = structuredClone(state); this.dirty = true;
    try { await this.write(); }
    catch (error) { this.state = previous; this.dirty = wasDirty; throw error; }
    this.onStatus('Сохранено на устройстве');
    clearTimeout(this.pending); this.pending = setTimeout(() => this.sync(), 400);
  }
  async sync() {
    if (this.running) return;
    if (this.conflicts.length) { this.onStatus('Есть изменения с другого устройства', true); return; }
    this.running = true;
    if (!this.dirty) {
      try {
        const response = await this.response('/api/state');
        if (!response.ok) throw new Error('Облако недоступно');
        const remote = await response.json();
        if (remote.user !== this.user) { location.reload(); return; }
        if (remote.revision !== this.revision) { this.acceptRemote(remote); await this.write(); }
        this.onStatus('Сохранено');
      } catch { this.unavailable(); }
      finally { this.running = false; }
      return;
    }
    const sent = structuredClone(this.state);
    try {
      const response = await this.response('/api/state', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ state: sent, revision: this.revision }) });
      if (response.status === 409) {
        const remote = await response.json();
        this.acceptRemote(remote); await this.write();
        this.onStatus(this.conflicts.length ? 'Есть изменения с другого устройства' : 'Обновление данных', !!this.conflicts.length);
      } else {
        if (!response.ok) throw new Error('Не удалось синхронизировать');
        const saved = await response.json();
        this.base = sent; this.revision = saved.revision;
        this.failures = 0;
        this.dirty = JSON.stringify(this.state) !== JSON.stringify(sent);
        await this.write(); this.onStatus(this.dirty ? 'Сохранено на устройстве' : 'Сохранено');
      }
    } catch { this.failures = (this.failures || 0) + 1; this.unavailable(); }
    finally { this.running = false; }
    if (this.dirty && !this.conflicts.length && !this.authNeeded && navigator.onLine) {
      clearTimeout(this.pending); this.pending = setTimeout(() => this.sync(), Math.min(60000, 1500 * 2 ** (this.failures || 0)));
    }
  }
  async resolveConflicts(useLocal) {
    if (!useLocal && this.conflicts.some(item => item.key === 'document')) this.state = structuredClone(this.remote);
    else for (const conflict of this.conflicts) {
      if (conflict.key === 'document') continue;
      if (conflict.key === 'settings') { if (!useLocal) this.state.settings[conflict.id] = this.remote.settings[conflict.id]; continue; }
      if (!useLocal) {
        this.state[conflict.key] = this.state[conflict.key].filter(item => item.id !== conflict.id);
        const remote = this.remote[conflict.key].find(item => item.id === conflict.id);
        if (remote) this.state[conflict.key].push(structuredClone(remote));
      }
      if (this.state[conflict.key].some(item => item.id === conflict.id)) delete this.state.deleted[conflict.id];
      else this.state.deleted[conflict.id] = new Date().toISOString();
    }
    validateState(this.state);
    this.dirty = true; this.conflicts = []; await this.write(); await this.sync(); return this.state;
  }
}
