export const kinds = ['task', 'goal', 'subgoal', 'habit', 'event'];
export const themes = {
  emerald: { name: 'Лесной', paper: '#F4F0E5', ink: '#222923', accent: '#275541', dark: '#142B22', light: '#C0DCC1', tile: 0 },
  ocean: { name: 'Морской', paper: '#EDF2F4', ink: '#182A38', accent: '#244F75', dark: '#122536', light: '#B6D7F2', tile: 1 },
  winter: { name: 'Зимний', paper: '#F0F5F9', ink: '#1F2E3C', accent: '#3A6383', dark: '#243B51', light: '#CCE9FA', tile: 2 },
  summer: { name: 'Летний', paper: '#FFF4D8', ink: '#362B19', accent: '#765117', dark: '#402B17', light: '#FFE3A0', tile: 3 },
  burgundy: { name: 'Осенний', paper: '#FAEEE7', ink: '#34232A', accent: '#793B4C', dark: '#38232C', light: '#F5C9B9', tile: 4 }
};
export const today = () => dateString(new Date());
export function dateString(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}
export function parseDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value || '')) throw new Error('Укажите дату.');
  const [year, month, day] = value.split('-').map(Number);
  const date = new Date(year, month - 1, day, 12);
  if (year < 1900 || year > 9998 || dateString(date) !== value) throw new Error('Проверьте дату.');
  return date;
}
export function shiftDate(value, days) {
  const date = parseDate(value); date.setDate(date.getDate() + days); return dateString(date);
}
export function addPeriod(value, period, direction = 1) {
  if (period === 'week') return shiftDate(value, 7 * direction);
  const date = parseDate(value), day = date.getDate();
  date.setDate(1);
  date.setMonth(date.getMonth() + (period === 'year' ? 12 : 1) * direction);
  const last = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  date.setDate(Math.min(day, last));
  return dateString(date);
}
export function dateLabel(value, options = { day: 'numeric', month: 'long' }) {
  return parseDate(value).toLocaleDateString('ru-RU', options);
}
export const id = () => crypto.randomUUID().replaceAll('-', '');
export const emptyState = () => ({ schema: 1, entries: [], columns: [], accounts: [], categories: [], operations: [], settings: { theme: 'emerald' }, deleted: {} });
export function children(state, entry) { return state.entries.filter(item => item.parentId === entry.id); }
export function progress(state, entry) {
  const related = children(state, entry);
  if (entry.kind === 'task' || !related.length) return { done: entry.checked ? 1 : 0, total: 1, percent: entry.checked ? 100 : 0, complete: !!entry.checked };
  const done = related.filter(child => progress(state, child).complete).length;
  return { done, total: related.length, percent: Math.floor(done * 100 / related.length), complete: done === related.length };
}
export function canComplete(state, entry) { return children(state, entry).every(child => progress(state, child).complete); }
export function archived(entry) { return !!entry.checked || !!entry.mastered; }
export function orderEntries(entries) {
  return [...entries].sort((a, b) => (a.targetDay || a.day || '9999').localeCompare(b.targetDay || b.day || '9999') ||
    (a.time || '99:99').localeCompare(b.time || '99:99') || (a.createdAt || '').localeCompare(b.createdAt || '') || a.id.localeCompare(b.id));
}
export function saveEntry(state, draft) {
  const entry = structuredClone(draft);
  entry.title = (entry.title || '').trim();
  if (!entry.title || entry.title.length > 220) throw new Error('Введите название до 220 символов.');
  if (!kinds.includes(entry.kind)) throw new Error('Неизвестный тип записи.');
  entry.priority = Number(entry.priority || 0);
  if (![0, 1, 2, 3].includes(entry.priority)) throw new Error('Выберите важность.');
  if (['task', 'goal', 'event', 'habit'].includes(entry.kind)) parseDate(entry.day);
  if (entry.day) parseDate(entry.day);
  if (entry.time && !/^([01]\d|2[0-3]):[0-5]\d$/.test(entry.time)) throw new Error('Проверьте время.');
  if (entry.kind === 'goal') {
    if (!['week', 'month', 'year'].includes(entry.period)) throw new Error('Выберите срок цели.');
    const original = state.entries.find(item => item.id === entry.id);
    if (!original || original.day !== entry.day || original.period !== entry.period) entry.targetDay = addPeriod(entry.day, entry.period);
    entry.parentId = null;
  }
  if (entry.kind === 'subgoal') {
    if (!state.entries.some(item => item.id === entry.parentId && item.kind === 'goal')) throw new Error('Выберите цель.');
    if (!!entry.day !== !!entry.targetDay) throw new Error('Укажите начало и завершение подцели.');
    if (entry.day && entry.targetDay < entry.day) throw new Error('Завершение должно быть после начала.');
  }
  if (entry.kind === 'task' && entry.parentId) {
    const parent = state.entries.find(item => item.id === entry.parentId && item.kind === 'subgoal');
    const original = state.entries.find(item => item.id === entry.id);
    if (!parent || parent.checked && original?.parentId !== parent.id) throw new Error('Выберите активную подцель.');
  }
  if (entry.kind === 'event' || entry.kind === 'habit') entry.parentId = null;
  if (entry.reminderAt && !Number.isFinite(Date.parse(entry.reminderAt))) throw new Error('Проверьте время напоминания.');
  entry.id ||= id();
  entry.notes ||= '';
  entry.createdAt ||= new Date().toISOString();
  entry.updatedAt = new Date().toISOString();
  const index = state.entries.findIndex(item => item.id === entry.id);
  if (index < 0) state.entries.push(entry); else state.entries[index] = entry;
  reconcile(state);
  return entry;
}
export function toggleEntry(state, entryId) {
  const entry = state.entries.find(item => item.id === entryId);
  if (!entry) throw new Error('Запись удалена.');
  if (!entry.checked && !canComplete(state, entry)) throw new Error('Сначала выполните связанные задачи.');
  entry.checked = !entry.checked;
  entry.completedOn = entry.checked ? today() : null;
  entry.archivedOn = entry.checked ? today() : null;
  entry.updatedAt = new Date().toISOString();
  reconcile(state);
}
export function reconcile(state) {
  for (const step of state.entries.filter(item => item.kind === 'subgoal')) {
    if (step.checked && !canComplete(state, step)) { step.checked = false; step.archivedOn = null; step.completedOn = null; }
  }
  for (const goal of state.entries.filter(item => item.kind === 'goal')) {
    if (goal.checked && !canComplete(state, goal)) { goal.checked = false; goal.archivedOn = null; goal.completedOn = null; }
  }
}
export function removeEntry(state, entryId) {
  const removed = new Set([entryId]);
  for (let level = 0; level < 3; level++) for (const entry of state.entries) if (removed.has(entry.parentId)) removed.add(entry.id);
  state.entries = state.entries.filter(entry => !removed.has(entry.id));
  for (const value of removed) state.deleted[value] = new Date().toISOString();
  reconcile(state);
}
export function habitStreak(entry, day = today()) {
  const marks = new Set(entry.marks || []);
  let cursor = entry.mastered || day;
  if (!entry.mastered && !marks.has(cursor)) cursor = shiftDate(cursor, -1);
  let count = 0;
  while (marks.has(cursor)) { count++; cursor = shiftDate(cursor, -1); }
  return count;
}
export function markHabit(entry, day = today()) {
  if (entry.mastered) return false;
  const marks = new Set(entry.marks || []);
  if (marks.has(day)) marks.delete(day); else marks.add(day);
  entry.marks = [...marks].sort();
  entry.updatedAt = new Date().toISOString();
  if (habitStreak(entry, day) >= 63) { entry.mastered = day; return true; }
  return false;
}
export function expireArchive(state, day = today()) {
  const cutoff = addPeriod(day, 'month', -1);
  for (const entry of state.entries) if (entry.archivedOn && entry.archivedOn <= cutoff) {
    if (entry.kind === 'task') entry.title = '';
    entry.notes = ''; entry.archivedOn = null;
  }
}

export function parseMoney(text, signed = false) {
  const value = String(text).trim().replace(/[\s\u00a0\u202f]/g, '').replace(',', '.');
  if (!/^-?\d+(\.\d{1,2})?$/.test(value)) throw new Error('Укажите сумму с точностью до копейки.');
  const negative = value.startsWith('-'), [whole, fraction = ''] = value.replace('-', '').split('.');
  const result = (BigInt(whole) * 100n + BigInt(fraction.padEnd(2, '0'))) * (negative ? -1n : 1n);
  if ((!signed && result <= 0n) || result > 99999999999999n || result < -99999999999999n) throw new Error('Проверьте сумму.');
  return result.toString();
}
export function money(amount) {
  const value = BigInt(amount || 0), negative = value < 0n, absolute = negative ? -value : value;
  return `${negative ? '−' : ''}${(absolute / 100n).toLocaleString('ru-RU')},${String(absolute % 100n).padStart(2, '0')} ₽`;
}
export function moneyInput(amount) {
  const value = BigInt(amount || 0), negative = value < 0n, absolute = negative ? -value : value;
  return `${negative ? '-' : ''}${absolute / 100n},${String(absolute % 100n).padStart(2, '0')}`;
}
export function totals(operations) {
  const income = operations.filter(item => item.kind === 'income').reduce((sum, item) => sum + BigInt(item.amount), 0n);
  const expense = operations.filter(item => item.kind === 'expense').reduce((sum, item) => sum + BigInt(item.amount), 0n);
  return { income, expense, net: income - expense };
}
export function balance(state, account, day = today()) {
  return state.operations.filter(item => item.day <= day).reduce((sum, item) => {
    if (item.accountId === account.id) sum += BigInt(item.amount) * (item.kind === 'income' ? 1n : -1n);
    if (item.kind === 'transfer' && item.destinationId === account.id) sum += BigInt(item.amount);
    return sum;
  }, BigInt(account.opening));
}
export function saveOperation(state, draft) {
  const operation = structuredClone(draft);
  parseDate(operation.day);
  if (!['income', 'expense', 'transfer'].includes(operation.kind)) throw new Error('Выберите тип операции.');
  const original = state.operations.find(item => item.id === operation.id);
  const account = state.accounts.find(item => item.id === operation.accountId);
  if (!account || account.archived && original?.accountId !== account.id) throw new Error('Выберите счёт.');
  if (!/^\d+$/.test(String(operation.amount)) || BigInt(operation.amount) <= 0n || BigInt(operation.amount) > 99999999999999n) throw new Error('Укажите сумму больше нуля.');
  if (operation.kind === 'transfer') {
    const destination = state.accounts.find(item => item.id === operation.destinationId);
    if (!destination || destination.id === account.id || destination.archived && original?.destinationId !== destination.id) throw new Error('Выберите другой счёт зачисления.');
    operation.categoryId = null;
  } else {
    const category = state.categories.find(item => item.id === operation.categoryId && item.kind === operation.kind);
    if (!category || category.archived && original?.categoryId !== category.id) throw new Error('Выберите категорию.');
    operation.destinationId = null;
  }
  operation.id ||= id(); operation.amount = String(operation.amount); operation.notes ||= '';
  operation.createdAt ||= new Date().toISOString(); operation.updatedAt = new Date().toISOString();
  const index = state.operations.findIndex(item => item.id === operation.id);
  if (index < 0) state.operations.push(operation); else state.operations[index] = operation;
  return operation;
}
export function validateState(state) {
  if (!state || state.schema !== 1) throw new Error('Неподдерживаемый формат данных.');
  for (const key of ['entries', 'columns', 'accounts', 'categories', 'operations']) {
    if (!Array.isArray(state[key]) || state[key].length > 50000) throw new Error('Проверьте файл данных.');
    const ids = new Set();
    for (const item of state[key]) {
      if (!/^[a-zA-Z0-9_-]{1,80}$/.test(item.id) || ids.has(item.id)) throw new Error('Повторяющиеся идентификаторы.');
      ids.add(item.id);
    }
  }
  for (const entry of state.entries) {
    if (!kinds.includes(entry.kind) || typeof entry.title !== 'string' || entry.title.length > 220) throw new Error('Некорректная запись.');
    if (entry.day) parseDate(entry.day);
    if (['task', 'goal', 'habit', 'event'].includes(entry.kind) && !entry.day && !(entry.kind === 'task' && entry.checked)) throw new Error('У записи отсутствует дата.');
    if (['goal', 'habit', 'event'].includes(entry.kind) && entry.parentId) throw new Error('Некорректная связь записи.');
    if (entry.kind === 'subgoal' && !state.entries.some(parent => parent.id === entry.parentId && parent.kind === 'goal')) throw new Error('У подцели отсутствует цель.');
    if (entry.kind === 'task' && entry.parentId && !state.entries.some(parent => parent.id === entry.parentId && parent.kind === 'subgoal')) throw new Error('У задачи отсутствует подцель.');
    if (entry.time && !/^([01]\d|2[0-3]):[0-5]\d$/.test(entry.time)) throw new Error('Некорректное время.');
    if (entry.targetDay) parseDate(entry.targetDay);
    if (entry.reminderAt && !Number.isFinite(Date.parse(entry.reminderAt))) throw new Error('Некорректное напоминание.');
    if (entry.marks && (!Array.isArray(entry.marks) || entry.marks.length > 100000)) throw new Error('Некорректная история привычки.');
    for (const mark of entry.marks || []) parseDate(mark);
  }
  for (const account of state.accounts) {
    if (typeof account.name !== 'string' || !account.name.trim() || account.name.length > 100) throw new Error('Проверьте название счёта.');
    if (!/^-?\d+$/.test(String(account.opening)) || BigInt(account.opening) > 99999999999999n || BigInt(account.opening) < -99999999999999n) throw new Error('Проверьте остаток счёта.');
  }
  for (const category of state.categories) if (!['income', 'expense'].includes(category.kind) || !category.name?.trim() || category.name.length > 100) throw new Error('Проверьте категорию.');
  const copied = { ...state, operations: [...state.operations] };
  for (const operation of state.operations) saveOperation(copied, operation);
  if (!themes[state.settings?.theme]) state.settings = { ...state.settings, theme: 'emerald' };
  state.deleted ||= {};
  return state;
}
export function mergeStates(base, local, remote) {
  const merged = structuredClone(remote), conflicts = [];
  merged.deleted = {};
  for (const key of new Set([...Object.keys(base.deleted), ...Object.keys(local.deleted), ...Object.keys(remote.deleted)])) {
    const value = local.deleted[key] !== base.deleted[key] ? local.deleted[key] : remote.deleted[key];
    if (value) merged.deleted[key] = value;
  }
  for (const key of ['entries', 'columns', 'accounts', 'categories', 'operations']) {
    const before = new Map(base[key].map(item => [item.id, item]));
    const mine = new Map(local[key].map(item => [item.id, item]));
    const theirs = new Map(remote[key].map(item => [item.id, item]));
    const result = [];
    for (const entryId of new Set([...before.keys(), ...mine.keys(), ...theirs.keys()])) {
      const b = before.get(entryId), l = mine.get(entryId), r = theirs.get(entryId);
      const localChanged = JSON.stringify(l) !== JSON.stringify(b), remoteChanged = JSON.stringify(r) !== JSON.stringify(b);
      const conflict = localChanged && remoteChanged && JSON.stringify(l) !== JSON.stringify(r);
      if (conflict) conflicts.push({ key, id: entryId });
      const choice = localChanged ? l : r;
      if (conflict) { if (choice) delete merged.deleted[entryId]; else merged.deleted[entryId] = local.deleted[entryId] || new Date().toISOString(); }
      if (choice && !merged.deleted[entryId]) result.push(choice);
    }
    merged[key] = result;
  }
  merged.settings = { ...remote.settings };
  for (const [key, value] of Object.entries(local.settings)) {
    if (JSON.stringify(value) === JSON.stringify(base.settings[key])) continue;
    if (JSON.stringify(remote.settings[key]) !== JSON.stringify(base.settings[key]) && JSON.stringify(remote.settings[key]) !== JSON.stringify(value)) conflicts.push({ key: 'settings', id: key });
    merged.settings[key] = value;
  }
  return { state: merged, conflicts };
}
