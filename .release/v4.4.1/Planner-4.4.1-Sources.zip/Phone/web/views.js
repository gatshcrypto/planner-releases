import { today, shiftDate, parseDate, dateString, dateLabel, addPeriod, progress, children, canComplete, orderEntries, habitStreak, balance, money, totals } from './domain.js';
import { escapeHtml as esc, button, empty, ring } from './ui.js';

export const sections = [
  ['tasks', 'Задачи', '✓'], ['subgoals', 'Подцели', '≡'], ['goals', 'Цели', '⚑'],
  ['habits', 'Привычки', '✦'], ['events', 'События', '▦'], ['finance', 'Учёт финансов', '₽'],
  ['finance-summary', 'Сводка финансов', '◉'], ['summary', 'Сводка', '▥']
];
const periodNames = { week: 'Неделя', month: 'Месяц', year: 'Год' };
export const priorityNames = ['Обычная · серая', 'Средняя · синяя', 'Высокая · жёлтая', 'Срочная · красная'];
export const priorityColors = ['#837e75', '#2562a3', '#a06a11', '#c73145'];
const categoryColors = ['#538b78', '#5485af', '#b9774e', '#9971a5', '#b29142', '#c46a79', '#659da1', '#8c9562'];

export function renderNavigation(app) {
  document.querySelector('#rail').innerHTML = `<div class="brand"><img src="/icon.png" alt="">Планер</div>${sections.map(([key, label, symbol], index) =>
    `${[3, 5, 7].includes(index) ? '<hr>' : ''}${button(`<span class="nav-symbol">${symbol}</span>${label}`, 'navigate', key, app.section === key ? 'active' : '')}`).join('')}<hr>${button('<span class="nav-symbol">◷</span>Помодоро', 'pomodoro')}${button('<span class="nav-symbol">⚙</span>Настройки', 'settings', '', 'rail-settings')}`;
  const nav = document.querySelector('#bottom-nav');
  const position = nav.scrollLeft;
  const changed = nav.dataset.section !== app.section;
  nav.innerHTML = sections.map(([key, label, symbol]) => button(`<span class="nav-symbol">${symbol}</span>${label}`, 'navigate', key,
    app.section === key ? 'active' : '', `aria-current="${app.section === key ? 'page' : 'false'}"`)).join('') +
    button('<span class="nav-symbol">◷</span>Помодоро', 'pomodoro') + button('<span class="nav-symbol">⚙</span>Настройки', 'settings');
  nav.scrollLeft = position;
  nav.dataset.section = app.section;
  if (changed) {
    const active = nav.querySelector('[aria-current="page"]');
    if (active && nav.clientWidth) {
      const item = active.getBoundingClientRect(), viewport = nav.getBoundingClientRect();
      if (item.left < viewport.left + 10) nav.scrollLeft += item.left - viewport.left - 10;
      else if (item.right > viewport.right - 10) nav.scrollLeft += item.right - viewport.right + 10;
    }
  }
  document.querySelector('#section-title').textContent = sections.find(item => item[0] === app.section)?.[1] || 'Ещё';
  document.querySelector('#context-date').textContent = dateLabel(today(), { weekday: 'long', day: 'numeric', month: 'long' });
  document.querySelector('#add-button').hidden = ['summary', 'more'].includes(app.section);
}
export function renderSection(app) {
  switch (app.section) {
    case 'tasks': return renderTasks(app);
    case 'subgoals': return renderEntities(app, 'subgoal');
    case 'goals': return renderEntities(app, 'goal');
    case 'habits': return renderHabits(app);
    case 'events': return renderEvents(app);
    case 'finance': return renderFinance(app);
    case 'finance-summary': return renderFinanceSummary(app);
    case 'summary': return renderSummary(app);
    default: return `<div class="more-grid">${sections.filter(item => !['tasks', 'goals', 'habits', 'events'].includes(item[0])).map(([key, name, symbol]) =>
      button(`<span class="nav-symbol">${symbol}</span>${name}`, 'navigate', key, '')).join('')}${button('<span class="nav-symbol">◷</span>Помодоро', 'pomodoro', '', '')}</div>`;
  }
}
function hero(percent, title, description, extra = '') {
  return `<section class="hero">${percent === null ? '' : ring(percent)}<div class="hero-copy"><h2>${esc(title)}</h2><p class="small muted">${esc(description)}</p>${extra}</div></section>`;
}
function navigation(label, action, nowAction = '', mode = '') {
  return `<div class="toolbar"><strong>${esc(label)}</strong><div class="navigation">${button('‹', action, '-1', 'icon-button', 'aria-label="Предыдущий период"')}${button('›', action, '1', 'icon-button', 'aria-label="Следующий период"')}${nowAction ? button(mode || 'Сегодня', nowAction) : ''}</div></div>`;
}
export function taskRow(app, entry, showCompleted = false) {
  const parent = app.state.entries.find(item => item.id === entry.parentId);
  const color = priorityColors[entry.priority || 0];
  const overdue = !entry.checked && entry.day && entry.day < today();
  const completed = !!entry.checked;
  const checkVisible = entry.kind === 'task' || canComplete(app.state, entry);
  const entryProgress = progress(app.state, entry);
  return `<div class="task-row${overdue ? ' overdue' : ''}" style="--priority:${color}" data-entry-id="${entry.id}">
    ${checkVisible ? button(completed ? '✓' : '', 'toggle', entry.id, `check${completed ? ' checked' : ''}`, `aria-label="${completed ? 'Вернуть в работу' : 'Выполнить'} ${esc(entry.title)}" aria-pressed="${completed}"`) : '<span class="check spacer"></span>'}
    <div class="task-body">${button(`<span class="task-title">${esc(entry.title)}</span>`, 'details', entry.id, 'task-body')}
    <div class="task-meta">${entry.time ? `<span>${entry.time}</span>` : ''}${app.overdue || entry.kind === 'subgoal' ? `<span>${entry.targetDay ? dateLabel(entry.targetDay) : entry.kind === 'task' ? dateLabel(entry.day) : ''}</span>` : ''}
    ${parent ? button(esc(parent.title), 'details', parent.id, 'link') : ''}${entry.reminderAt ? '<span class="reminder-badge" aria-label="Напоминание">◷</span>' : ''}</div></div>
    ${entry.kind === 'subgoal' && children(app.state, entry).length ? ring(entryProgress.percent, 'small-ring', 'Прогресс подцели') : ''}
    ${entry.kind !== 'habit' ? `<span class="priority-flag" title="${priorityNames[entry.priority || 0]}">⚑</span>` : ''}
    ${entry.kind === 'task' && !completed ? button('···', 'task-menu', entry.id, 'more-button', 'aria-label="Действия с задачей"') : ''}</div>`;
}
function board(app, entries, kind) {
  const columnId = entry => entry.columnId || app.state.entries.find(parent => parent.id === entry.parentId)?.columnId ||
    app.state.entries.find(parent => parent.id === app.state.entries.find(step => step.id === entry.parentId)?.parentId)?.columnId;
  const render = entry => kind === 'goal' ? goalCard(app, entry) : taskRow(app, entry);
  let result = '';
  if (app.state.columns.length) result += `<div class="columns">${[...app.state.columns].sort((a, b) => a.position - b.position).map(column =>
    `<section class="column"><div class="column-heading"><span>${esc(column.title)}</span>${button('···', 'column-menu', column.id, 'more-button', 'aria-label="Изменить столбец"')}</div>${entries.filter(entry => columnId(entry) === column.id).map(render).join('')}${button('+ Добавить', 'add-column-entry', column.id, 'link')}</section>`).join('')}${button('+ Столбец', 'column-new', '', 'outline-button column-add')}</div>`;
  const unassigned = entries.filter(entry => !columnId(entry) || !app.state.columns.some(column => column.id === columnId(entry)));
  if (unassigned.length) result += `<section class="${kind === 'goal' ? '' : 'card'}">${unassigned.map(render).join('')}</section>`;
  if (!entries.length) result += empty(kind === 'task' ? app.overdue ? 'Просроченных задач нет' : 'На этот день задач нет' : kind === 'goal' ? 'Активных целей пока нет' : 'Активных подцелей пока нет', 'add');
  if (!app.state.columns.length) result += button('+ Столбец', 'column-new', '', 'plain-button');
  return result;
}
function renderTasks(app) {
  const dayTasks = app.state.entries.filter(entry => entry.kind === 'task' && entry.day === app.date);
  const done = dayTasks.filter(entry => entry.checked).length;
  const percent = dayTasks.length ? Math.floor(done * 100 / dayTasks.length) : 0;
  let result = hero(dayTasks.length ? percent : null, dayTasks.length && done === dayTasks.length ? 'Всё запланированное выполнено' : 'Задачи дня', dateLabel(app.date, { day: 'numeric', month: 'long', year: 'numeric' }));
  result += navigation(dateLabel(app.date, { day: 'numeric', month: 'long' }), 'day-shift', 'day-now');
  const start = app.chartStart || shiftDate(app.date, -3);
  result += `<div class="date-strip">${Array.from({ length: 7 }, (_, index) => {
    const day = shiftDate(start, index), tasks = app.state.entries.filter(item => item.kind === 'task' && item.day === day);
    const percentage = tasks.length ? `${Math.floor(tasks.filter(item => item.checked).length * 100 / tasks.length)}%` : '—';
    return button(`<span>${dateLabel(day, { weekday: 'short' })}</span><span class="date-number">${parseDate(day).getDate()}</span><span class="day-percent">${percentage}</span>`, 'select-day', day,
      `day-button${day === app.date ? ' active' : ''}${day === today() ? ' today' : ''}`);
  }).join('')}</div><div class="navigation">${button('‹ Неделя', 'chart-shift', '-7', 'plain-button')}${button('Неделя ›', 'chart-shift', '7', 'plain-button')}</div>`;
  result += `<div class="filters">${button('Все', 'task-filter', 'all', app.overdue ? '' : 'active')}${button('Просроченные', 'task-filter', 'overdue', app.overdue ? 'active' : '')}</div>`;
  const tasks = app.overdue ? app.state.entries.filter(item => item.kind === 'task' && !item.checked && item.day < today()) : dayTasks.filter(item => !item.checked);
  return result + board(app, orderEntries(tasks), 'task');
}
function goalCard(app, goal) {
  const measured = progress(app.state, goal);
  return `<div class="card goal-card">${!children(app.state, goal).length ? button(goal.checked ? '✓' : '', 'toggle', goal.id, `check${goal.checked ? ' checked' : ''}`, 'aria-label="Выполнить цель"') : ''}
    ${button(`<h3 class="task-title">${esc(goal.title)}</h3><p class="goal-date">${periodNames[goal.period]} · до ${dateLabel(goal.targetDay)}</p><div class="progress-track"><i style="width:${measured.percent}%"></i></div>`, 'details', goal.id, 'goal-body')}${ring(measured.percent, 'small-ring', 'Прогресс цели')}</div>`;
}
function renderEntities(app, kind) {
  const entries = orderEntries(app.state.entries.filter(entry => entry.kind === kind && (kind === 'goal' ? progress(app.state, entry).complete === !!app.goalCompleted : !entry.checked)));
  let result = '';
  if (kind === 'goal') {
    const selected = entries.find(item => item.id === app.goalId) || entries[0];
    result = selected ? hero(progress(app.state, selected).percent, selected.title, `До ${dateLabel(selected.targetDay)}`,
      `<div class="navigation">${button('‹', 'goal-page', '-1', 'plain-button', 'aria-label="Предыдущая цель"')}${button('Открыть', 'details', selected.id, 'plain-button')}${button('›', 'goal-page', '1', 'plain-button', 'aria-label="Следующая цель"')}</div>`) : hero(null, 'Цели', 'Активных целей пока нет');
    if (selected) app.goalId = selected.id;
  }
  if (kind === 'goal') result += `<div class="filters">${button('В работе', 'goal-filter', 'active', app.goalCompleted ? '' : 'active')}${button('Выполненные', 'goal-filter', 'completed', app.goalCompleted ? 'active' : '')}</div>`;
  return result + board(app, entries, kind);
}
function renderHabits(app) {
  const habits = app.state.entries.filter(item => item.kind === 'habit' && (!!item.mastered === !!app.mastered));
  const active = app.state.entries.filter(item => item.kind === 'habit' && !item.mastered);
  const done = active.filter(item => item.marks?.includes(today())).length;
  let result = hero(active.length ? Math.floor(done * 100 / active.length) : null, 'Привычки сегодня', dateLabel(today()));
  result += `<div class="filters">${button('Активные', 'habit-filter', 'active', app.mastered ? '' : 'active')}${button('Освоенные', 'habit-filter', 'mastered', app.mastered ? 'active' : '')}</div>`;
  if (!habits.length) return result + empty(app.mastered ? 'Освоенных привычек пока нет' : 'Привычек пока нет', app.mastered ? '' : 'add');
  return result + habits.map(habit => `<section class="card"><div class="habit-row">${habit.mastered ? '' : button(habit.marks?.includes(today()) ? '✓' : '', 'habit-mark', habit.id,
    `check${habit.marks?.includes(today()) ? ' checked' : ''}`, `aria-label="Отметить привычку ${esc(habit.title)}"`)}${button(`<h3>${esc(habit.title)}</h3>`, 'details', habit.id, 'task-body')}${button('···', 'details', habit.id, 'more-button', 'aria-label="Открыть привычку"')}</div>
    <div class="habit-history">${Array.from({ length: 21 }, (_, index) => { const day = shiftDate(habit.mastered || today(), index - 20); return `<span class="${habit.marks?.includes(day) ? 'marked' : ''}" title="${dateLabel(day)}"></span>`; }).join('')}</div>
    <p class="small muted">${habit.mastered ? 'Освоена ' + dateLabel(habit.mastered) : `<span class="streak-number">${habitStreak(habit)} дн.</span> · текущая серия`}</p></section>`).join('');
}
function renderEvents(app) {
  const month = app.eventDate.slice(0, 7), events = app.state.entries.filter(item => item.kind === 'event' && item.day.startsWith(month));
  const nearest = orderEntries(app.state.entries.filter(item => item.kind === 'event' && item.day >= today()))[0];
  let result = hero(null, 'Календарь событий', nearest ? `${nearest.title} · ${dateLabel(nearest.day)}` : 'Ближайших событий нет');
  result += navigation(dateLabel(`${month}-01`, { month: 'long', year: 'numeric' }), 'event-month', 'event-now');
  const first = `${month}-01`, offset = (parseDate(first).getDay() + 6) % 7, start = shiftDate(first, -offset);
  result += `<section class="card"><div class="calendar">${['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'].map(day => `<span class="weekday">${day}</span>`).join('')}${Array.from({ length: 42 }, (_, index) => {
    const day = shiftDate(start, index), exists = app.state.entries.some(item => item.kind === 'event' && item.day === day);
    return button(`${parseDate(day).getDate()}${exists ? '<i class="event-dot"></i>' : '<i style="height:5px"></i>'}`, 'event-day', day,
      `calendar-day${day === app.eventDate ? ' selected' : ''}${day.startsWith(month) ? '' : ' outside'}${day === today() ? ' today' : ''}`);
  }).join('')}</div></section><div class="section-head"><h3>${dateLabel(app.eventDate)}</h3>${button('+ Событие', 'add', '', 'link')}</div>`;
  const dayEvents = orderEntries(events.filter(item => item.day === app.eventDate));
  return result + `<section class="card">${dayEvents.length ? dayEvents.map(event => button(`<span class="event-time">${event.time || 'Весь день'}</span><span><span class="event-title">${esc(event.title)}</span>${event.notes ? `<span class="task-meta">${esc(event.notes.slice(0, 100))}</span>` : ''}</span>`, 'details', event.id, 'event-row')).join('') : empty('На этот день событий нет', 'add', 'Добавить событие')}</section>`;
}
function metricGrid(labels, amounts) {
  return `<div class="metric-grid">${labels.map((label, index) => `<section class="metric ${['income', 'expense', 'net'][index]}"><p class="caption">${label}</p><strong class="amount">${money(amounts[index])}</strong></section>`).join('')}</div>`;
}
function financeNavigation(app, manage = true) {
  return navigation(app.financeYear ? app.financeDate.slice(0, 4) : dateLabel(app.financeDate, { month: 'long', year: 'numeric' }), 'finance-shift', 'finance-now', 'Сейчас') +
    `<div class="filters">${button('Месяц', 'finance-mode', 'month', app.financeYear ? '' : 'active')}${button('Год', 'finance-mode', 'year', app.financeYear ? 'active' : '')}</div>${manage ? `<div class="finance-tools">${button('Счета', 'accounts', '', 'outline-button')}${button('Категории', 'categories', '', 'outline-button')}</div>` : ''}`;
}
export function periodOperations(app) {
  return app.state.operations.filter(item => item.day.startsWith(app.financeDate.slice(0, app.financeYear ? 4 : 7)))
    .sort((a, b) => b.day.localeCompare(a.day) || (b.createdAt || '').localeCompare(a.createdAt || '') || a.id.localeCompare(b.id));
}
function financeDayHead(title, summary) {
  return `<div class="finance-day-head"><span class="day-name">${esc(title)}</span>${[['Доход', summary.income, 'income-text'], ['Расход', summary.expense, 'expense-text'], ['Итог', summary.net, '']].map(([label, amount, color]) => `<span><span class="caption">${label}</span><strong class="amount ${color}">${money(amount)}</strong></span>`).join('')}</div>`;
}
export function operationRow(app, operation) {
  const account = app.state.accounts.find(item => item.id === operation.accountId), category = app.state.categories.find(item => item.id === operation.categoryId);
  const destination = app.state.accounts.find(item => item.id === operation.destinationId);
  return button(`<span><strong>${esc(operation.kind === 'transfer' ? 'Перевод' : category?.name || 'Категория')}</strong><span class="operation-meta">${esc(account?.name)}${destination ? ' → ' + esc(destination.name) : ''}${operation.notes ? ' · ' + esc(operation.notes) : ''}</span></span><strong class="operation-amount ${operation.kind === 'income' ? 'income-text' : operation.kind === 'expense' ? 'expense-text' : ''}">${money(operation.amount)}</strong>`, 'operation', operation.id, 'finance-operation');
}
function renderFinance(app) {
  const operations = periodOperations(app), summary = totals(operations);
  let result = metricGrid(['Доход', 'Расход', 'Итог'], [summary.income, summary.expense, summary.net]) + financeNavigation(app);
  if (app.financeYear) return result + `<section class="card finance-day">${Array.from({ length: 12 }, (_, index) => 12 - index).map(month => {
    const prefix = `${app.financeDate.slice(0, 4)}-${String(month).padStart(2, '0')}`;
    return button(financeDayHead(dateLabel(`${prefix}-01`, { month: 'short' }), totals(operations.filter(item => item.day.startsWith(prefix)))), 'finance-month', `${prefix}-01`, 'year-month');
  }).join('')}</section>`;
  if (!operations.length) return result + empty('За этот месяц операций нет', 'add', 'Добавить операцию');
  const dates = [...new Set(operations.map(item => item.day))];
  return result + dates.map(day => { const daily = operations.filter(item => item.day === day); return `<section class="card finance-day">${financeDayHead(dateLabel(day, { day: 'numeric', month: 'short' }), totals(daily))}${daily.map(item => operationRow(app, item)).join('')}</section>`; }).join('');
}
function categoryChart(app, kind) {
  const grouped = new Map();
  for (const operation of periodOperations(app).filter(item => item.kind === kind)) grouped.set(operation.categoryId, (grouped.get(operation.categoryId) || 0n) + BigInt(operation.amount));
  const slices = [...grouped.entries()].map(([id, amount]) => ({ id, amount, name: app.state.categories.find(item => item.id === id)?.name || 'Категория' })).sort((a, b) => a.amount > b.amount ? -1 : a.amount < b.amount ? 1 : a.name.localeCompare(b.name));
  const total = slices.reduce((sum, slice) => sum + slice.amount, 0n);
  let angle = 0;
  const gradients = slices.map((slice, index) => { const start = angle; angle += Number(slice.amount * 10000n / total) / 100; return `${categoryColors[index % categoryColors.length]} ${start}% ${index === slices.length - 1 ? 100 : angle}%`; });
  return `<section class="card"><h3>${kind === 'expense' ? 'Расходы' : 'Доходы'} по категориям</h3><div class="donut" ${gradients.length ? `style="--slices:conic-gradient(${gradients.join(',')})"` : ''}><div class="donut-center"><span>${total ? kind === 'expense' ? 'Расход' : 'Доход' : 'Нет операций'}</span>${total ? `<strong>${money(total)}</strong>` : ''}</div></div>${slices.map((slice, index) => button(`<i class="legend-dot" style="--color:${categoryColors[index % categoryColors.length]}"></i><span class="legend-name">${esc(slice.name)} · ${(Number(slice.amount * 1000n / total) / 10).toLocaleString('ru-RU')}%</span><strong>${money(slice.amount)}</strong>`, 'category-history', slice.id, 'category-legend')).join('')}</section>`;
}
function renderFinanceSummary(app) {
  const accounts = app.state.accounts.map(account => ({ ...account, balance: balance(app.state, account) }));
  const assets = accounts.filter(item => item.balance > 0n).reduce((sum, item) => sum + item.balance, 0n);
  const debts = -accounts.filter(item => item.balance < 0n).reduce((sum, item) => sum + item.balance, 0n);
  return metricGrid(['Активы', 'Пассивы', 'Итог'], [assets, debts, assets - debts]) + `<section class="card"><div class="section-head" style="margin-top:0"><h3>Остатки на счетах</h3>${button('Счета', 'accounts', '', 'link')}</div>${accounts.length ? accounts.map(account => button(`<span>${esc(account.name)}${account.archived ? ' · архив' : ''}</span><strong class="${account.balance < 0n ? 'expense-text' : ''}">${money(account.balance)}</strong>`, 'account-edit', account.id, 'account-row')).join('') : empty('Счетов пока нет', 'account-new', 'Создать счёт')}</section>` + financeNavigation(app, false) + `<div class="charts">${categoryChart(app, 'expense')}${categoryChart(app, 'income')}</div>`;
}
function renderSummary(app) {
  const goals = app.state.entries.filter(item => item.kind === 'goal' && !progress(app.state, item).complete);
  const month = today().slice(0, 7), monthly = app.state.entries.filter(item => item.kind === 'task' && item.day?.startsWith(month));
  const done = monthly.filter(item => item.checked).length;
  let result = hero(monthly.length ? Math.floor(done * 100 / monthly.length) : null, 'Задачи за месяц', dateLabel(today(), { month: 'long', year: 'numeric' }));
  if (goals.length) result += `<div class="section-head"><h3>Цели</h3><span class="small muted">${goals.length}</span></div><div class="goal-grid">${orderEntries(goals).slice(app.goalPage * 6, app.goalPage * 6 + 6).map(goal => button(`${ring(progress(app.state, goal).percent, 'goal-ring')}<h3>${esc(goal.title)}</h3><p class="goal-date">До ${dateLabel(goal.targetDay)}</p>`, 'details', goal.id, 'card')).join('')}</div>${goals.length > 6 ? navigation(`${app.goalPage + 1} / ${Math.ceil(goals.length / 6)}`, 'summary-goals') : ''}`;
  const activeSteps = app.state.entries.filter(item => item.kind === 'subgoal' && !item.checked).length;
  const mastered = app.state.entries.filter(item => item.kind === 'habit' && item.mastered).length;
  result += `<div class="section-head"><h3>Результаты месяца</h3></div><div class="stats-grid"><div class="stat"><span class="small muted">Выполнено задач</span><strong>${done}</strong></div><div class="stat"><span class="small muted">Активных подцелей</span><strong>${activeSteps}</strong></div><div class="stat"><span class="small muted">Освоено привычек</span><strong>${mastered}</strong></div><div class="stat"><span class="small muted">Завершено целей</span><strong>${app.state.entries.filter(item => item.kind === 'goal' && progress(app.state, item).complete).length}</strong></div></div>`;
  result += `<div class="section-head"><h3>Выполнение по дням</h3></div><section class="card"><div class="bars">${Array.from({ length: 7 }, (_, index) => {
    const day = shiftDate(today(), index - 6), tasks = app.state.entries.filter(item => item.kind === 'task' && item.day === day), percent = tasks.length ? Math.floor(tasks.filter(item => item.checked).length * 100 / tasks.length) : 0;
    return `<div class="bar-column"><strong>${tasks.length ? percent + '%' : '—'}</strong><i style="--value:${percent}"></i><span>${dateLabel(day, { weekday: 'short' })}</span></div>`;
  }).join('')}</div></section>`;
  const habits = app.state.entries.filter(item => item.kind === 'habit');
  result += `<div class="section-head"><h3>Регулярность привычек</h3></div><section class="card"><div class="heatmap">${Array.from({ length: 91 }, (_, index) => { const day = shiftDate(today(), index - 90), eligible = habits.filter(habit => habit.day <= day && (!habit.mastered || habit.mastered >= day)), marked = eligible.filter(habit => habit.marks?.includes(day)).length; return `<i style="--intensity:${eligible.length ? Math.floor(marked * 100 / eligible.length) : 0}%" title="${dateLabel(day)}"></i>`; }).join('')}</div></section>`;
  return result;
}
