import { today, dateLabel, progress, children, canComplete, money, moneyInput, balance, themes, habitStreak } from './domain.js';
import { escapeHtml as esc, button, empty, options, field, input, textarea, select, formFooter, ring } from './ui.js';
import { sections, priorityNames, taskRow, operationRow, periodOperations } from './views.js';

export function showEntryForm(app, draft) {
  const existing = app.state.entries.some(item => item.id === draft.id);
  const labels = { task: 'Задача', goal: 'Цель', subgoal: 'Подцель', habit: 'Привычка', event: 'Событие' };
  let html = field('Название', input('title', draft.title, 'text', 'required maxlength="220" autocomplete="off"'));
  if (draft.kind !== 'habit') html += field('Важность', select('priority', priorityNames.map((name, index) => `<option value="${index}" ${index === (draft.priority || 0) ? 'selected' : ''}>⚑ ${name}</option>`).join('')));
  if (draft.kind === 'goal') html += field('Срок', select('period', [['week', 'Неделя'], ['month', 'Месяц'], ['year', 'Год']].map(([value, label]) => `<option value="${value}" ${value === (draft.period || 'month') ? 'selected' : ''}>${label}</option>`).join('')));
  if (draft.kind === 'subgoal') html += `<label class="toggle-field"><input type="checkbox" name="undated" ${draft.day ? '' : 'checked'}>Без срока</label>`;
  html += `<div class="${['task', 'event', 'subgoal'].includes(draft.kind) ? 'two-fields' : ''}">`;
  html += field(draft.kind === 'subgoal' ? 'Начало' : 'Дата', input('day', draft.day || (draft.kind === 'subgoal' ? '' : app.date), 'date', draft.kind === 'subgoal' && !draft.day ? 'disabled' : 'required'));
  if (draft.kind === 'task' || draft.kind === 'event') html += field('Время', input('time', draft.time, 'time', draft.kind === 'event' && !draft.time ? 'disabled' : ''));
  if (draft.kind === 'subgoal') html += field('Завершение', input('targetDay', draft.targetDay, 'date', !draft.day ? 'disabled' : 'required'));
  html += '</div>';
  if (draft.kind === 'event') html += `<label class="toggle-field"><input type="checkbox" name="allDay" ${draft.time ? '' : 'checked'}>Весь день</label>`;
  if (draft.kind === 'subgoal') html += field('Цель', select('parentId', options(app.state.entries.filter(item => item.kind === 'goal' && item.title), draft.parentId)));
  if (draft.kind === 'task') html += field('Подцель', select('parentId', options(app.state.entries.filter(item => item.kind === 'subgoal' && (!item.checked || existing && item.id === draft.parentId)), draft.parentId, 'Самостоятельная задача')));
  if (['task', 'goal'].includes(draft.kind) && app.state.columns.length) html += field('Столбец', select('columnId', options(app.state.columns, draft.columnId, 'Выбрать столбец')));
  if (['task', 'event'].includes(draft.kind)) {
    const local = draft.reminderAt ? new Date(new Date(draft.reminderAt).getTime() - new Date(draft.reminderAt).getTimezoneOffset() * 60000).toISOString().slice(0, 16) : '';
    html += field('Напоминание', input('reminderAt', local, 'datetime-local'));
  }
  html += field('Заметки', textarea('notes', draft.notes)) + formFooter(existing);
  app.sheet(existing ? labels[draft.kind] : `${draft.kind === 'event' ? 'Новое' : 'Новая'} ${labels[draft.kind].toLowerCase()}`, `<form data-form="entry">${html}</form>`, { ...draft });
}
export function showDetails(app, entryId) {
  const entry = app.state.entries.find(item => item.id === entryId);
  if (!entry) return app.close();
  const related = children(app.state, entry), measured = progress(app.state, entry);
  const parent = app.state.entries.find(item => item.id === entry.parentId);
  const checkVisible = entry.kind === 'task' || entry.kind === 'subgoal' && canComplete(app.state, entry) || entry.kind === 'goal' && !related.length;
  let body = `<div class="habit-row">${checkVisible ? button(entry.checked ? '✓' : '', 'detail-toggle', entry.id, `check${entry.checked ? ' checked' : ''}`, 'aria-label="Отметить выполнение"') : ''}<h3 class="detail-title" style="margin:0">${esc(entry.title)}</h3></div><div class="detail-actions">${button('Изменить', 'entry-edit', entryId, 'outline-button')}${parent ? button(esc(parent.title), 'details', parent.id, 'link') : ''}</div>`;
  if (['goal', 'subgoal'].includes(entry.kind) && related.length) body += `<div style="display:flex;align-items:center;gap:15px;margin:18px 0">${ring(measured.percent, 'goal-ring')}<span class="small muted">${entry.kind === 'goal' ? 'Выполнение цели' : 'Выполнение задач'}</span></div>`;
  if (entry.day) body += `<p class="small muted">${dateLabel(entry.day)}${entry.time ? ' · ' + entry.time : ''}${entry.targetDay ? ' — ' + dateLabel(entry.targetDay) : ''}</p>`;
  if (entry.kind === 'habit') body += `<p class="streak-number" style="margin-top:18px">${habitStreak(entry)} дн.</p>`;
  if (entry.notes) body += `<p class="detail-note">${esc(entry.notes)}</p>`;
  if (entry.reminderAt) body += `<p class="small muted" style="margin:15px 0">Напоминание · ${esc(new Date(entry.reminderAt).toLocaleString('ru-RU', { dateStyle: 'medium', timeStyle: 'short' }))}</p>`;
  if (entry.kind === 'goal' || entry.kind === 'subgoal') {
    body += `<div class="section-head"><h3>${entry.kind === 'goal' ? 'Подцели' : 'Задачи'}</h3>${!entry.checked ? button('+ Добавить', 'add-child', entry.id, 'link') : ''}</div>`;
    body += related.length ? related.filter(child => child.title).sort((a, b) => (a.targetDay || a.day || '9999').localeCompare(b.targetDay || b.day || '9999')).map(child => taskRow(app, child, true)).join('') : empty(entry.kind === 'goal' ? 'Подцелей пока нет' : 'Задач пока нет');
  }
  app.sheet(entry.kind === 'goal' ? 'Цель' : entry.kind === 'subgoal' ? 'Подцель' : entry.kind === 'habit' ? 'Привычка' : entry.kind === 'event' ? 'Событие' : 'Задача', body, { detailId: entry.id });
}
export function readOperation(app) {
  const form = document.querySelector('form[data-form="operation"]');
  if (!form) return app.draft;
  return { ...app.draft, ...Object.fromEntries(new FormData(form)), rawAmount: form.elements.amount.value };
}
export function showOperationForm(app, draft) {
  const existing = app.state.operations.some(item => item.id === draft.id);
  const kind = draft.kind || 'income';
  let html = `<div class="filters">${[['income', 'Доход'], ['expense', 'Расход'], ['transfer', 'Перевод']].map(([value, label]) => button(label, 'operation-kind', value, value === kind ? 'active' : '')).join('')}</div>`;
  html += field('Дата', input('day', draft.day || app.financeDate, 'date', 'required'));
  html += `<label class="field"><span>Сумма, ₽</span><div class="amount-input">${input('amount', draft.rawAmount ?? (draft.amount ? moneyInput(draft.amount) : ''), 'text', 'inputmode="decimal" required autocomplete="off"')}${button('▦', 'calculator', '', 'icon-button', 'aria-label="Калькулятор"')}</div></label>`;
  if (kind !== 'transfer') html += field(`Категория ${button('+ Создать', 'category-inline', '', 'link')}`, select('categoryId', options(app.state.categories.filter(item => item.kind === kind && (!item.archived || existing && item.id === draft.categoryId)), draft.categoryId)));
  const accounts = app.state.accounts.filter(item => !item.archived || existing && (item.id === draft.accountId || item.id === draft.destinationId));
  html += field(`${kind === 'transfer' ? 'Со счёта' : 'Счёт'} ${button('+ Создать', 'account-inline', 'source', 'link')}`, select('accountId', options(accounts, draft.accountId)));
  if (kind === 'transfer') html += field(`На счёт ${button('+ Создать', 'account-inline', 'destination', 'link')}`, select('destinationId', options(accounts, draft.destinationId)));
  html += field('Заметки', textarea('notes', draft.notes)) + formFooter(existing);
  app.sheet(existing ? 'Операция' : 'Новая операция', `<form data-form="operation">${html}</form>`, { ...draft, kind });
}
export function showAccountForm(app, account, inline = null) {
  app.sheet(account.id ? 'Счёт' : 'Новый счёт', `<form data-form="account">${field('Название', input('name', account.name, 'text', 'required maxlength="100"'))}${field('Начальный остаток, ₽', input('opening', account.opening ? moneyInput(account.opening) : '0,00', 'text', 'inputmode="decimal" required'))}<p class="small muted">Задолженность укажите со знаком минус.</p>${account.archived ? '<label class="toggle-field"><input name="archived" type="checkbox" checked>В архиве</label>' : ''}${formFooter(!!account.id)}</form>`, { ...account, _inline: inline });
}
export function showCategoryForm(app, category, inline = null) {
  const used = app.state.operations.some(item => item.categoryId === category.id);
  const type = `<select name="kind" ${used || inline ? 'disabled' : ''}><option value="income" ${category.kind === 'expense' ? '' : 'selected'}>Доход</option><option value="expense" ${category.kind === 'expense' ? 'selected' : ''}>Расход</option></select>`;
  app.sheet(category.id ? 'Категория' : 'Новая категория', `<form data-form="category">${field('Название', input('name', category.name, 'text', 'required maxlength="100"'))}${field('Тип', type)}${category.archived ? '<label class="toggle-field"><input name="archived" type="checkbox" checked>В архиве</label>' : ''}${formFooter(!!category.id)}</form>`, { ...category, kind: category.kind || 'income', _inline: inline });
}
export function showAccounts(app) {
  app.sheet('Счета', button('+ Создать счёт', 'account-new', '', 'primary-button full-width') + app.state.accounts.map(account => button(`<span>${esc(account.name)}${account.archived ? ' · архив' : ''}</span><strong class="${balance(app.state, account) < 0n ? 'danger' : ''}">${money(balance(app.state, account))}</strong>`, 'account-edit', account.id, 'account-row')).join(''));
}
export function showCategories(app) {
  let body = button('+ Создать категорию', 'category-new', '', 'primary-button full-width');
  for (const kind of ['income', 'expense']) body += `<div class="section-head"><h3>${kind === 'income' ? 'Доходы' : 'Расходы'}</h3></div>${app.state.categories.filter(item => item.kind === kind).map(item => button(`<span>${esc(item.name)}${item.archived ? ' · архив' : ''}</span><span>Изменить</span>`, 'category-edit', item.id, 'account-row')).join('')}`;
  app.sheet('Категории', body);
}
export function showSettings(app) {
  const installed = matchMedia('(display-mode: standalone)').matches || navigator.standalone;
  const pushAvailable = 'Notification' in window && 'PushManager' in window;
  let body = `<section class="settings-group"><h3>Оформление</h3><div class="theme-options">${Object.entries(themes).map(([key, theme]) => button(`<i style="--color:${theme.accent}"></i>${theme.name}`, 'theme', key, `theme-choice${app.state.settings.theme === key ? ' active' : ''}`)).join('')}</div></section>`;
  body += `<section class="settings-group"><h3>Синхронизация</h3>${app.storage.authNeeded ? button('Войти в планер', 'sign-in', '', 'settings-button') : button('Подключить другое устройство', 'pair-device', '', 'settings-button')}</section>`;
  body += `<section class="settings-group"><h3>Данные</h3><p class="status${app.storage.conflicts.length ? ' error' : ''}" id="sync-status">${esc(app.syncStatus)}</p>${button('Синхронизировать', 'sync', '', 'settings-button')}${app.storage.conflicts.length ? `<p class="small">Выберите изменения для записей, которые редактировались на двух устройствах.</p>${button('Сохранить мои изменения', 'resolve-conflict', 'local', 'settings-button')}${button('Принять изменения из облака', 'resolve-conflict', 'remote', 'settings-button')}` : ''}${button('Скачать резервную копию', 'export', '', 'settings-button')}${button('Импортировать данные', 'import', '', 'settings-button')}${button('Перенести данные с Windows', 'windows-import', '', 'settings-button')}${button('Архив', 'archive', '', 'settings-button')}</section>`;
  body += `<section class="settings-group"><h3>Напоминания</h3><p class="small muted">${pushAvailable ? Notification.permission === 'granted' ? 'Разрешение выдано' : 'Разрешение ещё не выдано' : 'Откройте планер с главного экрана iPhone'}</p>${button('Включить уведомления', 'enable-push', '', 'settings-button')}${button('Проверить уведомление', 'test-push', '', 'settings-button')}</section>`;
  if (!installed) body += `<section class="settings-group"><h3>Установка на iPhone</h3><p class="small muted">В Safari нажмите «Поделиться», затем «На экран Домой». Открывайте планер через появившуюся иконку.</p></section>`;
  body += `<section class="settings-group"><h3>Приложение</h3>${button('Проверить обновление', 'update-app', '', 'settings-button')}${button('Помодоро', 'pomodoro', '', 'settings-button')}<p class="small muted" style="margin-top:14px">Планер · iPhone 1.0</p></section>`;
  app.sheet('Настройки', body);
}
export function showArchive(app) {
  const entries = app.state.entries.filter(entry => ['task', 'subgoal'].includes(entry.kind) && entry.checked && entry.archivedOn && entry.title);
  app.sheet('Архив', entries.length ? `${entries.map(entry => `<div class="account-row"><span>${esc(entry.title)}</span>${button('Вернуть', 'restore', entry.id, 'link')}</div>`).join('')}<div class="form-actions">${button('Очистить архив', 'clear-archive', '', 'plain-button danger')}</div>` : empty('Архив пуст'));
}
export function showCategoryHistory(app, categoryId) {
  const category = app.state.categories.find(item => item.id === categoryId);
  const operations = periodOperations(app).filter(item => item.categoryId === categoryId);
  app.sheet(category.name, operations.map(item => `<p class="small muted" style="margin-top:12px">${dateLabel(item.day)}</p>${operationRow(app, item)}`).join(''));
}
export function showCalculator(app, draft) {
  app.calculatorDraft = draft;
  const labels = ['+', '−', '×', '÷', '7', '8', '9', '⌫', '4', '5', '6', 'C', '1', '2', '3', '=', '0', ',', 'Закрыть', 'Готово'];
  app.sheet('Калькулятор', `<form data-form="calculator"><input class="calculation" name="expression" value="${esc(draft.rawAmount || '')}" autocomplete="off" inputmode="decimal" aria-label="Выражение"><div class="keypad">${labels.map(label => button(label, 'calc-key', label, label === 'Готово' ? 'primary-button' : '')).join('')}</div><p class="form-error" role="alert"></p></form>`);
}
