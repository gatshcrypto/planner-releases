using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Web.Script.Serialization;
using System.Windows.Forms;

internal static class PlannerTransfer
{
    [STAThread]
    private static int Main(string[] arguments)
    {
        try
        {
            string source = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Planner", "planner.sqlite");
            string destination = null;
            for (int i = 0; i + 1 < arguments.Length; i++)
            {
                if (arguments[i] == "--source") source = arguments[++i];
                else if (arguments[i] == "--destination") destination = arguments[++i];
            }
            if (!File.Exists(source)) throw new IOException("База планера не найдена. Сначала откройте планер на этом компьютере.");
            if (destination == null)
            {
                using (var dialog = new SaveFileDialog { Filter = "Данные планера (*.json)|*.json", FileName = "planner-" + DateTime.Today.ToString("yyyy-MM-dd") + ".json", Title = "Сохранить данные для iPhone" })
                {
                    if (dialog.ShowDialog() != DialogResult.OK) return 0;
                    destination = dialog.FileName;
                }
            }
            using (var database = new Snapshot(source))
            {
                var marks = database.Read("SELECT habit,day FROM habit_marks").ToLookup(row => row[0], row => row[1]);
                string[] kinds = { "task", "goal", "subgoal", "habit", "event" };
                string[] periods = { "", "week", "month", "year" };
                var entries = database.Read("SELECT id,kind,title,priority,parent,day,period,checked,notes,scheduled_time,mastered,board_column,target_day,completed_on,archived_on,rowid FROM entries ORDER BY rowid").Select(row => new Dictionary<string, object>
                {
                    { "id", row[0] }, { "kind", kinds[Int32.Parse(row[1])] }, { "title", row[2] },
                    { "priority", Int32.Parse(row[3]) }, { "parentId", row[4] }, { "day", row[5] },
                    { "period", row[6] == null ? null : periods[Int32.Parse(row[6])] }, { "checked", row[7] == "1" },
                    { "notes", row[8] }, { "time", row[9] }, { "mastered", row[10] }, { "columnId", row[11] },
                    { "targetDay", row[12] }, { "completedOn", row[13] }, { "archivedOn", row[14] },
                    { "createdAt", new DateTime(1970,1,1,0,0,0,DateTimeKind.Utc).AddMilliseconds(Int64.Parse(row[15])).ToString("o") },
                    { "marks", marks[row[0]].ToArray() }
                }).ToArray();
                var columns = database.Read("SELECT id,title,position FROM board_columns ORDER BY position").Select(row => new { id = row[0], title = row[1], position = Int32.Parse(row[2]) }).ToArray();
                bool hasFinance = database.Read("SELECT name FROM sqlite_master WHERE name='finance_accounts'").Count > 0;
                var accounts = hasFinance ? database.Read("SELECT id,name,opening,archived FROM finance_accounts").Select(row => new { id = row[0], name = row[1], opening = row[2], archived = row[3] == "1" }).ToArray() : new object[0];
                var categories = hasFinance ? database.Read("SELECT id,name,kind,archived FROM finance_categories").Select(row => new { id = row[0], name = row[1], kind = row[2] == "0" ? "income" : "expense", archived = row[3] == "1" }).ToArray() : new object[0];
                string[] operationKinds = { "income", "expense", "transfer" };
                var operations = hasFinance ? database.Read("SELECT id,kind,day,amount,account_id,destination_id,category_id,notes,creation_order FROM finance_operations").Select(row => new
                {
                    id = row[0], kind = operationKinds[Int32.Parse(row[1])], day = row[2], amount = row[3], accountId = row[4], destinationId = row[5], categoryId = row[6], notes = row[7],
                    createdAt = new DateTime(Int64.Parse(row[8]), DateTimeKind.Utc).ToString("o")
                }).ToArray() : new object[0];
                string theme = database.Read("SELECT value FROM settings WHERE key='palette'").Select(row => row[0]).FirstOrDefault() ?? "emerald";
                var result = new { format = "planner-backup", exportedAt = DateTime.UtcNow.ToString("o"), state = new { schema = 1, entries, columns, accounts, categories, operations, settings = new { theme }, deleted = new Dictionary<string, string>() } };
                var serializer = new JavaScriptSerializer { MaxJsonLength = Int32.MaxValue };
                File.WriteAllText(destination, serializer.Serialize(result), new UTF8Encoding(false));
            }
            if (arguments.Length == 0) MessageBox.Show("Файл сохранён. Передайте его на iPhone и откройте в планере «Настройки → Импортировать данные».", "Перенос данных");
            return 0;
        }
        catch (Exception error)
        {
            if (arguments.Length == 0) MessageBox.Show(error.Message, "Перенос данных", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else Console.Error.WriteLine(error.Message);
            return 1;
        }
    }

    private sealed class Snapshot : IDisposable
    {
        private IntPtr connection;
        public Snapshot(string file)
        {
            Check(sqlite3_open_v2(Utf8(file), out connection, 1, IntPtr.Zero));
            sqlite3_busy_timeout(connection, 5000);
            Read("BEGIN");
        }
        public List<string[]> Read(string sql)
        {
            IntPtr statement;
            Check(sqlite3_prepare_v2(connection, Utf8(sql), -1, out statement, IntPtr.Zero));
            try
            {
                var rows = new List<string[]>();
                int result;
                while ((result = sqlite3_step(statement)) == 100)
                {
                    var row = new string[sqlite3_column_count(statement)];
                    for (int i = 0; i < row.Length; i++)
                        row[i] = sqlite3_column_type(statement, i) == 5 ? null : Marshal.PtrToStringUni(sqlite3_column_text16(statement, i), sqlite3_column_bytes16(statement, i) / 2);
                    rows.Add(row);
                }
                if (result != 101) Check(result);
                return rows;
            }
            finally { sqlite3_finalize(statement); }
        }
        private void Check(int code)
        {
            if (code != 0) throw new IOException("Не удалось прочитать базу планера. " + (connection == IntPtr.Zero ? "" : Marshal.PtrToStringUni(sqlite3_errmsg16(connection))));
        }
        private static byte[] Utf8(string value) { return Encoding.UTF8.GetBytes(value + "\0"); }
        public void Dispose() { if (connection != IntPtr.Zero) { sqlite3_close(connection); connection = IntPtr.Zero; } }
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] private static extern int sqlite3_open_v2(byte[] file, out IntPtr db, int flags, IntPtr vfs);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] private static extern int sqlite3_close(IntPtr db);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] private static extern int sqlite3_busy_timeout(IntPtr db, int timeout);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] private static extern IntPtr sqlite3_errmsg16(IntPtr db);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] private static extern int sqlite3_prepare_v2(IntPtr db, byte[] sql, int size, out IntPtr statement, IntPtr tail);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] private static extern int sqlite3_step(IntPtr statement);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] private static extern int sqlite3_finalize(IntPtr statement);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] private static extern int sqlite3_column_count(IntPtr statement);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] private static extern int sqlite3_column_type(IntPtr statement, int index);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] private static extern IntPtr sqlite3_column_text16(IntPtr statement, int index);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] private static extern int sqlite3_column_bytes16(IntPtr statement, int index);
    }
}
