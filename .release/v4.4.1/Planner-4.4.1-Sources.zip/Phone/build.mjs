import fs from 'node:fs/promises';
import path from 'node:path';

const root = new URL('.', import.meta.url);
const source = path.join(root.pathname.replace(/^\/([A-Za-z]:)/, '$1'), 'web');
const destination = new URL('./dist/server/', root);
await fs.mkdir(destination, { recursive: true });
const assets = {};
const mime = { '.html': 'text/html;charset=utf-8', '.js': 'application/javascript;charset=utf-8', '.css': 'text/css;charset=utf-8',
  '.json': 'application/json;charset=utf-8', '.webmanifest': 'application/manifest+json', '.jpg': 'image/jpeg', '.png': 'image/png', '.exe': 'application/octet-stream' };
for (const name of await fs.readdir(source)) {
  if (!(await fs.stat(path.join(source, name))).isFile()) continue;
  assets['/' + name] = { type: mime[path.extname(name)] || 'application/octet-stream', body: (await fs.readFile(path.join(source, name))).toString('base64') };
}
await fs.writeFile(new URL('assets.js', destination), 'export const assets=' + JSON.stringify(assets) + ';\n');
for (const name of ['index.js', 'api.js', 'push.js', 'auth.js', 'independent.js']) await fs.copyFile(new URL('./backend/' + name, root), new URL(name, destination));
await fs.copyFile(new URL('./web/domain.js', root), new URL('domain.js', destination));
let hosting;
try { hosting = JSON.parse(await fs.readFile(new URL('./.openai/hosting.json', root), 'utf8')); }
catch (error) { if (error.code !== 'ENOENT') throw error; }
if (hosting) {
  await fs.mkdir(new URL('./dist/.openai/', root), { recursive: true });
  await fs.writeFile(new URL('./dist/.openai/hosting.json', root), JSON.stringify(hosting, null, 2));
}
await fs.writeFile(new URL('wrangler.json', destination), JSON.stringify({ name: 'planner-phone', main: 'index.js', compatibility_date: '2026-11-27', triggers: { crons: ['* * * * *'] } }, null, 2));
console.log('Built iPhone planner with', Object.keys(assets).length, 'assets');
