CREATE TABLE planner_sessions (
  token_hash TEXT PRIMARY KEY NOT NULL,
  owner TEXT NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE INDEX planner_sessions_expiry ON planner_sessions(expires_at);
CREATE TABLE planner_pairings (
  code_hash TEXT PRIMARY KEY NOT NULL,
  owner TEXT NOT NULL,
  expires_at INTEGER NOT NULL
);
