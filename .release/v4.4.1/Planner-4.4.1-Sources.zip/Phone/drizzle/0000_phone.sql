CREATE TABLE planner_documents (
  owner TEXT PRIMARY KEY NOT NULL,
  revision INTEGER NOT NULL DEFAULT 0,
  body TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE planner_keys (
  name TEXT PRIMARY KEY NOT NULL,
  body TEXT NOT NULL
);
CREATE TABLE planner_subscriptions (
  id TEXT PRIMARY KEY NOT NULL,
  owner TEXT NOT NULL,
  body TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX planner_subscriptions_owner ON planner_subscriptions(owner);
CREATE TABLE planner_deliveries (
  id TEXT PRIMARY KEY NOT NULL,
  state TEXT NOT NULL,
  lease_until INTEGER NOT NULL,
  updated_at TEXT NOT NULL
);
