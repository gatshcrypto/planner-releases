import http from 'node:http';
import fs from 'node:fs';
import { DatabaseSync } from 'node:sqlite';
import worker from './dist/server/index.js';
import independentWorker from './dist/server/independent.js';
import { hash } from './dist/server/push.js';

fs.mkdirSync('.local', { recursive: true });
const db = new DatabaseSync('.local/planner.sqlite');
db.exec('PRAGMA journal_mode=WAL');
const exists = db.prepare("SELECT name FROM sqlite_master WHERE name='planner_documents'").get();
if (!exists) db.exec(fs.readFileSync('drizzle/0000_phone.sql', 'utf8'));
if (!db.prepare("SELECT name FROM sqlite_master WHERE name='planner_sessions'").get()) db.exec(fs.readFileSync('drizzle/0001_independent_auth.sql', 'utf8'));
const independent = process.env.PLANNER_INDEPENDENT === '1';
const port = Number(process.env.PLANNER_PORT || 4317);
const keyHash = process.env.PLANNER_TEST_KEY ? await hash(process.env.PLANNER_TEST_KEY) : null;
const binding = { prepare(sql) {
  let values = [];
  const statement = { bind(...parameters) { values = parameters; return statement; },
    async first() { return db.prepare(sql).get(...values) || null; },
    async all() { return { results: db.prepare(sql).all(...values) }; },
    async run() { const result = db.prepare(sql).run(...values); return { meta: { changes: Number(result.changes) } }; } };
  return statement;
} };
const server = http.createServer(async (incoming, outgoing) => {
  try {
    const chunks = []; for await (const chunk of incoming) chunks.push(chunk);
    const headers = new Headers(incoming.headers);
    if (!independent) headers.set('oai-authenticated-user-id', 'local-planner-owner');
    const host = incoming.headers.host === `localhost:${port}` ? `localhost:${port}` : `127.0.0.1:${port}`;
    const request = new Request(`http://${host}` + incoming.url, { method: incoming.method, headers,
      ...(!['GET', 'HEAD'].includes(incoming.method) ? { body: Buffer.concat(chunks) } : {}) });
    let response;
    const url = new URL(request.url);
    if (!url.pathname.startsWith('/api/')) {
      const filename = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
      if (!filename.includes('..') && !filename.includes('\\') && fs.existsSync('web/' + filename)) {
        const extension = filename.split('.').pop();
        const types = { html: 'text/html;charset=utf-8', js: 'application/javascript', css: 'text/css', json: 'application/json', webmanifest: 'application/manifest+json', png: 'image/png', jpg: 'image/jpeg', exe: 'application/octet-stream' };
        response = new Response(fs.readFileSync('web/' + filename), { headers: { 'Content-Type': types[extension] || 'application/octet-stream', 'Cache-Control': 'no-store' } });
      }
    }
    response ||= await (independent ? independentWorker : worker).fetch(request, { DB: binding, OWNER_ID: 'local-independent-owner', OWNER_KEY_HASH: keyHash });
    outgoing.writeHead(response.status, Object.fromEntries(response.headers));
    outgoing.end(Buffer.from(await response.arrayBuffer()));
  } catch (error) { console.error(error); outgoing.writeHead(500); outgoing.end('Local preview failed'); }
});
server.listen(port, '127.0.0.1', () => console.log(`Local http://127.0.0.1:${port}`));
