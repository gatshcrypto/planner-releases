"""Rebuild the mobile source and the resource embedded in the Windows application."""
import argparse
from pathlib import Path
import subprocess
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--phone', type=Path, default=Path('Phone'))
parser.add_argument('--windows', type=Path, default=Path('Windows'))
args = parser.parse_args()
phone, windows = args.phone.resolve(), args.windows.resolve()
subprocess.run(['node', 'build.mjs'], cwd=phone, check=True)
destination = windows / 'src' / 'PhoneServer.zip'
with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for source in sorted((phone / 'dist' / 'server').glob('*.js')):
        archive.write(source, source.name)
    for source in sorted((phone / 'drizzle').glob('*.sql')):
        archive.write(source, 'drizzle/' + source.name)
print(destination)
